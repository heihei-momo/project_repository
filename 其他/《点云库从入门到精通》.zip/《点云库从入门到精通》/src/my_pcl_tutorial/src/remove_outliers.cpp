#include <iostream>
#include <pcl/point_types.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <pcl/filters/conditional_removal.h>
int
 main (int argc, char** argv)
{
  if (argc != 2)
  {
    std::cerr << "please specify command line arg '-r' or '-c'" << std::endl;
    exit(0);
  }
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered (new pcl::PointCloud<pcl::PointXYZ>);
  cloud->width  = 5;
  cloud->height = 1;
  cloud->points.resize (cloud->width * cloud->height);
  for (size_t i = 0; i < cloud->points.size (); ++i)
  {
    cloud->points[i].x = 1024 * rand () / (RAND_MAX + 1.0f);
    cloud->points[i].y = 1024 * rand () / (RAND_MAX + 1.0f);
    cloud->points[i].z = 1024 * rand () / (RAND_MAX + 1.0f);
  }//[0,1024)
  if (strcmp(argv[1], "-r") == 0){//第二个参数检查是不是-r
    pcl::RadiusOutlierRemoval<pcl::PointXYZ> outrem;//outrem 是一个半径离群点移除滤波器对象
    outrem.setInputCloud(cloud);
    outrem.setRadiusSearch(0.8);//对每个点，搜索半径 0.8 米 范围内的邻居点
    outrem.setMinNeighborsInRadius(2);//如果一个点在指定半径内的邻居数 少于 2 个，就认为它是离群点
    outrem.filter (*cloud_filtered);
  }
  else if (strcmp(argv[1], "-c") == 0){
    
    pcl::ConditionAnd<pcl::PointXYZ>::Ptr range_cond (new pcl::ConditionAnd<pcl::PointXYZ> ());//ConditionAnd 表示多个条件必须 同时满足 才保留这个点（逻辑与 AND）
    range_cond->addComparison (pcl::FieldComparison<pcl::PointXYZ>::ConstPtr (new pcl::FieldComparison<pcl::PointXYZ> ("z", pcl::ComparisonOps::GT, 0.0)));
    //FieldComparison 表示对点的某个字段进行比较。
    // "z" → 选择 Z 坐标。
    // pcl::ComparisonOps::GT → 大于 (Greater Than)。
    // 0.0 → 阈值。
    // 含义：Z 坐标必须大于 0.0 米
    range_cond->addComparison (pcl::FieldComparison<pcl::PointXYZ>::ConstPtr (new pcl::FieldComparison<pcl::PointXYZ> ("z", pcl::ComparisonOps::LT, 0.8)));
    //"z" → 选择 Z 坐标。
    // pcl::ComparisonOps::LT → 小于 (Less Than)。
    // 0.8 → 阈值。
    // 含义：Z 坐标必须小于 0.8 米。
    pcl::ConditionalRemoval<pcl::PointXYZ> condrem;//创建一个条件滤波器对象
    condrem.setCondition(range_cond);//把刚刚定义的 range_cond 条件传给滤波器
    condrem.setInputCloud (cloud);
    condrem.setKeepOrganized(true);
    //true → 不改变点云的组织结构（比如有序点云的宽高不变），不符合条件的点会被设置为 NaN。
    //false → 删除不符合条件的点，得到稠密点云。
    condrem.filter (*cloud_filtered);
  }
  else{
    std::cerr << "please specify command line arg '-r' or '-c'" << std::endl;
    exit(0);
  }
  std::cerr << "Cloud before filtering: " << std::endl;
  for (size_t i = 0; i < cloud->points.size (); ++i)
    std::cerr << "    " << cloud->points[i].x << " "
                        << cloud->points[i].y << " "
                        << cloud->points[i].z << std::endl;

  std::cerr << "Cloud after filtering: " << std::endl;
  for (size_t i = 0; i < cloud_filtered->points.size (); ++i)
    std::cerr << "    " << cloud_filtered->points[i].x << " "
                        << cloud_filtered->points[i].y << " "
                        << cloud_filtered->points[i].z << std::endl;
  return (0);
}
