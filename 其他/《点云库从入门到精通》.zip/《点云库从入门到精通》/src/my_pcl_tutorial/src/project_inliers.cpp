#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/io/io.h>
int main (int argc, char** argv)
{
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_projected (new pcl::PointCloud<pcl::PointXYZ>);
  
  cloud->width  = 5;
  cloud->height = 1;
  cloud->points.resize (cloud->width * cloud->height);
  for (size_t i = 0; i < cloud->points.size (); ++i)
  {
    cloud->points[i].x = 1024 * rand () / (RAND_MAX + 1.0f);
    cloud->points[i].y = 1024 * rand () / (RAND_MAX + 1.0f);
    cloud->points[i].z = 1024 * rand () / (RAND_MAX + 1.0f);
  }//生成[0,1024)的随机点云
  std::cerr << "Cloud before projection: " << std::endl;
  for (size_t i = 0; i < cloud->points.size (); ++i)
    std::cerr << "    " << cloud->points[i].x << " " 
                        << cloud->points[i].y << " " 
                        << cloud->points[i].z << std::endl;
  
  pcl::ModelCoefficients::Ptr coefficients (new pcl::ModelCoefficients ());
  //ModelCoefficients 存放几何模型（如平面/直线/圆柱等）的参数。
  //这是一个共享指针（PCL 里通常用 boost::shared_ptr/std::shared_ptr），在堆上分配
  coefficients->values.resize (4);//对于平面模型（SACMODEL_PLANE），需要 4 个系数：[a, b, c, d]，表示平面方程
  coefficients->values[0] = coefficients->values[1] = 0;//这就是 a=0, b=0, c=1, d=0
  coefficients->values[2] = 1.0;//代入方程：0·x + 0·y + 1·z + 0 = 0 → z = 0
  coefficients->values[3] = 0;//也就是法向量 n = (0,0,1) 的水平平面（通过原点的 XY 平面）
  
  pcl::ProjectInliers<pcl::PointXYZ> proj;//创建一个投影滤波器。它会把点沿着法向量作正交投影到指定模型上
  proj.setModelType (pcl::SACMODEL_PLANE);
  //告诉滤波器：我们的模型是“平面”
  //因为不同模型（直线/平面/圆柱/球）需要不同数量和意义的 values
  proj.setInputCloud (cloud);//设置输入点云
  proj.setModelCoefficients (coefficients);//把上面准备好的平面系数传进去
  proj.filter (*cloud_projected);
  //执行投影。输出点云 cloud_projected与输入（或指定的子集）点数相同，但坐标已被投影到平面上。
  //如果没有调用 setIndices(...) 指定“内点集合”，则默认对全部点进行投影
  pcl::visualization::CloudViewer viewer("Cloud Viewer");    
  viewer.showCloud(cloud_projected);
  std::cerr << "Cloud after projection: " << std::endl;
  for (size_t i = 0; i < cloud_projected->points.size (); ++i)
    std::cerr << "    " << cloud_projected->points[i].x << " " 
                        << cloud_projected->points[i].y << " " 
                        << cloud_projected->points[i].z << std::endl;
  while (!viewer.wasStopped()) {
}
  return (0);
}
