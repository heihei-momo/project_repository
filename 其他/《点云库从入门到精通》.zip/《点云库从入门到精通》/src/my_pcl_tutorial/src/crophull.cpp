#include <pcl/visualization/cloud_viewer.h>
#include <iostream>
#include <pcl/io/io.h>
#include <pcl/io/pcd_io.h>
#include <vector>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/crop_hull.h>
#include <pcl/surface/concave_hull.h>

int main(int argc, char** argv)
{
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
	pcl::PCDReader reader;
	reader.read(argv[1],*cloud);

	pcl::PointCloud<pcl::PointXYZ>::Ptr boundingbox_ptr (new pcl::PointCloud<pcl::PointXYZ>);//构造“多边形点集”
	boundingbox_ptr->push_back(pcl::PointXYZ(0.1, 0.1, 0));
	boundingbox_ptr->push_back(pcl::PointXYZ(0.1, -0.1,0 ));
	boundingbox_ptr->push_back(pcl::PointXYZ(-0.1, 0.1,0 ));
	boundingbox_ptr->push_back(pcl::PointXYZ(-0.1, -0.1,0 ));
	boundingbox_ptr->push_back(pcl::PointXYZ(0.15, 0.2,0 ));
	//这里不是“轴对齐”盒，而是 5 个点组成的2D 点集（全在 z=0）。
	// 第 5 个点 (0.15, 0.1, 0) 会让凸包向 +X 方向凸出。
	// 重要：点的顺序不影响凸包，但会影响直接画“多边形”的顺序。凸包会返回排序后的顶点与三角剖分

	pcl::ConvexHull<pcl::PointXYZ> hull;//ConvexHull 会自动删除那些位于边界内部的点，最终结果可能只剩 4 个点（四边形）
	hull.setInputCloud(boundingbox_ptr);
	hull.setDimension(2);//只在 XY 平面上做凸包；输出 surface_hull（有序的包络顶点）和 polygons（三角面片索引，供 CropHull 使用）
	std::vector<pcl::Vertices> polygons;//存放凸包多边形的顶点索引
	pcl::PointCloud<pcl::PointXYZ>::Ptr surface_hull (new pcl::PointCloud<pcl::PointXYZ>);//保存凸包计算得到的实际几何点
	hull.reconstruct(*surface_hull, polygons);
	// 根据之前 hull.setInputCloud(boundingbox_ptr) 传入的点云，
	// 按 setDimension(2) 或 setDimension(3) 计算凸包。
	// 结果存到：
	// surface_hull → 按凸包外形排序的顶点坐标点云。
	// polygons → 这些点之间的连接关系（多边形面）
	pcl::PointCloud<pcl::PointXYZ>::Ptr objects (new pcl::PointCloud<pcl::PointXYZ>);//新建一个空点云 objects，用来存放裁剪后的结果（在凸包范围内的点）。
	pcl::CropHull<pcl::PointXYZ> bb_filter;
	//创建一个裁剪过滤器 CropHull（Hull = 壳/凸包）。
	// 功能：根据多边形凸包（二维）或多面体凸包（三维）来筛选点云。
	// 和 CropBox 不同，它不是用长方体裁剪，而是用任意形状的多边形/多面体
	bb_filter.setDim(2);//告诉过滤器按二维裁剪
	bb_filter.setInputCloud(cloud);
	bb_filter.setHullIndices(polygons);//传入凸包的拓扑结构（多边形顶点的索引）
	bb_filter.setHullCloud(surface_hull);//传入凸包的实际点坐标（外形）
	bb_filter.filter(*objects);//执行裁剪，把 cloud 中在凸包区域内的点提取出来，保存到 objects
	std::cout << objects->size() << std::endl;

	//visualize
	boost::shared_ptr<pcl::visualization::PCLVisualizer> for_visualizer_v (new pcl::visualization::PCLVisualizer ("crophull display"));
	for_visualizer_v->setBackgroundColor(255,255,255);

	int v1(0);
	for_visualizer_v->createViewPort (0.0, 0.0, 0.33, 1, v1);
	for_visualizer_v->setBackgroundColor (255, 255, 255, v1);
	for_visualizer_v->addPointCloud (cloud,"cloud",v1);
	for_visualizer_v->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR,255,0,0,"cloud");
	for_visualizer_v->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE,3,"cloud");
	for_visualizer_v->addPolygon<pcl::PointXYZ>(surface_hull,0,.069*255,0.2*255,"backview_hull_polyline1",v1);

	int v2(0);
	for_visualizer_v->createViewPort (0.33, 0.0, 0.66, 1, v2);	
	for_visualizer_v->setBackgroundColor (255, 255, 255, v2);
	for_visualizer_v->addPointCloud (surface_hull,"surface_hull",v2);
	for_visualizer_v->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR,255,0,0,"surface_hull");
	for_visualizer_v->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE,8,"surface_hull");
	for_visualizer_v->addPolygon<pcl::PointXYZ>(surface_hull,0,.069*255,0.2*255,"backview_hull_polyline",v2);

	int v3(0);
	for_visualizer_v->createViewPort (0.66, 0.0, 1, 1, v3);
	for_visualizer_v->setBackgroundColor (255, 255, 255, v3);
	for_visualizer_v->addPointCloud (objects,"objects",v3);
	for_visualizer_v->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR,255,0,0,"objects");
	for_visualizer_v->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE,3,"objects");

	while (!for_visualizer_v->wasStopped())
	{

		for_visualizer_v->spinOnce(1000);
	}
	system("pause");
}
