#include <pcl/point_cloud.h>
#include <pcl/octree/octree.h>
#include <iostream>
#include <vector>
#include <ctime>
	
int main (int argc, char**argv)
{
srand ((unsigned int) time (NULL));//用当前时间初始化 C 标准 rand() 随机种子，使后面随机点每次运行不同

float resolution =24.0f;//体素网格分辨率

pcl::octree::OctreePointCloudChangeDetector<pcl::PointXYZ>octree (resolution);//这是一个能维护「当前/之前」两个体素集合并比较它们差异的专用 octree。构造时把 voxel 分辨率传入
pcl::PointCloud<pcl::PointXYZ>::Ptr cloudA (new pcl::PointCloud<pcl::PointXYZ> );

cloudA->width =128;
cloudA->height =1;
cloudA->points.resize (cloudA->width *cloudA->height);
for (size_t i=0; i<cloudA->points.size (); ++i)
  {
cloudA->points[i].x =64.0f* rand () / (RAND_MAX +1.0f);
cloudA->points[i].y =64.0f* rand () / (RAND_MAX +1.0f);
cloudA->points[i].z =64.0f* rand () / (RAND_MAX +1.0f);
  }//随机生成点云

octree.setInputCloud (cloudA);//告诉 octree 接下来用哪个点云作为输入；它并不把点复制到树里，只是记录指针以供 addPointsFromInputCloud 使用
octree.addPointsFromInputCloud ();//把 cloudA 中的所有点根据 resolution 插入到当前“工作” octree（称为当前缓冲区），建立体素占用信息

octree.switchBuffers ();//switchBuffers() 做了缓冲区切换
//当第一次 addPointsFromInputCloud()后，某个缓冲区被填充为 cloudA 的占用信息。调用 switchBuffers() 会将当前占用作为 “previous”（用于之后的比较），并把“current”缓冲区重置为空以接收下一帧的点。
// 这样后续插入的点会进入“current”缓冲区，而比较操作将把 current 与 previous 作差异检测
pcl::PointCloud<pcl::PointXYZ>::Ptr cloudB (new pcl::PointCloud<pcl::PointXYZ> );

cloudB->width =128;
cloudB->height =1;
cloudB->points.resize (cloudB->width *cloudB->height);
for (size_t i=0; i<cloudB->points.size (); ++i)
  {
cloudB->points[i].x =64.0f* rand () / (RAND_MAX +1.0f);
cloudB->points[i].y =64.0f* rand () / (RAND_MAX +1.0f);
cloudB->points[i].z =64.0f* rand () / (RAND_MAX +1.0f);
  }//随机生成点云，第二帧

octree.setInputCloud (cloudB);
octree.addPointsFromInputCloud ();
//此时 octree 内部有两份信息：previous（cloudA 占用）与 current（cloudB 占用），可以进行比较
std::vector<int>newPointIdxVector;
octree.getPointIndicesFromNewVoxels (newPointIdxVector);
//比较 current vs previous，找出current 中那些位于“新 voxel”（即之前 previous 没有占用） 的点，并把这些点在 cloudB 中的索引写入 newPointIdxVector。
// 返回的索引是相对于 cloudB 的（注意不是 cloudA）
std::cout<<"Output from getPointIndicesFromNewVoxels:"<<std::endl;
for (size_t i=0; i<newPointIdxVector.size (); ++i)
std::cout<<i<<"# Index:"<<newPointIdxVector[i]
<<"  Point:"<<cloudB->points[newPointIdxVector[i]].x <<" "
<<cloudB->points[newPointIdxVector[i]].y <<" "
<<cloudB->points[newPointIdxVector[i]].z <<std::endl;
}
