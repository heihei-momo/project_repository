/* 跑不通 段错误 */
#include <iostream>
#include <boost/thread/thread.hpp>
#include <pcl/range_image/range_image.h>
#include <pcl/io/pcd_io.h>
#include <pcl/visualization/range_image_visualizer.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/features/range_image_border_extractor.h>
#include <pcl/keypoints/narf_keypoint.h>
#include <pcl/features/narf_descriptor.h>
#include <pcl/console/parse.h>

typedef pcl::PointXYZ PointType;

float angular_resolution = 0.5f;
float support_size = 0.2f;
pcl::RangeImage::CoordinateFrame coordinate_frame = pcl::RangeImage::CAMERA_FRAME;
bool setUnseenToMaxRange = false;
bool rotation_invariant = true;

void 
printUsage (const char* progName)
{
  std::cout << "\n\nUsage: "<<progName<<" [options] <scene.pcd>\n\n"
            << "Options:\n"
            << "-------------------------------------------\n"
            << "-r <float>   angular resolution in degrees (default "<<angular_resolution<<")\n"
            << "-c <int>     coordinate frame (default "<< (int)coordinate_frame<<")\n"
            << "-m           Treat all unseen points to max range\n"
            << "-s <float>   support size for the interest points (diameter of the used sphere - "
                                                                  "default "<<support_size<<")\n"
            << "-o <0/1>     switch rotational invariant version of the feature on/off"
            <<               " (default "<< (int)rotation_invariant<<")\n"
            << "-h           this help\n"
            << "\n\n";
}

void 
setViewerPose (pcl::visualization::PCLVisualizer& viewer, const Eigen::Affine3f& viewer_pose)
{
  // 计算相机位置、观察点和 up 向量
  Eigen::Vector3f pos_vector   = viewer_pose * Eigen::Vector3f (0, 0, 0);
  Eigen::Vector3f look_at_vec  = viewer_pose.rotation () * Eigen::Vector3f (0, 0, 1) + pos_vector;
  //默认相机朝向是 z 轴正方向 (0,0,1)，乘以旋转矩阵得到新的朝向，再加上位置得到焦点坐标。计算观察点

  Eigen::Vector3f up_vector    = viewer_pose.rotation () * Eigen::Vector3f (0, -1, 0);//计算上方向

  // 设置相机参数（pos, focal, up）
  viewer.setCameraPosition(
      static_cast<double>(pos_vector[0]), static_cast<double>(pos_vector[1]), static_cast<double>(pos_vector[2]),//相机位置
      static_cast<double>(look_at_vec[0]), static_cast<double>(look_at_vec[1]), static_cast<double>(look_at_vec[2]),//观察点
      static_cast<double>(up_vector[0]), static_cast<double>(up_vector[1]), static_cast<double>(up_vector[2])//上方向
  );

  viewer.updateCamera();//刷新相机
}

int main (int argc, char** argv)
{

  if (pcl::console::find_argument (argc, argv, "-h") >= 0)//命令行找到-h
  {
    printUsage (argv[0]);//打印
    return 0;
  }
  if (pcl::console::find_argument (argc, argv, "-m") >= 0)
  {
    setUnseenToMaxRange = true;
    cout << "Setting unseen values in range image to maximum range readings.\n";
  }
  if (pcl::console::parse (argc, argv, "-o", rotation_invariant) >= 0)//检查用户在运行程序时是否带了 -o 参数，如果有，就把后面跟的数值解析到变量 rotation_invariant 里面
    cout << "Switching rotation invariant feature version "<< (rotation_invariant ? "on" : "off")<<".\n";
  int tmp_coordinate_frame;
  if (pcl::console::parse (argc, argv, "-c", tmp_coordinate_frame) >= 0)
  {
    coordinate_frame = pcl::RangeImage::CoordinateFrame (tmp_coordinate_frame);
    cout << "Using coordinate frame "<< (int)coordinate_frame<<".\n";
  }
  if (pcl::console::parse (argc, argv, "-s", support_size) >= 0)
    cout << "Setting support size to "<<support_size<<".\n";
  if (pcl::console::parse (argc, argv, "-r", angular_resolution) >= 0)
    cout << "Setting angular resolution to "<<angular_resolution<<"deg.\n";
  angular_resolution = pcl::deg2rad (angular_resolution);//把角度制的分辨率（单位：度）转换成弧度制

  pcl::PointCloud<PointType>::Ptr point_cloud_ptr (new pcl::PointCloud<PointType>);
  pcl::PointCloud<PointType>& point_cloud = *point_cloud_ptr;
  pcl::PointCloud<pcl::PointWithViewpoint> far_ranges;//这里用来存储“远距离点云”（通常是深度图超出近场传感器范围的点）
  Eigen::Affine3f scene_sensor_pose (Eigen::Affine3f::Identity ());//存储传感器位姿（位置 + 朝向）。初始化为单位矩阵。
  std::vector<int> pcd_filename_indices = pcl::console::parse_file_extension_argument (argc, argv, "pcd");
  if (!pcd_filename_indices.empty ())
  {
    std::string filename = argv[pcd_filename_indices[0]];//存储pcd文件名
    if (pcl::io::loadPCDFile (filename, point_cloud) == -1)
    {
      cerr << "Was not able to open file \""<<filename<<"\".\n";
      printUsage (argv[0]);
      return 0;
    }
    scene_sensor_pose = Eigen::Affine3f (Eigen::Translation3f (point_cloud.sensor_origin_[0],                                                               point_cloud.sensor_origin_[1],                                             point_cloud.sensor_origin_[2])) *
                        Eigen::Affine3f (point_cloud.sensor_orientation_);//从 point_cloud 的 元数据（sensor_origin_ 和 sensor_orientation_）提取出原始传感器的位姿
    std::string far_ranges_filename = pcl::getFilenameWithoutExtension (filename)+"_far_ranges.pcd";
    if (pcl::io::loadPCDFile (far_ranges_filename.c_str (), far_ranges) == -1)
      std::cout << "Far ranges file \""<<far_ranges_filename<<"\" does not exists.\n";
  }
  else
  {
    setUnseenToMaxRange = true;
    cout << "\nNo *.pcd file given => Genarating example point cloud.\n\n";//自己创建点云
    for (float x=-0.5f; x<=0.5f; x+=0.01f)
    {
      for (float y=-0.5f; y<=0.5f; y+=0.01f)
      {
        PointType point;  point.x = x;  point.y = y;  point.z = 2.0f - y;
        point_cloud.points.push_back (point);
      }
    }
    point_cloud.width = (int) point_cloud.points.size ();  point_cloud.height = 1;
  }

  float noise_level = 0.0;
  float min_range = 0.0f;
  int border_size = 1;
  boost::shared_ptr<pcl::RangeImage> range_image_ptr (new pcl::RangeImage);
  pcl::RangeImage& range_image = *range_image_ptr;   
  range_image.createFromPointCloud (point_cloud, angular_resolution, pcl::deg2rad (360.0f), pcl::deg2rad (180.0f),
                                   scene_sensor_pose, coordinate_frame, noise_level, min_range, border_size);//生成一个 RangeImage，相当于把 3D 点云投影到球面坐标（range image）上
  //range_image.createFromPointCloud (
  //     point_cloud,             // 输入点云
  //     angular_resolution,      // 角分辨率（弧度制）
  //     pcl::deg2rad(360.0f),    // 水平方向视场角（360°）
  //     pcl::deg2rad(180.0f),    // 垂直方向视场角（180°）
  //     scene_sensor_pose,       // 传感器位姿（相机/激光雷达的外参）
  //     coordinate_frame,        // 坐标系类型（CAMERA_FRAME 等）
  //     noise_level,             // 噪声水平（默认 0.0，表示不加噪声）
  //     min_range,               // 最小量程（<min_range 的点会被忽略）
  //     border_size              // 边界像素填充值
  // );                                 
  // range_image.integrateFarRanges (far_ranges);//far_ranges是读取的far   pcd，如果有“很远的点”，把它们补到深度图里。
  if (setUnseenToMaxRange)
    range_image.setUnseenToMaxRange ();//未定义的像素 → 被赋值为 max_range（最大量程）
  
  pcl::visualization::PCLVisualizer viewer ("3D Viewer");
  viewer.setBackgroundColor (1, 1, 1);
  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointWithRange> range_image_color_handler (range_image_ptr, 0, 0, 0);
  viewer.addPointCloud (range_image_ptr, range_image_color_handler, "range image");//设置颜色
  viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "range image");//点云大小
  viewer.initCameraParameters ();//初始化相机
  setViewerPose (viewer, range_image.getTransformationToWorldSystem ()/*把相机调整到 RangeImage 对应的传感器视角*/);  

  pcl::visualization::RangeImageVisualizer range_image_widget ("Range image");
  range_image_widget.showRangeImage (range_image);//用灰度图显示深度信息

  pcl::RangeImageBorderExtractor range_image_border_extractor;//用来提取 RangeImage 的边界点
  pcl::NarfKeypoint narf_keypoint_detector;
  narf_keypoint_detector.setRangeImageBorderExtractor (&range_image_border_extractor);//设置边界提取器
  narf_keypoint_detector.setRangeImage (&range_image);//输入深度图
  narf_keypoint_detector.getParameters ().support_size = support_size;//support_size 是检测器参数，表示关键点邻域的半径
  
  pcl::PointCloud<int> keypoint_indices;//存储 整数索引 的点云
  narf_keypoint_detector.compute (keypoint_indices);//真正执行 NARF 关键点检测的步骤
  std::cout << "Found "<<keypoint_indices.points.size ()<<" key points.\n";

  pcl::PointCloud<pcl::PointXYZ>::Ptr keypoints_ptr (new pcl::PointCloud<pcl::PointXYZ>);
  pcl::PointCloud<pcl::PointXYZ>& keypoints = *keypoints_ptr;
  keypoints.points.resize (keypoint_indices.points.size ());
  for (size_t i=0; i<keypoint_indices.points.size (); ++i)
  keypoints.points[i].getVector3fMap () = range_image.points[keypoint_indices.points[i]].getVector3fMap ();
  //用索引从 RangeImage 取出 真实 3D 坐标
  
  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> keypoints_color_handler (keypoints_ptr, 0, 255, 0);
  viewer.addPointCloud<pcl::PointXYZ> (keypoints_ptr, keypoints_color_handler, "keypoints");//设置关键点的颜色
  viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 7, "keypoints");//设置关键点的大小

  std::vector<int> keypoint_indices2;
  keypoint_indices2.resize (keypoint_indices.points.size ());
  for (unsigned int i=0; i<keypoint_indices.size (); ++i) 
    keypoint_indices2[i]=keypoint_indices.points[i];//可以用这个索引从 RangeImage 或原始点云 中找到对应的 3D 点：
  pcl::NarfDescriptor narf_descriptor (&range_image, &keypoint_indices2);//参数：深度图，关键点索引的 std::vector<int>告诉计算器在哪些点上计算描述子
  narf_descriptor.getParameters ().support_size = support_size;
  //关键点邻域半径，影响描述子覆盖的局部范围
  //半径越大，描述子越平滑、稳定，但对细节敏感度降低
  narf_descriptor.getParameters ().rotation_invariant = rotation_invariant;
  //是否使用旋转不变版本的描述子。
  //如果为 true，描述子对旋转不敏感，适合姿态变化较大的点云

  pcl::PointCloud<pcl::Narf36> narf_descriptors;//存储所有关键点的 NARF 描述子
  narf_descriptor.compute (narf_descriptors);
  //遍历 keypoint_indices2 中的每个关键点。
  // 在关键点邻域内提取局部几何特征（深度、边界信息）。
  // 将特征编码成 36 维 NARF 描述子

  cout << "Extracted "<<narf_descriptors.size ()<<" descriptors for "
                      <<keypoint_indices.points.size ()<< " keypoints.\n";

  while (!viewer.wasStopped ())
  {
    range_image_widget.spinOnce ();
    viewer.spinOnce ();
    pcl_sleep(0.01);
  }
}
