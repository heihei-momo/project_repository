#include <pcl/io/pcd_io.h>
#include <pcl/point_cloud.h>
#include <pcl/correspondence.h>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/features/shot_omp.h>
#include <pcl/features/board.h>
#include <pcl/filters/uniform_sampling.h>  // 修改头文件路径
#include <pcl/recognition/cg/hough_3d.h>
#include <pcl/recognition/cg/geometric_consistency.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/kdtree/impl/kdtree_flann.hpp>
#include <pcl/common/transforms.h>
#include <pcl/console/parse.h>
#include <pcl/filters/extract_indices.h>  // 添加提取索引的头文件

typedef pcl::PointXYZRGBA PointType;
typedef pcl::Normal NormalType;
typedef pcl::ReferenceFrame RFType;
typedef pcl::SHOT352 DescriptorType;

std::string model_filename_;
std::string scene_filename_;

//Algorithm params
bool show_keypoints_ (false);
bool show_correspondences_ (false);
bool use_cloud_resolution_ (false);
bool use_hough_ (true);
float model_ss_ (0.01f);
float scene_ss_ (0.03f);
float rf_rad_ (0.015f);
float descr_rad_ (0.02f);
float cg_size_ (0.01f);
float cg_thresh_ (5.0f);

void
showHelp (char *filename)
{
  std::cout << std::endl;
  std::cout << "***************************************************************************" << std::endl;
  std::cout << "*                                                                         *" << std::endl;
  std::cout << "*             Correspondence Grouping Tutorial - Usage Guide              *" << std::endl;
  std::cout << "*                                                                         *" << std::endl;
  std::cout << "***************************************************************************" << std::endl << std::endl;
  std::cout << "Usage: " << filename << " model_filename.pcd scene_filename.pcd [Options]" << std::endl << std::endl;
  std::cout << "Options:" << std::endl;
  std::cout << "     -h:                     Show this help." << std::endl;
  std::cout << "     -k:                     Show used keypoints." << std::endl;
  std::cout << "     -c:                     Show used correspondences." << std::endl;
  std::cout << "     -r:                     Compute the model cloud resolution and multiply" << std::endl;
  std::cout << "                             each radius given by that value." << std::endl;
  std::cout << "     --algorithm (Hough|GC): Clustering algorithm used (default Hough)." << std::endl;
  std::cout << "     --model_ss val:         Model uniform sampling radius (default 0.01)" << std::endl;
  std::cout << "     --scene_ss val:         Scene uniform sampling radius (default 0.03)" << std::endl;
  std::cout << "     --rf_rad val:           Reference frame radius (default 0.015)" << std::endl;
  std::cout << "     --descr_rad val:        Descriptor radius (default 0.02)" << std::endl;
  std::cout << "     --cg_size val:          Cluster size (default 0.01)" << std::endl;
  std::cout << "     --cg_thresh val:        Clustering threshold (default 5)" << std::endl << std::endl;
}

void
parseCommandLine (int argc, char *argv[])
{
  //Show help
  if (pcl::console::find_switch (argc, argv, "-h"))
  {
    showHelp (argv[0]);
    exit (0);
  }

  //Model & scene filenames
  std::vector<int> filenames;
  filenames = pcl::console::parse_file_extension_argument (argc, argv, ".pcd");//返回值：一个 std::vector<int>，包含所有命令行参数中以该扩展名结尾的 索引（即 argv 中的位置）
  if (filenames.size () != 2)
  {
    std::cout << "Filenames missing.\n";
    showHelp (argv[0]);
    exit (-1);
  }

  model_filename_ = argv[filenames[0]];
  scene_filename_ = argv[filenames[1]];

  //Program behavior
  if (pcl::console::find_switch (argc, argv, "-k"))//命令行参数里出现了 -k
  {
    show_keypoints_ = true;
  }
  if (pcl::console::find_switch (argc, argv, "-c"))
  {
    show_correspondences_ = true;
  }
  if (pcl::console::find_switch (argc, argv, "-r"))
  {
    use_cloud_resolution_ = true;
  }

  std::string used_algorithm;
  if (pcl::console::parse_argument (argc, argv, "--algorithm", used_algorithm) != -1)//是 PCL（Point Cloud Library） 的命令行解析函数，用来 读取带参数的选项值。-1的话是没找到
  {
    if (used_algorithm.compare ("Hough") == 0)//用来比较字符串是否相等，相等的话就等于0
    {
      use_hough_ = true;
    }else if (used_algorithm.compare ("GC") == 0)
    {
      use_hough_ = false;
    }
    else
    {
      std::cout << "Wrong algorithm name.\n";
      showHelp (argv[0]);
      exit (-1);
    }
  }

  //General parameters
  pcl::console::parse_argument (argc, argv, "--model_ss", model_ss_);//从命令行参数里解析出 --model_ss 后面跟的数值，并存到变量 model_ss_中
  pcl::console::parse_argument (argc, argv, "--scene_ss", scene_ss_);
  pcl::console::parse_argument (argc, argv, "--rf_rad", rf_rad_);
  pcl::console::parse_argument (argc, argv, "--descr_rad", descr_rad_);
  pcl::console::parse_argument (argc, argv, "--cg_size", cg_size_);
  pcl::console::parse_argument (argc, argv, "--cg_thresh", cg_thresh_);
}

double
computeCloudResolution (const pcl::PointCloud<PointType>::ConstPtr &cloud)
{
  double res = 0.0;
  int n_points = 0;
  int nres;
  std::vector<int> indices (2);//两个元素
  std::vector<float> sqr_distances (2);
  pcl::search::KdTree<PointType> tree;
  tree.setInputCloud (cloud);

  for (size_t i = 0; i < cloud->size (); ++i)
  {
    if (! std::isfinite ((*cloud)[i].x))  // 改为使用std::isfinite
    {
      continue;
    }
    //Considering the second neighbor since the first is the point itself.
    nres = tree.nearestKSearch (i, 2, indices, sqr_distances);//找第i个点的邻近两个点，indices是返回邻近点的索引，sqr_distancesstd::vector<float>，返回对应邻居点到查询点的 平方距离。
    if (nres == 2)//nres返回找到的最近邻点的数量
    {
      res += sqrt (sqr_distances[1]);//计算最近点的距离
      ++n_points;//计算点数
    }
  }
  if (n_points != 0)
  {
    res /= n_points;//计算分辨率
  }
  return res;
}

int
main (int argc, char *argv[])
{
  parseCommandLine (argc, argv);

  pcl::PointCloud<PointType>::Ptr model (new pcl::PointCloud<PointType> ());
  pcl::PointCloud<PointType>::Ptr model_keypoints (new pcl::PointCloud<PointType> ());
  pcl::PointCloud<PointType>::Ptr scene (new pcl::PointCloud<PointType> ());
  pcl::PointCloud<PointType>::Ptr scene_keypoints (new pcl::PointCloud<PointType> ());
  pcl::PointCloud<NormalType>::Ptr model_normals (new pcl::PointCloud<NormalType> ());
  pcl::PointCloud<NormalType>::Ptr scene_normals (new pcl::PointCloud<NormalType> ());
  pcl::PointCloud<DescriptorType>::Ptr model_descriptors (new pcl::PointCloud<DescriptorType> ());
  pcl::PointCloud<DescriptorType>::Ptr scene_descriptors (new pcl::PointCloud<DescriptorType> ());

  //
  //  Load clouds
  //
  if (pcl::io::loadPCDFile (model_filename_, *model) < 0)
  {
    std::cout << "Error loading model cloud." << std::endl;
    showHelp (argv[0]);
    return (-1);
  }
  if (pcl::io::loadPCDFile (scene_filename_, *scene) < 0)
  {
    std::cout << "Error loading scene cloud." << std::endl;
    showHelp (argv[0]);
    return (-1);
  }

  //
  //  Set up resolution invariance
  //
  if (use_cloud_resolution_)
  {
    float resolution = static_cast<float> (computeCloudResolution (model));//计算分辨率
    if (resolution != 0.0f)
    {
      model_ss_   *= resolution;
      scene_ss_   *= resolution;
      rf_rad_     *= resolution;
      descr_rad_  *= resolution;
      cg_size_    *= resolution;//计算样本size
    }

    std::cout << "Model resolution:       " << resolution << std::endl;
    std::cout << "Model sampling size:    " << model_ss_ << std::endl;
    std::cout << "Scene sampling size:    " << scene_ss_ << std::endl;
    std::cout << "LRF support radius:     " << rf_rad_ << std::endl;
    std::cout << "SHOT descriptor radius: " << descr_rad_ << std::endl;
    std::cout << "Clustering bin size:    " << cg_size_ << std::endl << std::endl;
  }

  //
  //  Compute Normals
  //
  pcl::NormalEstimationOMP<PointType, NormalType> norm_est;//创建法向量估计对象
  norm_est.setKSearch (10);//设置最近邻搜索数量
  norm_est.setInputCloud (model);//指定输入点云
  norm_est.compute (*model_normals);//计算每个点的法向量，输出到 model_normals

  norm_est.setInputCloud (scene);
  norm_est.compute (*scene_normals);

  //
  //  Downsample Clouds to Extract keypoints
  //
  pcl::PointCloud<int> sampled_indices;

  pcl::UniformSampling<PointType> uniform_sampling;//创建均匀采样对象
  uniform_sampling.setInputCloud (model);//指定需要下采样的 输入点云
  uniform_sampling.setRadiusSearch (model_ss_);//采样半径

  pcl::PointCloud<PointType>::Ptr model_filtered(new pcl::PointCloud<PointType>());
  uniform_sampling.filter(*model_filtered);//将下采样后的点写入 model_filtered
  *model_keypoints = *model_filtered;
  
  std::cout << "Model total points: " << model->size () << "; Selected Keypoints: " << model_keypoints->size () << std::endl;

  uniform_sampling.setInputCloud (scene);
  uniform_sampling.setRadiusSearch (scene_ss_);
  
  // 修改这里：同样使用filter()方法
  pcl::PointCloud<PointType>::Ptr scene_filtered(new pcl::PointCloud<PointType>());
  uniform_sampling.filter(*scene_filtered);
  *scene_keypoints = *scene_filtered;
  
  std::cout << "Scene total points: " << scene->size () << "; Selected Keypoints: " << scene_keypoints->size () << std::endl;

  //
  //  Compute Descriptor for keypoints
  //
  pcl::SHOTEstimationOMP<PointType, NormalType, DescriptorType> descr_est;//创建描述子计算对象
  descr_est.setRadiusSearch (descr_rad_);//描述子计算邻域半径

  descr_est.setInputCloud (model_keypoints);//输入点云（均匀采样后的点云）
  descr_est.setInputNormals (model_normals);//输入法向量
  descr_est.setSearchSurface (model);//设置搜索邻域的原始点云
  descr_est.compute (*model_descriptors);//计算 SHOT 特征，结果保存在 model_descriptors

  descr_est.setInputCloud (scene_keypoints);
  descr_est.setInputNormals (scene_normals);
  descr_est.setSearchSurface (scene);
  descr_est.compute (*scene_descriptors);

  //
  //  Find Model-Scene Correspondences with KdTree
  //
  pcl::CorrespondencesPtr model_scene_corrs (new pcl::Correspondences ());

  pcl::KdTreeFLANN<DescriptorType> match_search;
  match_search.setInputCloud (model_descriptors);//输入特征描述点云

  //  For each scene keypoint descriptor, find nearest neighbor into the model keypoints descriptor cloud and add it to the correspondences vector.
  for (size_t i = 0; i < scene_descriptors->size (); ++i)//遍历 每个场景关键点的 SHOT 描述子
  {
    std::vector<int> neigh_indices (1);
    std::vector<float> neigh_sqr_dists (1);
    if (!std::isfinite (scene_descriptors->at (i).descriptor[0])) //skipping NaNs, 改为std::isfinite
    {
      continue;//跳过无效点
    }
    int found_neighs = match_search.nearestKSearch (scene_descriptors->at (i), 1, neigh_indices, neigh_sqr_dists);
    //match_search是模型描述子kd树，不是场景描述子，自己的点不在特征描述点云里面
    if(found_neighs == 1 && neigh_sqr_dists[0] < 0.25f) //如果找到了一个，并且距离小于0.25
    {
      pcl::Correspondence corr (neigh_indices[0], static_cast<int> (i), neigh_sqr_dists[0]);//pcl::Correspondence：表示 模型点和场景点的一对对应关系
      //neigh_indices[0]：模型点索引（KdTree 找到的最近邻点）
      // static_cast<int>(i)：场景点索引（当前遍历的关键点）
      // neigh_sqr_dists[0]：匹配距离（平方距离，用于衡量特征相似度）
      model_scene_corrs->push_back (corr);
    }
  }
  std::cout << "Correspondences found: " << model_scene_corrs->size () << std::endl;

  //
  //  Actual Clustering
  //
  std::vector<Eigen::Matrix4f, Eigen::aligned_allocator<Eigen::Matrix4f> > rototranslations;
  std::vector<pcl::Correspondences> clustered_corrs;

  //  Using Hough3D
  if (use_hough_)//Hough 3D 投票方法
  {
    //
    //  Compute (Keypoints) Reference Frames only for Hough
    //
    pcl::PointCloud<RFType>::Ptr model_rf (new pcl::PointCloud<RFType> ());
    pcl::PointCloud<RFType>::Ptr scene_rf (new pcl::PointCloud<RFType> ());

    pcl::BOARDLocalReferenceFrameEstimation<PointType, NormalType, RFType> rf_est;//每个关键点计算局部坐标系
    rf_est.setFindHoles (true);//处理点云空洞
    rf_est.setRadiusSearch (rf_rad_);//邻域半径

    rf_est.setInputCloud (model_keypoints);//输入均匀采样后的点云
    rf_est.setInputNormals (model_normals);//输入原始点云法向量
    rf_est.setSearchSurface (model);//输入原始点云
    rf_est.compute (*model_rf);//对模型关键点计算 LRF，输出到 model_rf

    rf_est.setInputCloud (scene_keypoints);
    rf_est.setInputNormals (scene_normals);
    rf_est.setSearchSurface (scene);
    rf_est.compute (*scene_rf);//对场景关键点计算 LRF，输出到 scene_rf

    //  Clustering
    pcl::Hough3DGrouping<PointType, PointType, RFType, RFType> clusterer;//创建 Hough 3D 分组器对象
    clusterer.setHoughBinSize (cg_size_);//投票空间每个 bin 的大小（控制精度）
    clusterer.setHoughThreshold (cg_thresh_);//投票空间每个 bin 的大小（控制精度）
    clusterer.setUseInterpolation (true);//投票时是否对 bin 进行插值，提高精度
    clusterer.setUseDistanceWeight (false);//是否按距离加权投票（这里关闭）

    clusterer.setInputCloud (model_keypoints);
    clusterer.setInputRf (model_rf);
    clusterer.setSceneCloud (scene_keypoints);
    clusterer.setSceneRf (scene_rf);
    //输入关键点和局部参考系
    clusterer.setModelSceneCorrespondences (model_scene_corrs);//设置模型-场景初步对应关系

    clusterer.recognize (rototranslations, clustered_corrs);//执行识别
    //rototranslations：输出模型在场景中的位姿矩阵（4x4 仿射矩阵）
    //clustered_corrs：每个识别出的物体对应的关键点匹配集合
  }
  else // Using GeometricConsistency   //使用 Geometric Consistency (GC) 方法进行点云物体识别
  {
    pcl::GeometricConsistencyGrouping<PointType, PointType> gc_clusterer;
    gc_clusterer.setGCSize (cg_size_);//点对之间一致性距离阈值 如果两对匹配点之间的距离变化在该阈值内，认为几何一致
    gc_clusterer.setGCThreshold (cg_thresh_);//形成聚类所需的最少一致点对数

    gc_clusterer.setInputCloud (model_keypoints);//模型关键点
    gc_clusterer.setSceneCloud (scene_keypoints);//输入关键点的点云  场景关键点
    gc_clusterer.setModelSceneCorrespondences (model_scene_corrs);//model_scene_corrs

    gc_clusterer.recognize (rototranslations, clustered_corrs);
    //rototranslations：每个识别物体的位姿矩阵（4x4 仿射矩阵）
    //clustered_corrs：每个识别物体的匹配点集
    
  }

  //
  //  Output results
  //
  std::cout << "Model instances found: " << rototranslations.size () << std::endl;//识别到的模型实例数量
  for (size_t i = 0; i < rototranslations.size (); ++i)
  {
    std::cout << "\n    Instance " << i + 1 << ":" << std::endl;
    std::cout << "        Correspondences belonging to this instance: " << clustered_corrs[i].size () << std::endl;//输出匹配点数量

    // Print the rotation matrix and translation vector
    Eigen::Matrix3f rotation = rototranslations[i].block<3,3>(0, 0);//提取旋转矩阵，提取从 第 0 行、第 0 列 开始的 3×3 块 也就是 T 的左上角 3×3 部分
    Eigen::Vector3f translation = rototranslations[i].block<3,1>(0, 3);//从 第 0 行、第 3 列 开始，提取 3×1 块 也就是仿射矩阵右上角的平移向量 [t_x, t_y, t_z]^T

    printf ("\n");
    printf ("            | %6.3f %6.3f %6.3f | \n", rotation (0,0), rotation (0,1), rotation (0,2));
    printf ("        R = | %6.3f %6.3f %6.3f | \n", rotation (1,0), rotation (1,1), rotation (1,2));
    printf ("            | %6.3f %6.3f %6.3f | \n", rotation (2,0), rotation (2,1), rotation (2,2));
    printf ("\n");
    printf ("        t = < %0.3f, %0.3f, %0.3f >\n", translation (0), translation (1), translation (2));
  }

  //
  //  Visualization
  //
  pcl::visualization::PCLVisualizer viewer ("Correspondence Grouping Tutorial");
  viewer.addPointCloud (scene, "scene_cloud");
  viewer.setBackgroundColor(255,255,255);
  pcl::PointCloud<PointType>::Ptr off_scene_model (new pcl::PointCloud<PointType> ());
  pcl::PointCloud<PointType>::Ptr off_scene_model_keypoints (new pcl::PointCloud<PointType> ());

  if (show_correspondences_ || show_keypoints_)
  {
    //  We are translating the model so that it doesn't end in the middle of the scene representation
    //对点云进行旋转 平移，但这里是单位旋转和没有平移，等于拷贝了一份新的点云
    pcl::transformPointCloud (*model, *off_scene_model, Eigen::Vector3f (0,0,0), Eigen::Quaternionf (1, 0, 0, 0));
    pcl::transformPointCloud (*model_keypoints, *off_scene_model_keypoints, Eigen::Vector3f (0,0,0), Eigen::Quaternionf (1, 0, 0, 0));

    pcl::visualization::PointCloudColorHandlerCustom<PointType> off_scene_model_color_handler (off_scene_model, 0, 255, 0);//给点云自定义颜色
    viewer.addPointCloud (off_scene_model, off_scene_model_color_handler, "off_scene_model");//将off_scene_model用绿色显示
  }

  if (show_keypoints_)
  {
    pcl::visualization::PointCloudColorHandlerCustom<PointType> scene_keypoints_color_handler (scene_keypoints, 0, 0, 255);
    viewer.addPointCloud (scene_keypoints, scene_keypoints_color_handler, "scene_keypoints");//scene_keypoints用某颜色显示
    viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 5, "scene_keypoints");//设置点云大小为5

    pcl::visualization::PointCloudColorHandlerCustom<PointType> off_scene_model_keypoints_color_handler (off_scene_model_keypoints, 0, 0, 255);//设置off_scene_model_keypoints的颜色
    viewer.addPointCloud (off_scene_model_keypoints, off_scene_model_keypoints_color_handler, "off_scene_model_keypoints");//添加显示
    viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 5, "off_scene_model_keypoints");
  }

  for (size_t i = 0; i < rototranslations.size (); ++i)//rototranslations 存储每个识别物体的 4x4 位姿矩阵
  {
    pcl::PointCloud<PointType>::Ptr rotated_model (new pcl::PointCloud<PointType> ());
    pcl::transformPointCloud (*model, *rotated_model, rototranslations[i]);//模型点云变换到场景位置，也就是对齐坐标系，对齐场景

    std::stringstream ss_cloud;
    ss_cloud << "instance" << i;

    pcl::visualization::PointCloudColorHandlerCustom<PointType> rotated_model_color_handler (rotated_model, 255, 0, 0);//设置颜色
    viewer.addPointCloud (rotated_model, rotated_model_color_handler, ss_cloud.str ());//添加显示

    if (show_correspondences_)
    {
      for (size_t j = 0; j < clustered_corrs[i].size (); ++j)
      //clustered_corrs[i] → 第 i 个识别实例的 匹配关键点集合
      // 每个 Correspondence 包含：
      // index_query：模型关键点索引
      // index_match：场景关键点索引
      // distance：描述子距离（可选，用于阈值筛选）
      {
        std::stringstream ss_line;
        ss_line << "correspondence_line" << i << "_" << j;//每条线生成 唯一名称 ID
        PointType& model_point = off_scene_model_keypoints->at (clustered_corrs[i][j].index_query);//取第 i 个识别实例中第 j 对匹配对应关系的模型关键点。会同时获取对应的场景点
        //at(index) 方法返回点云中指定索引的点
        PointType& scene_point = scene_keypoints->at (clustered_corrs[i][j].index_match);//取第 i 个识别实例中第 j 对匹配对应关系的关键点

        //  We are drawing a line for each pair of clustered correspondences found between the model and the scene
        viewer.addLine<PointType, PointType> (model_point, scene_point, 0, 255, 0, ss_line.str ());//在PCL可视化器中绘制两点之间的连线
      }
    }
  }

  while (!viewer.wasStopped ())
  {
    viewer.spinOnce ();
  }
  return (0);
}