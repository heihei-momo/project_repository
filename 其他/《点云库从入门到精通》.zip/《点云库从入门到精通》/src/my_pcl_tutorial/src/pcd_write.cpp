#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
//随机生成点云并保存

int main(int argc,char**argv)
{
pcl::PointCloud<pcl::PointXYZ> cloud;//点类型是 pcl::PointXYZ，表示每个点有 x、y、z 三个 float 坐标
cloud.width=5;//一行五个点
cloud.height=1;//一行，非有序点云
cloud.is_dense=false;//表示点云可能包含非法值
cloud.points.resize(cloud.width*cloud.height);//分配存储空间，这里是五个点
for(size_t i=0;i<cloud.points.size();++i)
{
cloud.points[i].x=1024*rand()/(RAND_MAX+1.0f);//生成一个0到1024的数字，RAND_MAX应该是rand的最大值
cloud.points[i].y=1024*rand()/(RAND_MAX+1.0f);//+1.0f，可以解决浮点数的运算（精度），还可以变成，半开区间
cloud.points[i].z=1024*rand()/(RAND_MAX+1.0f);
}
pcl::io::savePCDFileASCII("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/test_pcd.pcd",cloud);
std::cerr<<"Saved "<<cloud.points.size()<<" data points to test_pcd.pcd."<<std::endl;
for(size_t i=0;i<cloud.points.size();++i)
std::cerr<<"    "<<cloud.points[i].x<<" "<<cloud.points[i].y<<" "<<cloud.points[i].z<<std::endl;
return(0);
}
