#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/features/normal_3d.h>
#include <pcl/features/feature.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/features/fpfh.h>
#include <pcl/features/impl/fpfh.hpp>
#include <pcl/recognition/implicit_shape_model.h>

int
main (int argc, char** argv)
{
  if (argc == 0)
  { std::cout << std::endl;
  std::cout << "Usage: " << argv[0] << "class1.pcd class1_label(int) class2.pcd class2_label" << std::endl << std::endl;
   return (-1);
  }
  unsigned int number_of_training_clouds = (argc - 1) / 2;

  pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> normal_estimator;//法线估计器初始化
  normal_estimator.setRadiusSearch (25.0);

  std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr> training_clouds;
  std::vector<pcl::PointCloud<pcl::Normal>::Ptr> training_normals;
  std::vector<unsigned int> training_classes;
  //定义训练数据容器

  for (unsigned int i_cloud = 0; i_cloud < number_of_training_clouds - 1; i_cloud++)
  {
    pcl::PointCloud<pcl::PointXYZ>::Ptr tr_cloud(new pcl::PointCloud<pcl::PointXYZ> ());
    if ( pcl::io::loadPCDFile <pcl::PointXYZ> (argv[i_cloud * 2 + 1], *tr_cloud) == -1 )//加载点云
      return (-1);

    pcl::PointCloud<pcl::Normal>::Ptr tr_normals = (new pcl::PointCloud<pcl::Normal>)->makeShared ();
    normal_estimator.setInputCloud (tr_cloud);
    normal_estimator.compute (*tr_normals);//计算法线

    unsigned int tr_class = static_cast<unsigned int> (strtol (argv[i_cloud * 2 + 2], 0, 10));//将命令行参数转为整数标签。

    training_clouds.push_back (tr_cloud);//原点云
    training_normals.push_back (tr_normals);//对应法线
    training_classes.push_back (tr_class);//标签
  }

  pcl::FPFHEstimation<pcl::PointXYZ, pcl::Normal, pcl::Histogram<153> >::Ptr fpfh(new pcl::FPFHEstimation<pcl::PointXYZ, pcl::Normal, pcl::Histogram<153> >);//FPFH 特征估计器
  fpfh->setRadiusSearch (30.0);//设定半径搜索为 30 个单位
  pcl::Feature< pcl::PointXYZ, pcl::Histogram<153> >::Ptr feature_estimator(fpfh);//将 FPFH 包装成通用 Feature 类型，方便传给 ISM
 
  pcl::ism::ImplicitShapeModelEstimation<153, pcl::PointXYZ, pcl::Normal> ism;//初始化隐式形状模型（ISM）训练器
  ism.setFeatureEstimator(feature_estimator);//设置特征计算器
  ism.setTrainingClouds (training_clouds);//训练点云
  ism.setTrainingNormals (training_normals);//训练法线
  ism.setTrainingClasses (training_classes);//类别标签
  ism.setSamplingSize (2.0f);//采样大小

  pcl::ism::ImplicitShapeModelEstimation<153, pcl::PointXYZ, pcl::Normal>::ISMModelPtr model = boost::shared_ptr<pcl::features::ISMModel>(new pcl::features::ISMModel);
  //ISMModelPtr 是训练完成的隐式形状模型对象，存储了训练结果
  ism.trainISM (model);//执行训练

  std::string file ("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/txt/trained_ism_model.txt");
  model->saveModelToFile (file);

  std::cout << "trained_ism_model.txt is the output of training stage. You can use the trained_ism_model.txt in the classification stage" << std::endl << std::endl;

  return (0);
}