#include <iostream>
#include <string>
#include <vector>

#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>

#include <pdal/pdal.hpp>
#include <pdal/StageFactory.hpp>
#include <pdal/PointView.hpp>
#include <pdal/Options.hpp>
#include <pdal/PointTable.hpp>

int main(int argc, char** argv)
{
    if (argc != 3)//参数检查 程序-las文件路径-输出的pcd路径
    {
        std::cerr << "用法: " << argv[0] << " input.las output.pcd" << std::endl;
        return -1;
    }

    std::string las_file = argv[1];
    std::string pcd_file = argv[2];

    // 创建 PDAL LAS Reader
    pdal::StageFactory factory;//StageFactory 是 PDAL 的工厂类，用来创建各种 Stage 对象（Stage 是 PDAL 中的基本单元：reader、filter、writer 等都继承自 Stage）
    pdal::Options options;//Options 用来存放给 Stage 的参数（键值对集合）。每个 Stage 接受的一组参数不同（reader 最常见的参数是 filename）
    options.add("filename", las_file);//把文件名设置进 options，使后面创建的 reader 知道要打开哪个 LAS 文件

    pdal::Stage* reader = factory.createStage("readers.las");//创建 PDAL 的 LAS reader stage（一个插件）
	//请求 factory 实例化一个名为 "readers.las" 的 stage，并返回指向基类 Stage 的原始指针
    if (!reader)
    {
        std::cerr << "无法创建 LAS 读取器，请确认已安装 PDAL 并支持 LAS 格式" << std::endl;
        return -1;
    }
    reader->setOptions(options);//把之前创建的 options（里面有 filename=las_file 等参数）传递给这个 Stage（这里是 readers.las）

    pdal::PointTable table;//PDAL 的 PointTable 是用来保存点云数据的“架子”
    reader->prepare(table);//让这个 stage（reader）检查参数、分配资源、建立 PointTable 的 schema（字段结构）
    pdal::PointViewSet viewSet = reader->execute(table);//真正去读 LAS 文件，把数据加载到 PointTable，并返回一个 PointViewSet（点视图集合）

    // 取第一块数据
    pdal::PointViewPtr view = *viewSet.begin();

    // 转换到 PCL 格式
    pcl::PointCloud<pcl::PointXYZRGB> cloud;
    cloud.width = view->size();
    cloud.height = 1;
    cloud.is_dense = false;//说明点云里可能有无效点（NaN）。
    cloud.points.resize(cloud.width);

    for (pdal::point_count_t i = 0; i < view->size(); ++i)//遍历
    {
        cloud.points[i].x = view->getFieldAs<float>(pdal::Dimension::Id::X, i);
        cloud.points[i].y = view->getFieldAs<float>(pdal::Dimension::Id::Y, i);
        cloud.points[i].z = view->getFieldAs<float>(pdal::Dimension::Id::Z, i);

        uint16_t r = view->getFieldAs<uint16_t>(pdal::Dimension::Id::Red, i);
        uint16_t g = view->getFieldAs<uint16_t>(pdal::Dimension::Id::Green, i);
        uint16_t b = view->getFieldAs<uint16_t>(pdal::Dimension::Id::Blue, i);

        cloud.points[i].r = static_cast<uint8_t>(r / 256);//把颜色值缩放到八位，把 0–65535 映射到 0–255 范围
        cloud.points[i].g = static_cast<uint8_t>(g / 256);
        cloud.points[i].b = static_cast<uint8_t>(b / 256);
    }

    // 保存为 PCD
    pcl::io::savePCDFileBinary(pcd_file, cloud);
    std::cout << "成功将 " << las_file << " 转换为 " << pcd_file
              << "，点数: " << cloud.points.size() << std::endl;

    return 0;
}
