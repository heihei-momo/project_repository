#include <pcl/point_cloud.h>
#include <pcl/octree/octree.h>
#include <iostream>
#include <vector>
#include <ctime>

int main (int argc, char**argv)
{
srand ((unsigned int) time (NULL));
pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
cloud->width =1000;
cloud->height =1;
cloud->points.resize (cloud->width * cloud->height);
for (size_t i=0; i< cloud->points.size (); ++i)
  {//随机生成点云
cloud->points[i].x =1024.0f* rand () / (RAND_MAX +1.0f);
cloud->points[i].y =1024.0f* rand () / (RAND_MAX +1.0f);
cloud->points[i].z =1024.0f* rand () / (RAND_MAX +1.0f);
  }
float resolution =128.0f;//resolution 是八叉树(Octree)的 体素（voxel）边长，单位和点云坐标单位相同（米、毫米或其它）。Octree 用这个分辨率把空间划分成等大小立方体格子
pcl::octree::OctreePointCloudSearch<pcl::PointXYZ> octree(resolution);//Octree 会先根据 resolution 把空间切成很多立方体格子
//构造一个类型为 pcl::PointXYZ 的 OctreePointCloudSearch 对象，使用上面给定的 resolution。此时树是空的（还没加入点）
octree.setInputCloud (cloud);//把点云指针 cloud（通常是 pcl::PointCloud<pcl::PointXYZ>::Ptr）设置到 octree 上，告诉 octree 以后要用这个点云的数据来建树或进行增量插入
octree.addPointsFromInputCloud();//把 cloud 里的所有点插入到 octree 结构中（真正建立索引）。调用后就可以执行搜索操作。这一步会按点数做树结构插入，复杂度接近 O(N)（建立成本），对大点云会耗时与内存。
pcl::PointXYZ searchPoint;
searchPoint.x=1024.0f* rand () / (RAND_MAX +1.0f);
searchPoint.y=1024.0f* rand () / (RAND_MAX +1.0f);
searchPoint.z=1024.0f* rand () / (RAND_MAX +1.0f);
// 生成一个随机查询点 searchPoint，坐标范围 [0,1024)

std::vector<int>pointIdxVec;
if (octree.voxelSearch(searchPoint, pointIdxVec))//查找和 searchPoint 所在 同一个体素（之前切了很多空间格子resolution） 的所有点索引。布尔值 true/false，表示是否找到体素
  {
std::cout<<"Neighbors within voxel search at ("<<searchPoint.x
<<" "<<searchPoint.y
<<" "<<searchPoint.z<<")"
<<std::endl;
for (size_t i=0; i<pointIdxVec.size (); ++i)
std::cout<<"    "<< cloud->points[pointIdxVec[i]].x 
<<" "<< cloud->points[pointIdxVec[i]].y 
<<" "<< cloud->points[pointIdxVec[i]].z <<std::endl;
  }

int K =10;
std::vector<int>pointIdxNKNSearch;
std::vector<float>pointNKNSquaredDistance;
std::cout<<"K nearest neighbor search at ("<<searchPoint.x
<<" "<<searchPoint.y
<<" "<<searchPoint.z
<<") with K="<< K <<std::endl;
if (octree.nearestKSearch (searchPoint, K, pointIdxNKNSearch, pointNKNSquaredDistance) >0)//返回附近点的索引和对应的平方欧氏距离
  {
for (size_t i=0; i<pointIdxNKNSearch.size (); ++i)
std::cout<<"    "<<   cloud->points[ pointIdxNKNSearch[i] ].x 
<<" "<< cloud->points[pointIdxNKNSearch[i] ].y 
<<" "<< cloud->points[pointIdxNKNSearch[i] ].z 
<<" (squared distance: "<<pointNKNSquaredDistance[i] <<")"<<std::endl;
  }

std::vector<int>pointIdxRadiusSearch;//用来保存 搜索到的点的索引（cloud->points[index]）。
std::vector<float>pointRadiusSquaredDistance;//保存这些点到 searchPoint 的 平方距离（不用开方计算更快）
float radius =256.0f* rand () / (RAND_MAX +1.0f);//范围
std::cout<<"Neighbors within radius search at ("<<searchPoint.x
<<" "<<searchPoint.y
<<" "<<searchPoint.z
<<") with radius="<< radius <<std::endl;
if (octree.radiusSearch (searchPoint, radius, pointIdxRadiusSearch, pointRadiusSquaredDistance) >0)//找相应范围内的点
  {
for (size_t i=0; i<pointIdxRadiusSearch.size (); ++i)
std::cout<<"    "<<   cloud->points[ pointIdxRadiusSearch[i] ].x 
<<" "<< cloud->points[pointIdxRadiusSearch[i] ].y 
<<" "<< cloud->points[pointIdxRadiusSearch[i] ].z 
<<" (squared distance: "<<pointRadiusSquaredDistance[i] <<")"<<std::endl;
  }
}
