//初始猜测矩阵guess可能不符合实际数据，所以没有配准重合
#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/registration/ndt.h>
#include <pcl/filters/approximate_voxel_grid.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <boost/thread/thread.hpp>
int
main (int argc, char** argv)
{

  pcl::PointCloud<pcl::PointXYZ>::Ptr target_cloud (new pcl::PointCloud<pcl::PointXYZ>);
  if (pcl::io::loadPCDFile<pcl::PointXYZ> ("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd_11.2/2.pcd", *target_cloud) == -1)
  {
    PCL_ERROR ("Couldn't read file room_scan1.pcd \n");
    return (-1);
  }
  std::cout << "Loaded " << target_cloud->size () << " data points from room_scan1.pcd" << std::endl;

  pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud (new pcl::PointCloud<pcl::PointXYZ>);
  if (pcl::io::loadPCDFile<pcl::PointXYZ> ("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd_11.2/1.pcd", *input_cloud) == -1)
  {
    PCL_ERROR ("Couldn't read file room_scan2.pcd \n");
    return (-1);
  }
  std::cout << "Loaded " << input_cloud->size () << " data points from room_scan2.pcd" << std::endl;


  pcl::PointCloud<pcl::PointXYZ>::Ptr cleaned_cloud(new pcl::PointCloud<pcl::PointXYZ>);
  std::vector<int> indices;
  pcl::removeNaNFromPointCloud(*input_cloud, *cleaned_cloud, indices);
  input_cloud = cleaned_cloud;

  pcl::PointCloud<pcl::PointXYZ>::Ptr filtered_cloud (new pcl::PointCloud<pcl::PointXYZ>);
  pcl::ApproximateVoxelGrid<pcl::PointXYZ> approximate_voxel_filter;//近似体素网格滤波器
  approximate_voxel_filter.setLeafSize (0.1, 0.1, 0.1);//0.2 m 表示每个体素边长 20 厘米 
  approximate_voxel_filter.setInputCloud (input_cloud);
  approximate_voxel_filter.filter (*filtered_cloud);//滤波
  std::cout << "Filtered cloud contains " << filtered_cloud->size ()
            << " data points from room_scan2.pcd" << std::endl;
  pcl::NormalDistributionsTransform<pcl::PointXYZ, pcl::PointXYZ> ndt;//创建ndt对象

  ndt.setTransformationEpsilon (0.01);//控制配准精度
  ndt.setStepSize (0.1);//设置梯度下降步长
  ndt.setResolution (1.0);//设置网格分辨率
  ndt.setMaximumIterations (55);//最多迭代 35 次，防止算法陷入死循环。
  ndt.setInputCloud (filtered_cloud);
  ndt.setInputTarget (target_cloud);
  Eigen::AngleAxisf init_rotation (0.6931, Eigen::Vector3f::UnitZ ());//初始旋转
  Eigen::Translation3f init_translation (1.79387, 0.720047, 0);//初始平移
  Eigen::Matrix4f init_guess = (init_translation * init_rotation).matrix ();//构建初始变换矩阵
  pcl::PointCloud<pcl::PointXYZ>::Ptr output_cloud (new pcl::PointCloud<pcl::PointXYZ>);
  ndt.align (*output_cloud, init_guess);//*output_cloud 会被更新为当前迭代后的点云位置，但这只是 中间状态或粗略结果
  //output_cloud 保存配准结果。
  //使用 init_guess 提供初始位姿。
  std::cout << "Normal Distributions Transform has converged:" << ndt.hasConverged ()
            << " score: " << ndt.getFitnessScore () << std::endl;

  pcl::transformPointCloud (*input_cloud, *output_cloud, ndt.getFinalTransformation ());//将源点云应用 NDT 配准得到的最终变换矩阵，生成对齐后的点云
  //最终对齐结果：通常是通过 ndt.getFinalTransformation() 得到矩阵，然后再用 transformPointCloud 应用到原始点云
  pcl::io::savePCDFileASCII ("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/room_scan2_transformed.pcd", *output_cloud);
  boost::shared_ptr<pcl::visualization::PCLVisualizer>
  viewer_final (new pcl::visualization::PCLVisualizer ("3D Viewer"));
  viewer_final->setBackgroundColor (0, 0, 0);
  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ>
  target_color (target_cloud, 255, 0, 0);//红色
  viewer_final->addPointCloud<pcl::PointXYZ> (target_cloud, target_color, "target cloud");
  viewer_final->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE,
                                                  1, "target cloud");
  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ>
  output_color (output_cloud, 0, 255, 0);
  viewer_final->addPointCloud<pcl::PointXYZ> (output_cloud, output_color, "output cloud");
  viewer_final->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE,
                                                  1, "output cloud");

  viewer_final->addCoordinateSystem (1.0);
  viewer_final->initCameraParameters ();

  while (!viewer_final->wasStopped ())
  {
    viewer_final->spinOnce (100);
    boost::this_thread::sleep (boost::posix_time::microseconds (100000));
  }
  return (0);
}
