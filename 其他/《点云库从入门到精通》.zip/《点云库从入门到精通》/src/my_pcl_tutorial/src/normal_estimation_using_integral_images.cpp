 #include <pcl/io/io.h>
     #include <pcl/io/pcd_io.h>
     #include <pcl/features/integral_image_normal.h>
     #include <pcl/visualization/cloud_viewer.h>
     int
     main ()
     {
             pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
             pcl::io::loadPCDFile ("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/table_scene_mug_stereo_textured.pcd", *cloud);

             pcl::PointCloud<pcl::Normal>::Ptr normals (new pcl::PointCloud<pcl::Normal>);
             pcl::IntegralImageNormalEstimation<pcl::PointXYZ, pcl::Normal> ne;
             ne.setNormalEstimationMethod (ne.AVERAGE_3D_GRADIENT);//选择积分图法线估计的内部算法
             ne.setMaxDepthChangeFactor(0.02f);//深度变化阈值
             ne.setNormalSmoothingSize(10.0f);//控制用于平滑法线的邻域大小因子
             ne.setInputCloud(cloud);
             ne.compute(*normals);

             pcl::visualization::PCLVisualizer viewer("PCL Viewer");
             viewer.setBackgroundColor (0.0, 0.0, 0.5);//蓝色
             viewer.addPointCloudNormals<pcl::PointXYZ,pcl::Normal>(cloud, normals);
             while (!viewer.wasStopped ())
             {
               viewer.spinOnce ();
             }
             return 0;
     }
