#include <boost/make_shared.hpp>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/point_representation.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/filter.h>
#include <pcl/features/normal_3d.h>
#include <pcl/registration/icp.h>
#include <pcl/registration/icp_nl.h>
#include <pcl/registration/transforms.h>
#include <pcl/visualization/pcl_visualizer.h>
using pcl::visualization::PointCloudColorHandlerGenericField;
using pcl::visualization::PointCloudColorHandlerCustom;

typedef pcl::PointXYZ PointT;
typedef pcl::PointCloud<PointT> PointCloud;
typedef pcl::PointNormal PointNormalT;
typedef pcl::PointCloud<PointNormalT> PointCloudWithNormals;

pcl::visualization::PCLVisualizer *p;

int vp_1, vp_2;

struct PCD
{
  PointCloud::Ptr cloud;
  std::string f_name;
  PCD() : cloud (new PointCloud) {};//构造函数 PCD() : cloud(new PointCloud) {}; 在创建 PCD 对象时，自动分配一个新的空点云对象，并让 cloud 智能指针指向它。
};
struct PCDComparator
{
  bool operator () (const PCD& p1, const PCD& p2)
  {
    return (p1.f_name < p2.f_name);
  }
};

class MyPointRepresentation : public pcl::PointRepresentation <PointNormalT>//继承了 pcl::PointRepresentation<PointNormalT>，表示你要为 PointNormalT 类型的点（带法向和曲率）定义一个新的向量表示方式
{
  using pcl::PointRepresentation<PointNormalT>::nr_dimensions_;
public:
  MyPointRepresentation ()
  {

    nr_dimensions_ = 4;//表示你映射后的向量有多少维
  }

  virtual void copyToFloatArray (const PointNormalT &p, float * out) const//copyToFloatArray 是 纯虚函数，只会在 基类 PointRepresentation 的指针/引用 被用到的时候被调用
  {
    // < x, y, z, curvature >
    out[0] = p.x;
    out[1] = p.y;
    out[2] = p.z;
    out[3] = p.curvature;
  }
};

void showCloudsLeft(const PointCloud::Ptr cloud_target, const PointCloud::Ptr cloud_source)//原始点云，目标点云
{
  p->removePointCloud ("vp1_target");
  p->removePointCloud ("vp1_source");//如果视口里之前已经显示过名为 "vp1_target" 或 "vp1_source" 的点云，会先删除
  PointCloudColorHandlerCustom<PointT> tgt_h (cloud_target, 0, 255, 0);
  PointCloudColorHandlerCustom<PointT> src_h (cloud_source, 255, 0, 0);//创建颜色处理器
  p->addPointCloud (cloud_target, tgt_h, "vp1_target", vp_1);
  p->addPointCloud (cloud_source, src_h, "vp1_source", vp_1);//添加点云到窗口
  PCL_INFO ("Press q to begin the registration.\n");
  p-> spin();//spin()会打开交互式窗口，并阻塞程序。用户可以用鼠标旋转、缩放、平移视图。只有按下q或关闭窗口，程序才会继续执行
}
////////////////////////////////////////////////////////////////////////////////


void showCloudsRight(const PointCloudWithNormals::Ptr cloud_target, const PointCloudWithNormals::Ptr cloud_source)
{
  p->removePointCloud ("source");
  p->removePointCloud ("target");//把旧的点云移除
  PointCloudColorHandlerGenericField<PointNormalT> tgt_color_handler (cloud_target, "curvature");//给目标点云定义颜色句柄：使用点云中 "curvature" 字段（曲率值）进行着色
  //先在点云里找到 "curvature" 字段。
  // 找出该字段的 最小值 和 最大值。
  // 把曲率值按区间 [min, max] 归一化到 [0, 255]
  if (!tgt_color_handler.isCapable ())
      PCL_WARN ("Cannot create curvature color handler!");
  PointCloudColorHandlerGenericField<PointNormalT> src_color_handler (cloud_source, "curvature");
  if (!src_color_handler.isCapable ())//检查点云颜色处理器（ColorHandler）是否能正常工作
      PCL_WARN ("Cannot create curvature color handler!");
  p->addPointCloud (cloud_target, tgt_color_handler, "target", vp_2);
  p->addPointCloud (cloud_source, src_color_handler, "source", vp_2);//添加点云
  p->spinOnce();
}
////////////////////////////////////////////////////////////////////////////////

void loadData (int argc, char **argv, std::vector<PCD, Eigen::aligned_allocator<PCD> > &models)
//std::vector<PCD, Eigen::aligned_allocator<PCD>> 是一个专门为 Eigen 内存对齐优化的点云容器
{
  std::string extension (".pcd");

  for (int i = 1; i < argc; i++)
  {
    std::string fname = std::string (argv[i]);//取出文件名

    if (fname.size () <= extension.size ())//文件名错误
      continue;
    std::transform (fname.begin (), fname.end (), fname.begin ()/*表示结果写回原字符串*/, (int(*)(int))tolower/*返回对应小写字符*/);// 把文件名统一转成小写，避免 .PCD / .Pcd / .pcd 区分大小写问题

    if (fname.compare (fname.size () - extension.size ()/*从字符串倒数第N个字符开始比较*/, extension.size ()/*比较长度*/, extension/*目标后缀*/) == 0)
    {
      PCD m;
      m.f_name = argv[i];
      pcl::io::loadPCDFile (argv[i], *m.cloud);
 
      std::vector<int> indices;
      pcl::removeNaNFromPointCloud(*m.cloud,*m.cloud, indices);//删除nan点
      models.push_back (m);//存储处理后的点云
    }
  }
}

void pairAlign (const PointCloud::Ptr cloud_src, const PointCloud::Ptr cloud_tgt, PointCloud::Ptr output, Eigen::Matrix4f &final_transform, bool downsample = false/*默认f，但是用函数时可以显式传入true，那就是true*/)
{
  PointCloud::Ptr src (new PointCloud);
  PointCloud::Ptr tgt (new PointCloud);
  pcl::VoxelGrid<PointT> grid;
  if (downsample)
  {
    grid.setLeafSize (0.05, 0.05, 0.05);//利用体素网格进行采样
    grid.setInputCloud (cloud_src);
    grid.filter (*src);
    grid.setInputCloud (cloud_tgt);
    grid.filter (*tgt);
  }
  else
  {
    src = cloud_src;
    tgt = cloud_tgt;
  }

  PointCloudWithNormals::Ptr points_with_normals_src (new PointCloudWithNormals);
  PointCloudWithNormals::Ptr points_with_normals_tgt (new PointCloudWithNormals);
  pcl::NormalEstimation<PointT, PointNormalT> norm_est;
  pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ> ());
  norm_est.setSearchMethod (tree);
  norm_est.setKSearch (30);
  norm_est.setInputCloud (src);
  norm_est.compute (*points_with_normals_src);//计算法线，曲率，默认坐标可能是 (0,0,0)，是不带坐标信息的，但是是和原始点云一一对应的
  pcl::copyPointCloud (*src, *points_with_normals_src);//把原始点云坐标拷贝到带法线点云中，确保每个点同时拥有 位置 + 法线 + 曲率
  norm_est.setInputCloud (tgt);
  norm_est.compute (*points_with_normals_tgt);
  pcl::copyPointCloud (*tgt, *points_with_normals_tgt);
  
  MyPointRepresentation point_representation;

  float alpha[4] = {1.0, 1.0, 1.0, 1.0};
  point_representation.setRescaleValues (alpha);//给四个系数设置权重（RescaleValues）

  pcl::IterativeClosestPointNonLinear<PointNormalT, PointNormalT> reg;//非线性ICP
  reg.setTransformationEpsilon (1e-6);//收敛条件之一：当变换矩阵变化量 < 1e-6 时停止迭代

  reg.setMaxCorrespondenceDistance (0.1);//最近邻对应点的最大距离阈值 = 0.1m。超过这个距离的点对会被忽略，避免错误匹配

  reg.setPointRepresentation (boost::make_shared<const MyPointRepresentation> (point_representation));//这样ICP在找对应点时，就会调用你重写的copyToFloatArray，把点转成 <x,y,z,curvature> 向量，再去算距离
  reg.setInputCloud (points_with_normals_src);//输入原始点云
  reg.setInputTarget (points_with_normals_tgt);//输入目标点云

  Eigen::Matrix4f Ti = Eigen::Matrix4f::Identity (), prev, targetToSource;
  PointCloudWithNormals::Ptr reg_result = points_with_normals_src;
  reg.setMaximumIterations (2);//每次 reg.align 只迭代 2 步，然后返回
  for (int i = 0; i < 30; ++i)
  {
    PCL_INFO ("Iteration Nr. %d.\n", i);
    points_with_normals_src = reg_result;
    reg.setInputCloud (points_with_normals_src);
    reg.align (*reg_result);//对齐一次

    Ti = reg.getFinalTransformation () * Ti;
    //reg.getFinalTransformation()：这次迭代得到的 4×4 变换。
    //每次都左乘到 Ti 上，得到源点云相对于目标点云的 累计全局变换

    if (fabs ((reg.getLastIncrementalTransformation () - prev).sum ())/*.sum() 会把矩阵的 16 个元素全部加起来，得到一个标量*/ < reg.getTransformationEpsilon ()/*收敛阈值*/)
      reg.setMaxCorrespondenceDistance (reg.getMaxCorrespondenceDistance ()/*先获取当前最大对应距离*/ - 0.001);//调用 setMaxCorrespondenceDistance() 更新 ICP 的参数

      prev = reg.getLastIncrementalTransformation ();//上一轮迭代的增量变换

    showCloudsRight(points_with_normals_tgt, points_with_normals_src);
    //如果连续两轮的增量变换几乎一样，说明 ICP 算法已经不再“明显移动”源点云，进入收敛阶段，每次收敛判据满足时，就把最大对应点距离逐渐缩小，让ICP匹配变得越来越精细
  }

  targetToSource = Ti.inverse();//源点云到目标点云的变换矩阵，再求逆

  pcl::transformPointCloud (*cloud_tgt, *output, targetToSource);//输出点云 output 就是 与源点云对齐的目标点云
  p->removePointCloud ("source");
  p->removePointCloud ("target");
  PointCloudColorHandlerCustom<PointT> cloud_tgt_h (output, 0, 255, 0);
  PointCloudColorHandlerCustom<PointT> cloud_src_h (cloud_src, 255, 0, 0);//颜色
  p->addPointCloud (output, cloud_tgt_h, "target", vp_2);
  p->addPointCloud (cloud_src, cloud_src_h, "source", vp_2);//添加点云
	PCL_INFO ("Press q to continue the registration.\n");
  p->spin ();
  p->removePointCloud ("source"); 
  p->removePointCloud ("target");//清除点云

  *output += *cloud_src;//追加点云
    final_transform = targetToSource;//保存或输出最终配准矩阵
 }

int main (int argc, char** argv)
{

  std::vector<PCD, Eigen::aligned_allocator<PCD> > data;
  loadData (argc, argv, data);//取出点云存在data

  if (data.empty ())
  {
    PCL_ERROR ("Syntax is: %s <source.pcd> <target.pcd> [*]", argv[0]);
    PCL_ERROR ("[*] - multiple files can be added. The registration results of (i, i+1) will be registered against (i+2), etc");
    PCL_INFO ("Example: %s `rospack find pcl`/test/bun0.pcd `rospack find pcl`/test/bun4.pcd", argv[0]);
    return (-1);
  }
  PCL_INFO ("Loaded %d datasets.", (int)data.size ());
 
  p = new pcl::visualization::PCLVisualizer (argc, argv, "Pairwise Incremental Registration example");
  p->createViewPort (0.0, 0, 0.5, 1.0, vp_1);
  p->createViewPort (0.5, 0, 1.0, 1.0, vp_2);//创建两个视口
	PointCloud::Ptr result (new PointCloud), source, target;
  //result → 最终配准结果点云
  // source → 当前配准的源点云
  // target → 当前配准的目标点云
  Eigen::Matrix4f GlobalTransform = Eigen::Matrix4f::Identity ()/*初始化单位矩阵，第一帧就是全局参考帧*/, pairTransform;
  //GlobalTransform → 存储全局累积变换，用于把多个点云配准到同一个坐标系
  //pairTransform → 存储当前源-目标配准的局部变换
    for (size_t i = 1; i < data.size (); ++i)
  {
    source = data[i-1].cloud;
    target = data[i].cloud;

    showCloudsLeft(source, target);//添加点云到窗口
    PointCloud::Ptr temp (new PointCloud);
    PCL_INFO ("Aligning %s (%d) with %s (%d).\n", data[i-1].f_name.c_str (), source->points.size (), data[i].f_name.c_str (), target->points.size ());
    pairAlign (source, target, temp/*output，合并后的点云*/, pairTransform/*配准矩阵*/, true);

    pcl::transformPointCloud (*temp, *result, GlobalTransform/*单位矩阵*/);//将合并后的点，并变换，存储到result
    GlobalTransform = pairTransform * GlobalTransform;

    std::stringstream ss;
    ss << "/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd_11.2/" << i << ".pcd";
    pcl::io::savePCDFile (ss.str (), *result, true);
  }
}

