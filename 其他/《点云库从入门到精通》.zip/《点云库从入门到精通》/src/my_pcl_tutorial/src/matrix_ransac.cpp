#include <fstream>
#include <iostream>
#include <pcl/console/parse.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/io/pcd_io.h>
#include <pcl/sample_consensus/ransac.h>
#include <pcl/sample_consensus/sac_model_sphere.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/passthrough.h>
#include <pcl/features/normal_3d.h>
#include <pcl/kdtree/kdtree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/common/transforms.h>
#include <pcl/common/transformation_from_correspondences.h>
#include <pcl/io/openni_grabber.h>
#include <boost/thread/thread.hpp>

class KinectViewer
{
public:
    KinectViewer(bool downsample) : viewer("KinectGrabber"), downsample_(downsample), global_(false) {}//构造函数

    void cloud_cb_(const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr& cloud)
    {
        // Step 1: 下采样 & 直通滤波
        pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud_filtered(new pcl::PointCloud<pcl::PointXYZRGB>);
        pcl::PassThrough<pcl::PointXYZRGB> pass;
        pass.setInputCloud(cloud);
        pass.setFilterFieldName("z");
        pass.setFilterLimits(0.0, 1.7);
        pass.filter(*cloud_filtered);
		//PassThrough 直通滤波：
		//过滤掉 z 方向（深度）不在 0~1.7 米 的点

        pcl::VoxelGrid<pcl::PointXYZRGB> vg;
        vg.setInputCloud(cloud_filtered);
        vg.setLeafSize(0.01f, 0.01f, 0.01f);
        vg.filter(*cloud_filtered);
        std::cout << "Filtered cloud has: " << cloud_filtered->size() << " points." << std::endl;
		// 将点云划分为 1cm³ 的体素 每个体素只保留一个点

        // Step 2: 平面分割
        pcl::SACSegmentation<pcl::PointXYZRGB> seg;
        seg.setOptimizeCoefficients(true);// setOptimizeCoefficients(true) → 优化平面参数，使拟合更精确
        seg.setModelType(pcl::SACMODEL_PLANE);// SACMODEL_PLANE → 拟合平面
        seg.setMethodType(pcl::SAC_RANSAC);//SACSegmentation 使用 RANSAC 拟合模型
        seg.setMaxIterations(100);// MaxIterations → 最大迭代次数
        seg.setDistanceThreshold(0.02);// DistanceThreshold → 点到模型距离阈值，小于该值视为内点

        pcl::PointIndices::Ptr inliers(new pcl::PointIndices);//inliers → 平面内点索引
        pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);//coefficients → 平面方程系数 [a, b, c, d]（ax+by+cz+d=0）
        seg.setInputCloud(cloud_filtered);
        seg.segment(*inliers, *coefficients);

        if (inliers->indices.empty())
        {
            std::cout << "No plane found." << std::endl;
        }
        else
        {
            std::cout << "Plane coefficients: " << *coefficients << std::endl;
        }

        // Step 3: 球体分割
        pcl::SACSegmentation<pcl::PointXYZRGB> seg_sphere;
        seg_sphere.setOptimizeCoefficients(true);//优化
        seg_sphere.setModelType(pcl::SACMODEL_SPHERE);//类型是球体
        seg_sphere.setMethodType(pcl::SAC_RANSAC);//使用 RANSAC 拟合模型
        seg_sphere.setMaxIterations(100);//最大迭代次数
        seg_sphere.setDistanceThreshold(0.01);//点到模型距离阈值

        pcl::PointIndices::Ptr inliers_sphere(new pcl::PointIndices);
        pcl::ModelCoefficients::Ptr coeff_sphere(new pcl::ModelCoefficients);
        seg_sphere.setInputCloud(cloud_filtered);
        seg_sphere.segment(*inliers_sphere, *coeff_sphere);//索引+参数

        if (inliers_sphere->indices.empty())
        {
            std::cout << "No sphere found." << std::endl;
        }
        else
        {
            std::cout << "Sphere coefficients: " << *coeff_sphere << std::endl;
        }

        // 可视化
        viewer.showCloud(cloud_filtered);
    }

    void run(const std::string& device_id)
    {
        pcl::Grabber* interface = new pcl::OpenNIGrabber(device_id);
		//pcl::Grabber 是 PCL 用于 实时抓取点云数据的基类
		//OpenNIGrabber 是其子类，用于 从 Kinect / OpenNI 设备抓取 RGB + Depth 点云
        boost::function<void(const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr&)> f =
        boost::bind(&KinectViewer::cloud_cb_, this, _1);//告诉 Grabber，每当抓到新点云时，调用 cloud_cb_ 进行处理
        boost::signals2::connection c = interface->registerCallback(f);//注册回调

        interface->start();//开启 Kinect 数据抓取线程
        while (!viewer.wasStopped())//保持主线程不退出，让 Grabber 和回调持续工作
        {
            boost::this_thread::sleep(boost::posix_time::milliseconds(100));
        }
        interface->stop();//停止 Kinect 数据抓取线程
    }
    pcl::visualization::CloudViewer viewer;
    bool downsample_;
    bool global_;
};

int main(int argc, char** argv)
{
    std::string device_id = "#1";
    if (argc >= 2)
        device_id = argv[1];

    KinectViewer v(false);
    v.run(device_id);

    return 0;
}
