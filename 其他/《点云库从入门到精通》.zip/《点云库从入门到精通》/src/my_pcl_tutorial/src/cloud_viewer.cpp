#include <pcl/visualization/cloud_viewer.h>
#include <iostream>
#include <pcl/io/io.h>
#include <pcl/io/pcd_io.h>
    
int user_data;
void viewerOneOff (pcl::visualization::PCLVisualizer& viewer)
{
    viewer.setBackgroundColor (1.0, 0.5, 1.0); // 设置背景颜色 (RGB: 粉紫色)
    pcl::PointXYZ o;
    o.x = 1.0;
    o.y = 0;
    o.z = 0;
    viewer.addSphere (o, 0.25, "sphere", 0);// 球心坐标 (1, 0, 0)，添加一个半径 0.25 的球体
    std::cout << "i only run once" << std::endl;
    
}
    
void viewerPsycho (pcl::visualization::PCLVisualizer& viewer)//循环回调函数
{
    static unsigned count = 0;// 静态变量，记录调用次数
    std::stringstream ss;
    ss << "Once per viewer loop: " << count++;
    viewer.removeShape ("text", 0); // 删除上一次的文字，text，形状 ID（任意字符串，但必须唯一才能不覆盖其他元素），一般用 0 表示默认视口
    viewer.addText (ss.str(), 200, 300, "text", 0);// 添加新文字，一般用 0 表示默认视口
    //FIXME: possible race condition here:
    user_data++;
}
    
int main ()
{
    pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZRGBA>);
    pcl::io::loadPCDFile ("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/maize.pcd", *cloud);//读取点云
    pcl::visualization::CloudViewer viewer("Cloud Viewer");    
    
    viewer.showCloud(cloud);
    
    viewer.runOnVisualizationThreadOnce (viewerOneOff);//执行一次（第一次渲染前调用）,用来做一次性的可视化设置
    
    viewer.runOnVisualizationThread (viewerPsycho);//每一帧渲染循环都会执行（类似游戏引擎里的 update()）,用来动态更新可视化内容
    while (!viewer.wasStopped ())//主线程循环（可在这里处理数据或计算）
    {
    
    user_data++;
    }
    return 0;
}
