//跑不通，跑不通，一直段错误，不科学
#include <iostream>
#include <boost/thread/thread.hpp>
#include <pcl/range_image/range_image.h>
#include <pcl/io/pcd_io.h>
#include <pcl/visualization/range_image_visualizer.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/features/range_image_border_extractor.h>
#include <pcl/keypoints/narf_keypoint.h>
#include <pcl/console/parse.h>
#include <pcl/filters/filter.h>

typedef pcl::PointXYZ PointType;

float angular_resolution = 0.5f;
float support_size = 0.2f;
pcl::RangeImage::CoordinateFrame coordinate_frame = pcl::RangeImage::CAMERA_FRAME;
bool setUnseenToMaxRange = false;

void printUsage(const char* progName)
{
    std::cout << "\n\nUsage: " << progName << " [options] <scene.pcd>\n\n"
              << "Options:\n"
              << "-------------------------------------------\n"
              << "-r <float>   angular resolution in degrees (default " << angular_resolution << ")\n"
              << "-c <int>     coordinate frame (default " << (int)coordinate_frame << ")\n"
              << "-m           Treat all unseen points as maximum range readings\n"
              << "-s <float>   support size for the interest points (diameter of the used sphere - "
              << "default " << support_size << ")\n"
              << "-h           this help\n"
              << "\n\n";
}

void setViewerPose(pcl::visualization::PCLVisualizer& viewer, const Eigen::Affine3f& viewer_pose)
{
    Eigen::Vector3f pos_vector = viewer_pose * Eigen::Vector3f(0,0,0);//把相机坐标系的原点 变换到世界坐标，pos_vector 就是相机在世界坐标中的位置
    Eigen::Vector3f look_at_vector = viewer_pose.rotation() * Eigen::Vector3f(0,0,1) + pos_vector;
    //viewer_pose.rotation() 取出旋转矩阵，[0,0,1] 是相机坐标系的 +Z 轴，把这个方向旋到世界坐标，得到世界中的前向方向 。。。。将它加到相机位置上（相当于沿前向 1 个长度单位）得到视点
    Eigen::Vector3f up_vector = viewer_pose.rotation() * Eigen::Vector3f(0,-1,0);//把这个方向旋到世界坐标，得到世界中的 view-up 向量。VTK 会用它来确定画面“顶部”的方向，因为在相机坐标系y是向下的

    viewer.setCameraPosition(//不要求向量单位长度；VTK 内部会做归一化，但最好保持 up 与 (look - eye) 不共线
        pos_vector[0], pos_vector[1], pos_vector[2],//相机的世界坐标
        look_at_vector[0], look_at_vector[1], look_at_vector[2],//视点
        up_vector[0], up_vector[1], up_vector[2]//上方向
    );//喂给可视化器
}

int main (int argc, char** argv)
{
    if (pcl::console::find_argument(argc, argv, "-h") >= 0)
    {
        printUsage(argv[0]);
        return 0;
    }
    if (pcl::console::find_argument(argc, argv, "-m") >= 0)
    {
        setUnseenToMaxRange = true;
        std::cout << "Setting unseen values in range image to maximum range readings.\n";
    }

    int tmp_coordinate_frame;
    if (pcl::console::parse(argc, argv, "-c", tmp_coordinate_frame) >= 0)
    {
        coordinate_frame = pcl::RangeImage::CoordinateFrame(tmp_coordinate_frame);
        std::cout << "Using coordinate frame " << (int)coordinate_frame << ".\n";
    }
    if (pcl::console::parse(argc, argv, "-s", support_size) >= 0)
        std::cout << "Setting support size to " << support_size << ".\n";
    if (pcl::console::parse(argc, argv, "-r", angular_resolution) >= 0)
        std::cout << "Setting angular resolution to " << angular_resolution << " deg.\n";

    angular_resolution = pcl::deg2rad(angular_resolution);//把角度单位的数值转为弧度单位

    // 加载点云
    pcl::PointCloud<PointType>::Ptr point_cloud_ptr(new pcl::PointCloud<PointType>);
    pcl::PointCloud<PointType>& point_cloud = *point_cloud_ptr;
    pcl::PointCloud<pcl::PointWithViewpoint> far_ranges;//PointWithViewpoint 是一种特殊点类型，存储点坐标 + 传感器位置
    Eigen::Affine3f scene_sensor_pose(Eigen::Affine3f::Identity());
    // Affine3f 表示一个 3D 仿射变换矩阵（包含旋转 + 平移）
    // 默认设为单位矩阵，即传感器位姿在原点

    std::vector<int> pcd_filename_indices = pcl::console::parse_file_extension_argument(argc, argv, "pcd");
    //解析命令行参数，找出所有以 .pcd 结尾的文件索引。
    //返回值是 索引数组（比如 [1] 表示 argv[1] 是 pcd 文件）
    if (!pcd_filename_indices.empty())
    {
        std::string filename = argv[pcd_filename_indices[0]];
        if (pcl::io::loadPCDFile(filename, point_cloud) == -1)
        {
            std::cerr << "Was not able to open file \"" << filename << "\".\n";
            printUsage(argv[0]);
            return 0;
        }
        scene_sensor_pose = Eigen::Affine3f(Eigen::Translation3f(point_cloud.sensor_origin_[0],
                                                                 point_cloud.sensor_origin_[1],
                                                                 point_cloud.sensor_origin_[2])) *
                            Eigen::Affine3f(point_cloud.sensor_orientation_);//点云文件里存的 传感器位姿信息
        std::string far_ranges_filename = pcl::getFilenameWithoutExtension(filename) + "_far_ranges.pcd";
        if (pcl::io::loadPCDFile(far_ranges_filename.c_str(), far_ranges) == -1)//PCL 的 RangeImage 支持加载一个 _far_ranges.pcd 文件，里面存放超出范围的点。如果存在，补充到 RangeImage；如果没有，就打印一句提示
            std::cout << "Far ranges file \"" << far_ranges_filename << "\" does not exist.\n";
    }
    else
    {
        setUnseenToMaxRange = true;
        std::cout << "\nNo *.pcd file given => Generating example point cloud.\n\n";
        for (float x=-0.5f; x<=0.5f; x+=0.01f)
        {
            for (float y=-0.5f; y<=0.5f; y+=0.01f)
            {
                PointType point; point.x = x; point.y = y; point.z = 2.0f-y;
                point_cloud.points.push_back(point);
            }
        }
        point_cloud.width = (int)point_cloud.points.size(); point_cloud.height = 1;//自己造点云
    }

    // 生成深度图
    float noise_level = 0.0;
    float min_range = 0.0f;
    int border_size = 1;
    pcl::RangeImage::Ptr range_image_ptr(new pcl::RangeImage);
    pcl::RangeImage& range_image = *range_image_ptr;

    range_image.createFromPointCloud(point_cloud, angular_resolution,//把点云投影成一个 2D 深度图（range image）
                                     pcl::deg2rad(360.0f), pcl::deg2rad(180.0f),
                                     scene_sensor_pose, coordinate_frame,
                                     noise_level, min_range, border_size);
    //point_cloud：点云（来自 pcd 或合成的）。
    // angular_resolution：角分辨率（一般 0.5° ~ 1°）。
    // 360°, 180°：水平/垂直视场角。
    // scene_sensor_pose：传感器位姿（前面算好的）。
    // coordinate_frame：坐标系（一般 pcl::RangeImage::CAMERA_FRAME）。
    // noise_level, min_range, border_size：前面定义的参数。
    range_image.integrateFarRanges(far_ranges);//融合 _far_ranges.pcd 里的超远点
    if (setUnseenToMaxRange)
        range_image.setUnseenToMaxRange();//把未观测到的像素设为最大深度，而不是 NaN，这样方便可视化

    // 3D 可视化
    pcl::visualization::PCLVisualizer viewer("3D Viewer");
    viewer.setBackgroundColor(1, 1, 1);
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointWithRange>
        range_image_color_handler(range_image_ptr, 0, 0, 0);//自定义颜色（黑色）
    viewer.addPointCloud(range_image_ptr, range_image_color_handler, "range image");
    viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "range image");
    viewer.initCameraParameters();//初始化相机参数
    setViewerPose(viewer, range_image.getTransformationToWorldSystem());//把相机摆到合适位置
    //range_image.getTransformationToWorldSystem()它返回一个 Eigen::Affine3f（齐次变换矩阵，4x4），描述了 RangeImage 的坐标系 → 世界坐标系 的变换。
    //是一个 完整的位姿（旋转 + 平移），描述坐标系之间的关系
    // 显示 range image
    pcl::visualization::RangeImageVisualizer range_image_widget("Range image");
    range_image_widget.showRangeImage(range_image);

//-----------------------------------------------------------
    float max_range = 10000.0f;  // RangeImage 自带的最大测距

    for (size_t i = 0; i < range_image.points.size(); ++i) {
    if (!pcl::isFinite(range_image.points[i])) {
        // 设置成一个极远点（例如 z=max_range，其余设0）
        range_image.points[i].x = 0.0f;
        range_image.points[i].y = 0.0f;
        range_image.points[i].z = max_range;
        range_image.points[i].range = max_range;
    }
}

//-----------------------------------------------------------
    std::cout << "RangeImage size: " << range_image.width 
          << " x " << range_image.height 
          << " (" << range_image.points.size() << " points)" << std::endl;

    if (range_image.width == 0 || range_image.height == 0 || range_image.points.empty()) {
        std::cerr << "Invalid range image! Skipping border extraction." << std::endl;
        return -1;
    }

    // 检查是不是有 NaN
    for (size_t i = 0; i < range_image.points.size(); ++i) {
        if (!pcl::isFinite(range_image.points[i])) {
            std::cerr << "Found invalid point at " << i << std::endl;
            return -1;
        }
    }
//-----------------------------------------------------------------
//RangeImage 里一上来就有无效点 (NaN/Inf)，所以一旦 RangeImageBorderExtractor 访问它，就直接段错误。我丢找好久错误

    // 提取 NARF 关键点
    pcl::RangeImageBorderExtractor range_image_border_extractor;//提取边界信息（用于找关键点）
    
    pcl::NarfKeypoint narf_keypoint_detector(&range_image_border_extractor);//NARF 特征关键点检测器
    
    narf_keypoint_detector.setRangeImage(&range_image);//输入 range image
    narf_keypoint_detector.getParameters().support_size = support_size;//搜索半径，决定关键点邻域大小
    
    pcl::PointCloud<int> keypoint_indices;
    std::cout << "RangeImage points: " << range_image.points.size() << std::endl;
    std::cout << "Width: " << range_image.width << " Height: " << range_image.height << std::endl;

    narf_keypoint_detector.compute(keypoint_indices);//输出关键点索引（哪些点是关键点）
    std::cerr << "111111" << std::endl;
    //输出的是 int，即关键点在 range_image.points 里的下标
    std::cout << "Found " << keypoint_indices.points.size() << " key points.\n";

    pcl::PointCloud<pcl::PointXYZ>::Ptr keypoints_ptr(new pcl::PointCloud<pcl::PointXYZ>);//创建一个空的点云指针 keypoints_ptr，存储类型是 pcl::PointXYZ（只包含 x,y,z）。NARF 关键点检测返回的只是点的 索引，这里需要新建一个点云来存储这些关键点的位置。
    pcl::PointCloud<pcl::PointXYZ>& keypoints = *keypoints_ptr;
    keypoints.points.resize(keypoint_indices.points.size());//先给点云分配这么多个点的空间
    for (size_t i=0; i<keypoint_indices.points.size(); ++i)//NARF 给出的只是 索引，这里根据索引把点拷贝出来，转成普通 PointXYZ 点云
    {

        int idx = keypoint_indices.points[i];
        if (idx < 0 || idx >= (int)range_image.points.size()) {
            std::cerr << "Invalid index: " << idx << std::endl;
            continue;
        }
        if (!pcl::isFinite(range_image.points[idx])) {
            std::cerr << "Skipping NaN keypoint at " << idx << std::endl;
            continue;
        }
        std::cout << "Processing keypoint index: " << idx << std::endl;
        keypoints.points[i].getVector3fMap() =range_image.points[idx].getVector3fMap();

        // if (keypoint_indices.points[i] >= range_image.points.size()) {
        // std::cerr << "Invalid keypoint index: " << keypoint_indices.points[i]
        //           << " (range_image size = " << range_image.points.size() << ")\n";
        // continue;  // 跳过非法索引
        // }
        // keypoints.points[i].getVector3fMap() = range_image.points[keypoint_indices.points[i]].getVector3fMap();//把每个关键点对应点云的三维坐标拷贝到 keypoints 点云里
        //getVector3fMap()，Eigen 风格的接口，把点的 (x,y,z) 作为 Eigen::Vector3f 返回
    }
        
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ>
        keypoints_color_handler(keypoints_ptr, 0, 255, 0);//绿色
    viewer.addPointCloud<pcl::PointXYZ>(keypoints_ptr, keypoints_color_handler, "keypoints");//keypoints_ptr存储的是关键点
    viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 7, "keypoints");
    //设置点云的渲染属性。PCL_VISUALIZER_POINT_SIZE 控制点的大小。这里设成了 7，比普通点大很多，这样关键点能在三维视图里一眼就看出来

    // 主循环
    while (!viewer.wasStopped())
    {
        range_image_widget.spinOnce(); // process GUI events
        viewer.spinOnce();
        pcl_sleep(0.01);
    }
}
