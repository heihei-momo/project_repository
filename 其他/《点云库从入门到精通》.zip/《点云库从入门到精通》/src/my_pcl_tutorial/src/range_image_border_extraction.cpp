//跑不通，一直段错误，不科学
#include <iostream>
#include <boost/thread/thread.hpp>
#include <pcl/range_image/range_image.h>
#include <pcl/io/pcd_io.h>
#include <pcl/visualization/range_image_visualizer.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/features/range_image_border_extractor.h>
#include <pcl/console/parse.h>
typedef pcl::PointXYZ PointType;

float angular_resolution = 0.5f;// 角分辨率(度)
pcl::RangeImage::CoordinateFrame coordinate_frame = pcl::RangeImage::CAMERA_FRAME;
bool setUnseenToMaxRange = false;// 是否把不可见点设为最大深度

void 
printUsage (const char* progName)
{
  std::cout << "\n\nUsage: "<<progName<<" [options] <scene.pcd>\n\n"
            << "Options:\n"
            << "-------------------------------------------\n"
            << "-r <float>   angular resolution in degrees (default "<<angular_resolution<<")\n"
            << "-c <int>     coordinate frame (default "<< (int)coordinate_frame<<")\n"
            << "-m           Treat all unseen points to max range\n"
            << "-h           this help\n"
            << "\n\n";
}

int 
main (int argc, char** argv)
{

  if (pcl::console::find_argument (argc, argv, "-h") >= 0)//pcl::console::find_argument作用：检查某个命令行参数（flag / 开关）是否存在。返回值：返回该参数在 argv 中的位置索引，如果不存在则返回 -1
  {
    printUsage (argv[0]);
    return 0;
  }
  if (pcl::console::find_argument (argc, argv, "-m") >= 0)
  {
    setUnseenToMaxRange = true;
    cout << "Setting unseen values in range image to maximum range readings.\n";
  }
  int tmp_coordinate_frame;
  if (pcl::console::parse (argc, argv, "-c", tmp_coordinate_frame) >= 0)//pcl::console::parse作用：解析某个参数后面跟随的数值，并将其赋值给变量。返回值：返回成功解析的参数个数（通常是 1），如果没解析到则返回 0
  {
    coordinate_frame = pcl::RangeImage::CoordinateFrame (tmp_coordinate_frame);
    cout << "Using coordinate frame "<< (int)coordinate_frame<<".\n";
  }
  if (pcl::console::parse (argc, argv, "-r", angular_resolution) >= 0)
    cout << "Setting angular resolution to "<<angular_resolution<<"deg.\n";
  angular_resolution = pcl::deg2rad (angular_resolution);

  pcl::PointCloud<PointType>::Ptr point_cloud_ptr (new pcl::PointCloud<PointType>);
  pcl::PointCloud<PointType>& point_cloud = *point_cloud_ptr;
  pcl::PointCloud<pcl::PointWithViewpoint> far_ranges;//PointWithViewpoint 结构包含 点坐标 + 传感器观测位置。far_ranges 通常用于保存 超出主点云范围的稀疏点
  Eigen::Affine3f scene_sensor_pose (Eigen::Affine3f::Identity ());//定义一个 传感器位姿矩阵，默认是单位矩阵
  std::vector<int> pcd_filename_indices = pcl::console::parse_file_extension_argument (argc, argv, "pcd");//parse_file_extension_argument 会从命令行参数 argv 中找到 所有以 .pcd 结尾的文件，并返回它们在 argv 中的索引
  if (!pcd_filename_indices.empty ())
  {
    std::string filename = argv[pcd_filename_indices[0]];
    if (pcl::io::loadPCDFile (filename, point_cloud) == -1)
    {
      cout << "Was not able to open file \""<<filename<<"\".\n";
      printUsage (argv[0]);
      return 0;
    }
    scene_sensor_pose = Eigen::Affine3f (Eigen::Translation3f (point_cloud.sensor_origin_[0],point_cloud.sensor_origin_[1],point_cloud.sensor_origin_[2])) *Eigen::Affine3f (point_cloud.sensor_orientation_);
    //设置传感器位姿
    //从点云头部信息（.sensor_origin_ 和 .sensor_orientation_）提取扫描时的传感器位置和方向。
    //Translation3f提供平移，sensor_orientation_提供旋转。
    //最终得到scene_sensor_pose，表示传感器在世界坐标中的位姿
    std::string far_ranges_filename = pcl::getFilenameWithoutExtension (filename)+"_far_ranges.pcd";
    //pcl::getFilenameWithoutExtension (filename)
    // 输入 "table_scene_lms400.pcd"
    // 输出 "table_scene_lms400"
    // 就是把文件扩展名（.pcd）去掉，保留主文件名
    if (pcl::io::loadPCDFile(far_ranges_filename.c_str(), far_ranges) == -1)
      std::cout << "Far ranges file \""<<far_ranges_filename<<"\" does not exists.\n";
  }
  else
  {
    cout << "\nNo *.pcd file given => Genarating example point cloud.\n\n";
    for (float x=-0.5f; x<=0.5f; x+=0.01f)
    {
      for (float y=-0.5f; y<=0.5f; y+=0.01f)
      {
        PointType point;  point.x = x;  point.y = y;  point.z = 2.0f - y;
        point_cloud.points.push_back (point);
      }
    }
    point_cloud.width = (int) point_cloud.points.size ();  point_cloud.height = 1;
  }

  float noise_level = 0.0;
  float min_range = 0.0f;
  int border_size = 1;
  boost::shared_ptr<pcl::RangeImage> range_image_ptr (new pcl::RangeImage);
  pcl::RangeImage& range_image = *range_image_ptr;   
  range_image.createFromPointCloud (point_cloud, angular_resolution, pcl::deg2rad (360.0f), pcl::deg2rad (180.0f), scene_sensor_pose, coordinate_frame, noise_level, min_range, border_size);
  range_image.integrateFarRanges (far_ranges);//如果你有单独存储的 远距离点云（比如 _far_ranges.pcd），可以把它合并到 RangeImage 中，保证远距离点不会丢失
  if (setUnseenToMaxRange)
    range_image.setUnseenToMaxRange ();

  pcl::visualization::PCLVisualizer viewer ("3D Viewer");
  viewer.setBackgroundColor (1, 1, 1);
  viewer.addCoordinateSystem (1.0f);// 添加坐标轴
  pcl::visualization::PointCloudColorHandlerCustom<PointType> point_cloud_color_handler (point_cloud_ptr, 0, 0, 0);//PCL 中点云可视化需要“颜色处理器”，告诉 viewer 每个点怎么上色。PointCloudColorHandlerCustom 会给所有点统一颜色。(0,0,0) → 黑色。
  viewer.addPointCloud (point_cloud_ptr, point_cloud_color_handler, "original point cloud");
  //iewer.addPointCloud(...)
  // 第一个参数：点云指针。
  // 第二个参数：颜色处理器。
  // 第三个参数：点云的 ID 名字，用来在后续更新/删除时标识


  
  pcl::RangeImageBorderExtractor border_extractor (&range_image);
  pcl::PointCloud<pcl::BorderDescription> border_descriptions;
  border_extractor.compute (border_descriptions);
  //RangeImageBorderExtractor：输入 RangeImage，计算每个像素点的边界信息。
  // border_descriptions：保存每个点的边界分类结果

  pcl::PointCloud<pcl::PointWithRange>::Ptr border_points_ptr(new pcl::PointCloud<pcl::PointWithRange>), veil_points_ptr(new pcl::PointCloud<pcl::PointWithRange>), shadow_points_ptr(new pcl::PointCloud<pcl::PointWithRange>);
  //border_points → 障碍物边界点
  // veil_points → “面纱点”（RangeImage 中遮挡过渡的点）
  // shadow_points → 阴影边界点（遮挡后不可见区域的边界）
  pcl::PointCloud<pcl::PointWithRange>& border_points = *border_points_ptr, & veil_points = * veil_points_ptr, & shadow_points = *shadow_points_ptr;
  for (int y=0; y< (int)range_image.height; ++y)
  {
    for (int x=0; x< (int)range_image.width; ++x)
    {
      if (border_descriptions.points[y*range_image.width + x].traits[pcl::BORDER_TRAIT__OBSTACLE_BORDER])
        border_points.points.push_back (range_image.points[y*range_image.width + x]);
      if (border_descriptions.points[y*range_image.width + x].traits[pcl::BORDER_TRAIT__VEIL_POINT])
        veil_points.points.push_back (range_image.points[y*range_image.width + x]);
      if (border_descriptions.points[y*range_image.width + x].traits[pcl::BORDER_TRAIT__SHADOW_BORDER])
        shadow_points.points.push_back (range_image.points[y*range_image.width + x]);
    }
  }
  //遍历 RangeImage 的所有像素点 (x,y)。通过 border_descriptions 判断该点属于哪种边界。对应的点放到不同的点云里

  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointWithRange> border_points_color_handler (border_points_ptr, 0, 255, 0);
  viewer.addPointCloud<pcl::PointWithRange> (border_points_ptr, border_points_color_handler, "border points");
  viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 7, "border points");

  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointWithRange> veil_points_color_handler (veil_points_ptr, 255, 0, 0);
  viewer.addPointCloud<pcl::PointWithRange> (veil_points_ptr, veil_points_color_handler, "veil points");
  viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 7, "veil points");

  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointWithRange> shadow_points_color_handler (shadow_points_ptr, 0, 255, 255);
  viewer.addPointCloud<pcl::PointWithRange> (shadow_points_ptr, shadow_points_color_handler, "shadow points");
  viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 7, "shadow points");

  pcl::visualization::RangeImageVisualizer* range_image_borders_widget = NULL;//定义一个 RangeImageVisualizer 的指针，用来显示 2D 的深度图
  range_image_borders_widget =
    pcl::visualization::RangeImageVisualizer::getRangeImageBordersWidget (range_image, -std::numeric_limits<float>::infinity (), std::numeric_limits<float>::infinity (), false, border_descriptions, "Range image with borders" );                     
  //range_image
  // 输入的深度图（由点云生成的 RangeImage）。
  // -std::numeric_limits<float>::infinity()
  // 最小深度阈值，这里设为 -∞，表示不过滤
  // std::numeric_limits<float>::infinity()
  // 最大深度阈值，这里设为 +∞，同样表示不过滤。
  // 这两个参数可以限制可视化的深度范围，比如 0.5, 5.0 就只显示 0.5m 到 5m 的深度。
  // false 是否以灰度显示强度图像，这里是 false，只显示深度 + 边界。
  // border_descriptions边界分类结果（由 RangeImageBorderExtractor 计算得到）。在图像上会用不同颜色标记边界（障碍物边界、veil、shadow）。
  // "Range image with borders"窗口的标题。
  while (!viewer.wasStopped ())
  {
    range_image_borders_widget->spinOnce ();
    viewer.spinOnce ();
    pcl_sleep(0.01);
  }
}
