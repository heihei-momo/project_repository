#include <pcl/io/pcd_io.h>
#include <pcl/point_cloud.h>
#include <pcl/correspondence.h>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/features/shot_omp.h>
#include <pcl/features/board.h>
#include <pcl/keypoints/uniform_sampling.h>
#include <pcl/recognition/cg/hough_3d.h>
#include <pcl/recognition/cg/geometric_consistency.h>
#include <pcl/recognition/hv/hv_go.h>
#include <pcl/registration/icp.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/kdtree/impl/kdtree_flann.hpp>
#include <pcl/common/transforms.h> 
#include <pcl/console/parse.h>

typedef pcl::PointXYZRGBA PointType;
typedef pcl::Normal NormalType;
typedef pcl::ReferenceFrame RFType;
typedef pcl::SHOT352 DescriptorType;

struct CloudStyle
{
    double r;
    double g;
    double b;
    double size;

    CloudStyle (double r,
                double g,
                double b,
                double size) :
        r (r),
        g (g),
        b (b),
        size (size)
    {
    }
};

CloudStyle style_white (255.0, 255.0, 255.0, 4.0);
CloudStyle style_red (255.0, 0.0, 0.0, 3.0);
CloudStyle style_green (0.0, 255.0, 0.0, 5.0);
CloudStyle style_cyan (93.0, 200.0, 217.0, 4.0);
CloudStyle style_violet (255.0, 0.0, 255.0, 8.0);

std::string model_filename_;
std::string scene_filename_;

//Algorithm params 
bool show_keypoints_ (false);
bool use_hough_ (true);
float model_ss_ (0.02f);
float scene_ss_ (0.02f);
float rf_rad_ (0.015f);
float descr_rad_ (0.02f);
float cg_size_ (0.01f);
float cg_thresh_ (5.0f);
int icp_max_iter_ (5);
float icp_corr_distance_ (0.005f);
float hv_clutter_reg_ (5.0f);
float hv_inlier_th_ (0.005f);
float hv_occlusion_th_ (0.01f);
float hv_rad_clutter_ (0.03f);
float hv_regularizer_ (3.0f);
float hv_rad_normals_ (0.05);
bool hv_detect_clutter_ (true);

/**
 * Prints out Help message
 * @param filename Runnable App Name
 */
void
showHelp (char *filename)
{
  std::cout << std::endl;
  std::cout << "***************************************************************************" << std::endl;
  std::cout << "*                                                                         *" << std::endl;
  std::cout << "*          Global Hypothese Verification Tutorial - Usage Guide          *" << std::endl;
  std::cout << "*                                                                         *" << std::endl;
  std::cout << "***************************************************************************" << std::endl << std::endl;
  std::cout << "Usage: " << filename << " model_filename.pcd scene_filename.pcd [Options]" << std::endl << std::endl;
  std::cout << "Options:" << std::endl;
  std::cout << "     -h:                          Show this help." << std::endl;
  std::cout << "     -k:                          Show keypoints." << std::endl;
  std::cout << "     --algorithm (Hough|GC):      Clustering algorithm used (default Hough)." << std::endl;
  std::cout << "     --model_ss val:              Model uniform sampling radius (default " << model_ss_ << ")" << std::endl;
  std::cout << "     --scene_ss val:              Scene uniform sampling radius (default " << scene_ss_ << ")" << std::endl;
  std::cout << "     --rf_rad val:                Reference frame radius (default " << rf_rad_ << ")" << std::endl;
  std::cout << "     --descr_rad val:             Descriptor radius (default " << descr_rad_ << ")" << std::endl;
  std::cout << "     --cg_size val:               Cluster size (default " << cg_size_ << ")" << std::endl;
  std::cout << "     --cg_thresh val:             Clustering threshold (default " << cg_thresh_ << ")" << std::endl << std::endl;
  std::cout << "     --icp_max_iter val:          ICP max iterations number (default " << icp_max_iter_ << ")" << std::endl;
  std::cout << "     --icp_corr_distance val:     ICP correspondence distance (default " << icp_corr_distance_ << ")" << std::endl << std::endl;
  std::cout << "     --hv_clutter_reg val:        Clutter Regularizer (default " << hv_clutter_reg_ << ")" << std::endl;
  std::cout << "     --hv_inlier_th val:          Inlier threshold (default " << hv_inlier_th_ << ")" << std::endl;
  std::cout << "     --hv_occlusion_th val:       Occlusion threshold (default " << hv_occlusion_th_ << ")" << std::endl;
  std::cout << "     --hv_rad_clutter val:        Clutter radius (default " << hv_rad_clutter_ << ")" << std::endl;
  std::cout << "     --hv_regularizer val:        Regularizer value (default " << hv_regularizer_ << ")" << std::endl;
  std::cout << "     --hv_rad_normals val:        Normals radius (default " << hv_rad_normals_ << ")" << std::endl;
  std::cout << "     --hv_detect_clutter val:     TRUE if clutter detect enabled (default " << hv_detect_clutter_ << ")" << std::endl << std::endl;
}

/**
 * Parses Command Line Arguments (Argc,Argv)
 * @param argc
 * @param argv
 */
void
parseCommandLine (int argc,
                  char *argv[])
{
  //Show help
  if (pcl::console::find_switch (argc, argv, "-h"))
  {
    showHelp (argv[0]);
    exit (0);
  }

  //Model & scene filenames
  std::vector<int> filenames;
  filenames = pcl::console::parse_file_extension_argument (argc, argv, ".pcd");
  if (filenames.size () != 2)
  {
    std::cout << "Filenames missing.\n";
    showHelp (argv[0]);
    exit (-1);
  }

  model_filename_ = argv[filenames[0]];
  scene_filename_ = argv[filenames[1]];

  //Program behavior
  if (pcl::console::find_switch (argc, argv, "-k"))
  {
    show_keypoints_ = true;
  }

  std::string used_algorithm;
  if (pcl::console::parse_argument (argc, argv, "--algorithm", used_algorithm) != -1)
  {
    if (used_algorithm.compare ("Hough") == 0)
    {
      use_hough_ = true;
    }
    else if (used_algorithm.compare ("GC") == 0)
    {
      use_hough_ = false;
    }
    else
    {
      std::cout << "Wrong algorithm name.\n";
      showHelp (argv[0]);
      exit (-1);
    }
  }

  //General parameters
  pcl::console::parse_argument (argc, argv, "--model_ss", model_ss_);//查找要找的参数名，并存储解析结果
  pcl::console::parse_argument (argc, argv, "--scene_ss", scene_ss_);
  pcl::console::parse_argument (argc, argv, "--rf_rad", rf_rad_);
  pcl::console::parse_argument (argc, argv, "--descr_rad", descr_rad_);
  pcl::console::parse_argument (argc, argv, "--cg_size", cg_size_);
  pcl::console::parse_argument (argc, argv, "--cg_thresh", cg_thresh_);
  pcl::console::parse_argument (argc, argv, "--icp_max_iter", icp_max_iter_);
  pcl::console::parse_argument (argc, argv, "--icp_corr_distance", icp_corr_distance_);
  pcl::console::parse_argument (argc, argv, "--hv_clutter_reg", hv_clutter_reg_);
  pcl::console::parse_argument (argc, argv, "--hv_inlier_th", hv_inlier_th_);
  pcl::console::parse_argument (argc, argv, "--hv_occlusion_th", hv_occlusion_th_);
  pcl::console::parse_argument (argc, argv, "--hv_rad_clutter", hv_rad_clutter_);
  pcl::console::parse_argument (argc, argv, "--hv_regularizer", hv_regularizer_);
  pcl::console::parse_argument (argc, argv, "--hv_rad_normals", hv_rad_normals_);
  pcl::console::parse_argument (argc, argv, "--hv_detect_clutter", hv_detect_clutter_);
}

int main (int argc,char *argv[])
{
  parseCommandLine (argc, argv);

  pcl::PointCloud<PointType>::Ptr model (new pcl::PointCloud<PointType> ());
  pcl::PointCloud<PointType>::Ptr model_keypoints (new pcl::PointCloud<PointType> ());
  pcl::PointCloud<PointType>::Ptr scene (new pcl::PointCloud<PointType> ());
  pcl::PointCloud<PointType>::Ptr scene_keypoints (new pcl::PointCloud<PointType> ());
  pcl::PointCloud<NormalType>::Ptr model_normals (new pcl::PointCloud<NormalType> ());
  pcl::PointCloud<NormalType>::Ptr scene_normals (new pcl::PointCloud<NormalType> ());
  pcl::PointCloud<DescriptorType>::Ptr model_descriptors (new pcl::PointCloud<DescriptorType> ());
  pcl::PointCloud<DescriptorType>::Ptr scene_descriptors (new pcl::PointCloud<DescriptorType> ());

  /**
   * Load Clouds
   */
  if (pcl::io::loadPCDFile (model_filename_, *model) < 0)
  {
    std::cout << "Error loading model cloud." << std::endl;
    showHelp (argv[0]);
    return (-1);
  }
  if (pcl::io::loadPCDFile (scene_filename_, *scene) < 0)
  {
    std::cout << "Error loading scene cloud." << std::endl;
    showHelp (argv[0]);
    return (-1);
  }
//model和scene分别存储点云
  /**
   * Compute Normals
   */
  pcl::NormalEstimationOMP<PointType, NormalType> norm_est;
  norm_est.setKSearch (10);
  norm_est.setInputCloud (model);
  norm_est.compute (*model_normals);

  norm_est.setInputCloud (scene);
  norm_est.compute (*scene_normals);//计算法线

  /**
 *  Downsample Clouds to Extract keypoints
 */
  pcl::UniformSampling<PointType> uniform_sampling;//采样
  pcl::PointCloud<int> sampled_indices;

  // 处理 Model
  uniform_sampling.setInputCloud(model);
  uniform_sampling.setRadiusSearch(model_ss_);
  uniform_sampling.filter(*model_keypoints);//输出点云

  // 处理 Scene
  uniform_sampling.setInputCloud(scene);
  uniform_sampling.setRadiusSearch(scene_ss_);
  uniform_sampling.filter(*scene_keypoints);
  /**
   *  Compute Descriptor for keypoints
   */
  pcl::SHOTEstimationOMP<PointType, NormalType, DescriptorType> descr_est;
  descr_est.setRadiusSearch (descr_rad_);

  descr_est.setInputCloud (model_keypoints);//输入采样后的点云
  descr_est.setInputNormals (model_normals);//输入完整点云的法线
  descr_est.setSearchSurface (model);//完整点云
  descr_est.compute (*model_descriptors);//SHOT 描述子计算

  descr_est.setInputCloud (scene_keypoints);
  descr_est.setInputNormals (scene_normals);
  descr_est.setSearchSurface (scene);
  descr_est.compute (*scene_descriptors);//SHOT 描述子计算

  /**
   *  Find Model-Scene Correspondences with KdTree
   */
  pcl::CorrespondencesPtr model_scene_corrs (new pcl::Correspondences ());//存储 模型点云和场景点云之间的匹配关系
  pcl::KdTreeFLANN<DescriptorType> match_search;//建立 模型描述子点云的 KD 树
  match_search.setInputCloud (model_descriptors);//输入shot描述子
  std::vector<int> model_good_keypoints_indices;
  std::vector<int> scene_good_keypoints_indices;

  for (size_t i = 0; i < scene_descriptors->size (); ++i)//遍历场景描述子
  {
    std::vector<int> neigh_indices (1);
    std::vector<float> neigh_sqr_dists (1);
    if (!pcl_isfinite (scene_descriptors->at (i).descriptor[0]))  //跳过无效点
    {
      continue;
    }
    int found_neighs = match_search.nearestKSearch (scene_descriptors->at (i), 1, neigh_indices, neigh_sqr_dists);//对场景描述子 scene_descriptors->at(i) 找 最近的一个模型描述子
    //输出 neigh_indices[] 最近邻在模型点云中的索引, neigh_sqr_dists[] 最近邻的平方距离
    if (found_neighs == 1 && neigh_sqr_dists[0] < 0.25f)//如果找到了一个邻居而且，距离小于0.25  表示为可信
    {
      pcl::Correspondence corr (neigh_indices[0], static_cast<int> (i), neigh_sqr_dists[0]);//创建一个 Correspondence 对象  （最近邻在模型点云中的索引，场景点索引，最近邻的平方距离）
      model_scene_corrs->push_back (corr);//推入匹配关系
      model_good_keypoints_indices.push_back (corr.index_query);//模型点索引，就是neigh_indices[0]
      scene_good_keypoints_indices.push_back (corr.index_match);//场景点索引，就是i
    }
  }
  pcl::PointCloud<PointType>::Ptr model_good_kp (new pcl::PointCloud<PointType> ());
  pcl::PointCloud<PointType>::Ptr scene_good_kp (new pcl::PointCloud<PointType> ());
  pcl::copyPointCloud (*model_keypoints, model_good_keypoints_indices, *model_good_kp);//从原始的模型关键点 model_keypoints 中提取匹配成功的点（索引在 model_good_keypoints_indices 中），并存入 model_good_kp
  pcl::copyPointCloud (*scene_keypoints, scene_good_keypoints_indices, *scene_good_kp);//从 scene_keypoints 中提取索引为 scene_good_keypoints_indices 的点，生成新的点云 scene_good_kp

  std::cout << "Correspondences found: " << model_scene_corrs->size () << std::endl;

  /**
   *  Clustering
   */
  std::vector<Eigen::Matrix4f, Eigen::aligned_allocator<Eigen::Matrix4f> > rototranslations;//用于存储候选刚体变换矩阵（旋转+平移）
  std::vector < pcl::Correspondences > clustered_corrs;//用于存储每个变换矩阵对应的匹配点集

  if (use_hough_)//Hough3DGrouping方法
  {
    pcl::PointCloud<RFType>::Ptr model_rf (new pcl::PointCloud<RFType> ());
    pcl::PointCloud<RFType>::Ptr scene_rf (new pcl::PointCloud<RFType> ());

    pcl::BOARDLocalReferenceFrameEstimation<PointType, NormalType, RFType> rf_est;//配置LRF估计器
    rf_est.setFindHoles (true);//允许在局部几何不完整时仍尝试计算 LRF（避免 NaN）
    rf_est.setRadiusSearch (rf_rad_);//查找半径

    rf_est.setInputCloud (model_keypoints);//模型关键点
    rf_est.setInputNormals (model_normals);//完整点云的法线
    rf_est.setSearchSurface (model);//完整点云
    rf_est.compute (*model_rf);//计算 每个关键点的局部参考框架 并保存到 model_rf

    rf_est.setInputCloud (scene_keypoints);
    rf_est.setInputNormals (scene_normals);
    rf_est.setSearchSurface (scene);
    rf_est.compute (*scene_rf);

    //  Clustering
    pcl::Hough3DGrouping<PointType, PointType, RFType, RFType> clusterer;//初始化 Hough3DGrouping 聚类器，用于根据关键点和描述子匹配结果生成候选变换矩阵
    clusterer.setHoughBinSize (cg_size_);//设置网格大小
    clusterer.setHoughThreshold (cg_thresh_);//投票阈值
    clusterer.setUseInterpolation (true);//使用插值优化 Hough 空间投票，提高精度
    clusterer.setUseDistanceWeight (false);//false → 所有匹配点平等投票

    clusterer.setInputCloud (model_keypoints);//输入点云关键点
    clusterer.setInputRf (model_rf);//模型关键点对应的 LRF（局部参考框架）
    clusterer.setSceneCloud (scene_keypoints);//场景关键点
    clusterer.setSceneRf (scene_rf);//场景关键点对应的 LRF
    clusterer.setModelSceneCorrespondences (model_scene_corrs);//将之前通过描述子匹配得到的 有效匹配点对（Correspondences）输入给聚类器

    clusterer.recognize (rototranslations, clustered_corrs);//执行识别与聚类
    //输出：
    // rototranslations → 候选刚体变换矩阵（每个 4x4 Matrix4f）
    // clustered_corrs → 对应每个变换矩阵的匹配点集（每个簇的 Correspondences）
  }
  else//GeometricConsistencyGrouping方法
  {
    pcl::GeometricConsistencyGrouping<PointType, PointType> gc_clusterer;//创建 GeometricConsistencyGrouping 对象
    gc_clusterer.setGCSize (cg_size_);//指定 一致性距离阈值（单位：米） 如果两个匹配点对之间的距离变化超过这个值，就认为不一致
    gc_clusterer.setGCThreshold (cg_thresh_);//指定 最少一致性匹配点数量 只有匹配点数大于阈值的簇才会生成候选变换

    gc_clusterer.setInputCloud (model_keypoints);//输入模型关键点云
    gc_clusterer.setSceneCloud (scene_keypoints);//输入场景点关键点云
    gc_clusterer.setModelSceneCorrespondences (model_scene_corrs);//匹配关系

    gc_clusterer.recognize (rototranslations, clustered_corrs);//执行识别与聚类
  }

  /**
   * Stop if no instances
   */
  if (rototranslations.size () <= 0)
  {
    cout << "*** No instances found! ***" << endl;
    return (0);
  }
  else
  {
    cout << "Recognized Instances: " << rototranslations.size () << endl << endl;
  }

  /**
   * Generates clouds for each instances found 
   */
  std::vector<pcl::PointCloud<PointType>::ConstPtr> instances;//定义输出容器

  for (size_t i = 0; i < rototranslations.size (); ++i)//遍历所有候选变换矩阵
  {
    pcl::PointCloud<PointType>::Ptr rotated_model (new pcl::PointCloud<PointType> ());//rotated_model 是 临时点云指针，用来存放变换后的模型点云
    pcl::transformPointCloud (*model, *rotated_model, rototranslations[i]);
    //对模型点云应用刚体变换矩阵
    // *model → 输入原始模型点云
    // *rotated_model → 输出变换后的模型点云
    // rototranslations[i] → 当前候选变换矩阵（4x4）
    instances.push_back (rotated_model);
  }

  /**
   * ICP
   */
  std::vector<pcl::PointCloud<PointType>::ConstPtr> registered_instances;//registered_instances 保存 ICP 精细对齐后的模型实例点云
  if (true)
  {
    cout << "--- ICP ---------" << endl;

    for (size_t i = 0; i < rototranslations.size (); ++i)//遍历之前生成的候选实例点云
    {
      pcl::IterativeClosestPoint<PointType, PointType> icp;//ICP 是 经典点云配准算法  功能：在初始位置基础上进一步精细对齐，最小化点到点距离
      icp.setMaximumIterations (icp_max_iter_);//最大迭代系数
      icp.setMaxCorrespondenceDistance (icp_corr_distance_);//最大对应点距离  超过该距离的点不会被匹配  可过滤噪声或孤立点
      icp.setInputTarget (scene);//设置目标点云
      icp.setInputSource (instances[i]);//设置源点云
      pcl::PointCloud<PointType>::Ptr registered (new pcl::PointCloud<PointType>);
      icp.align (*registered);//执行 ICP 对齐
      registered_instances.push_back (registered);//保存对齐结果
      cout << "Instance " << i << " ";
      if (icp.hasConverged ())
      {
        cout << "Aligned!" << endl;
      }
      else
      {
        cout << "Not Aligned!" << endl;
      }
    }

    cout << "-----------------" << endl << endl;
  }

  /**
   * Hypothesis Verification
   */
  cout << "--- Hypotheses Verification ---" << endl;
  std::vector<bool> hypotheses_mask;  //存储每个候选模型实例是否被验证为正确匹配

  pcl::GlobalHypothesesVerification<PointType, PointType> GoHv;//GoHv 用于 全局假设验证

  GoHv.setSceneCloud (scene);  //设置场景点云
  GoHv.addModels (registered_instances, true);
  //registered_instances → ICP 对齐后的模型实例
  //第二个参数 true → 表示 将实例视为已经预对齐

  //设置 GHV 参数
  GoHv.setInlierThreshold (hv_inlier_th_);//点云距离阈值，模型点到场景点的最大距离，超出认为不一致
  GoHv.setOcclusionThreshold (hv_occlusion_th_);//遮挡阈值，允许模型被遮挡的比例
  GoHv.setRegularizer (hv_regularizer_);//正则化系数，控制候选模型数量惩罚，避免过拟合
  GoHv.setRadiusClutter (hv_rad_clutter_);//用于检测场景杂点的半径
  GoHv.setClutterRegularizer (hv_clutter_reg_);//杂点正则化，抑制杂乱点对验证影响
  GoHv.setDetectClutter (hv_detect_clutter_);//是否检测场景中的杂点
  GoHv.setRadiusNormals (hv_rad_normals_);//计算法向量支持半径，用于重叠和遮挡判断

  GoHv.verify ();//开始全局假设验证
  GoHv.getMask (hypotheses_mask);//每个候选模型实例是否通过验证
  //hypotheses_mask[i] == true → 第 i 个候选实例是可信匹配

  for (int i = 0; i < hypotheses_mask.size (); i++)//打印可信匹配信息
  {
    if (hypotheses_mask[i])
    {
      cout << "Instance " << i << " is GOOD! <---" << endl;
    }
    else
    {
      cout << "Instance " << i << " is bad!" << endl;
    }
  }
  cout << "-------------------------------" << endl;

  /**
   *  Visualization
   */
  pcl::visualization::PCLVisualizer viewer ("gagagga");
  viewer.setBackgroundColor(255,255,255);
  viewer.addPointCloud (scene, "scene_cloud");

  pcl::PointCloud<PointType>::Ptr off_scene_model (new pcl::PointCloud<PointType> ());
  pcl::PointCloud<PointType>::Ptr off_scene_model_keypoints (new pcl::PointCloud<PointType> ());

  pcl::PointCloud<PointType>::Ptr off_model_good_kp (new pcl::PointCloud<PointType> ());
  pcl::transformPointCloud (*model, *off_scene_model, Eigen::Vector3f (-1, 0, 0), Eigen::Quaternionf (1, 0, 0, 0));
  //将输入点云应用一个 刚体变换（平移 + 旋转）
  //*model → 原始模型点云
  // *off_scene_model → 输出点云（变换后的模型）
  // Eigen::Vector3f(-1, 0, 0) → 平移向量
  // 表示沿 X 轴负方向平移 1 单位
  // Eigen::Quaternionf(1, 0, 0, 0) → 四元数表示旋转
  // (1, 0, 0, 0) 表示 单位四元数，即没有旋转

  pcl::transformPointCloud (*model_keypoints, *off_scene_model_keypoints, Eigen::Vector3f (-1, 0, 0), Eigen::Quaternionf (1, 0, 0, 0));//将输入点云应用一个 刚体变换（平移 + 旋转），存入第二个参数
  pcl::transformPointCloud (*model_good_kp, *off_model_good_kp, Eigen::Vector3f (-1, 0, 0), Eigen::Quaternionf (1, 0, 0, 0));

  if (show_keypoints_)
  {
    CloudStyle modelStyle = style_white;
    pcl::visualization::PointCloudColorHandlerCustom<PointType> off_scene_model_color_handler (off_scene_model, modelStyle.r, modelStyle.g, modelStyle.b);//颜色处理器
    viewer.addPointCloud (off_scene_model, off_scene_model_color_handler, "off_scene_model");//将点云添加到可视化器
    viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, modelStyle.size, "off_scene_model");//渲染属性  大小
  }

  if (show_keypoints_)
  {
    CloudStyle goodKeypointStyle = style_violet;//显示风格
    pcl::visualization::PointCloudColorHandlerCustom<PointType> model_good_keypoints_color_handler (off_model_good_kp, goodKeypointStyle.r, goodKeypointStyle.g,
                                                                                                    goodKeypointStyle.b);//颜色处理器
    viewer.addPointCloud (off_model_good_kp, model_good_keypoints_color_handler, "model_good_keypoints");//加入点云（旋转后的model）
    viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, goodKeypointStyle.size, "model_good_keypoints");//大小

    pcl::visualization::PointCloudColorHandlerCustom<PointType> scene_good_keypoints_color_handler (scene_good_kp, goodKeypointStyle.r, goodKeypointStyle.g,
                                                                                                    goodKeypointStyle.b);//颜色处理器
    viewer.addPointCloud (scene_good_kp, scene_good_keypoints_color_handler, "scene_good_keypoints");//匹配成功的点
    viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, goodKeypointStyle.size, "scene_good_keypoints");//大小
  }

  for (size_t i = 0; i < instances.size (); ++i)
  {
    std::stringstream ss_instance;
    ss_instance << "instance_" << i;

    CloudStyle clusterStyle = style_red;
    pcl::visualization::PointCloudColorHandlerCustom<PointType> instance_color_handler (instances[i], clusterStyle.r, clusterStyle.g, clusterStyle.b);
    viewer.addPointCloud (instances[i], instance_color_handler, ss_instance.str ());
    viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, clusterStyle.size, ss_instance.str ());

    CloudStyle registeredStyles = hypotheses_mask[i] ? style_green : style_cyan;
    ss_instance << "_registered" << endl;
    pcl::visualization::PointCloudColorHandlerCustom<PointType> registered_instance_color_handler (registered_instances[i], registeredStyles.r,
                                                                                                   registeredStyles.g, registeredStyles.b);
    viewer.addPointCloud (registered_instances[i], registered_instance_color_handler, ss_instance.str ());
    viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, registeredStyles.size, ss_instance.str ());
  }

  while (!viewer.wasStopped ())
  {
    viewer.spinOnce ();
  }

  return (0);
}