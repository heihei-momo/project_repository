#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/common/io.h>
#include <pcl/keypoints/sift_keypoint.h>
#include <pcl/features/normal_3d.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/console/time.h>
using namespace std;

namespace pcl
{
  template<>
    struct SIFTKeypointFieldSelector<PointXYZ>
    {
      inline float
      operator () (const PointXYZ &p) const
      {
    return p.z;
      }
    };
}

int
main(int argc, char *argv[])
{

  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_xyz (new pcl::PointCloud<pcl::PointXYZ>);
  pcl::io::loadPCDFile (argv[1], *cloud_xyz);

  const float min_scale = 0.01;       
  const int n_octaves = 6;            
  const int n_scales_per_octave = 7;  
  const float min_contrast = 0.005;       
 
  pcl::SIFTKeypoint<pcl::PointXYZ, pcl::PointWithScale> sift;//创建SIFT检测器
  pcl::PointCloud<pcl::PointWithScale> result;
  sift.setInputCloud(cloud_xyz);//设置输入点云
  pcl::search::KdTree<pcl::PointXYZ>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZ> ());
  sift.setSearchMethod(tree);//设置搜索方法
  sift.setScales(min_scale, n_octaves, n_scales_per_octave);////设置参数： 最小尺度, 金字塔层数, 每层尺度数
  sift.setMinimumContrast(min_contrast);//最小对比度阈值
  sift.compute(result);//执行计算

  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_temp (new pcl::PointCloud<pcl::PointXYZ>);
  copyPointCloud(result, *cloud_temp);//类型转换复制
 

  pcl::visualization::PCLVisualizer viewer("Sift keypoint");//创建可视化对象
  viewer.setBackgroundColor( 255, 255, 255 );//背景颜色
  viewer.addPointCloud(cloud_xyz, "cloud");//将原始点云 cloud_xyz 添加到可视化器中
  viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR,0,0,0,"cloud");
  //第一个参数：要设置的属性类型（颜色）
  //第二、三、四个参数：RGB颜色值 (0, 0, 0) = 黑色
  //第五个参数：点云ID ("cloud")
  viewer.addPointCloud(cloud_temp, "keypoints");//添加关键点点云
  viewer.setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 9, "keypoints");//设置关键点大小
  viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR,255,0,0,"keypoints");//设置关键点颜色

  while(!viewer.wasStopped ())
  {
    viewer.spinOnce ();
  }
  return 0;
  
}