

#include <pcl/io/pcd_io.h>
#include <pcl/io/ply_io.h>
#include <pcl/console/print.h>
#include <pcl/console/parse.h>
#include <pcl/console/time.h>

using namespace pcl;
using namespace pcl::io;
using namespace pcl::console;

void
printHelp (int, char **argv)
{
  print_error ("Syntax is: %s [-format 0|1] input.ply output.pcd\n", argv[0]);
}

bool
loadCloud (const std::string &filename, pcl::PCLPointCloud2 &cloud)
{
  TicToc tt;//使用 TicToc 计时：tt.tic() 开始，tt.toc() 返回经过时间（通常以 ms 表示，浮点数）
  print_highlight ("Loading "); print_value ("%s ", filename.c_str ());

  pcl::PLYReader reader;
  tt.tic ();
  if (reader.read (filename, cloud) < 0)//读取 PLY 到 PCLPointCloud2
    return (false);
  print_info ("[done, ");
  print_value ("%g", tt.toc ()); print_info (" ms : "); 
  print_value ("%d", cloud.width * cloud.height); 
  print_info (" points]\n");
  print_info ("Available dimensions: "); 
  print_value ("%s\n", pcl::getFieldsList (cloud).c_str ());

  return (true);
}

void
saveCloud (const std::string &filename, const pcl::PCLPointCloud2 &cloud, bool format)
{
  TicToc tt;
  tt.tic ();

  print_highlight ("Saving "); print_value ("%s ", filename.c_str ());
  
  pcl::PCDWriter writer;
  writer.write (filename, cloud, Eigen::Vector4f::Zero (), Eigen::Quaternionf::Identity (), format);
  //writer.write(...) 的参数含义：
  // filename：输出的PCD文件名。
  // cloud：要写出的点云数据。
  // Eigen::Vector4f::Zero()：传 sensor/相机原点（origin），此处设为零向量（无位移）。
  // Eigen::Quaternionf::Identity()：传 sensor/相机朝向（orientation），使用单位四元数（无旋转）。
  // format（最后一项）控制是否以二进制保存（实现细节取决于 PCL 版本，但常见约定：1/bool true → binary，0/false → ascii）。
  
  print_info ("[done, "); print_value ("%g", tt.toc ()); print_info (" ms : "); print_value ("%d", cloud.width * cloud.height); print_info (" points]\n");
}

/* ---[ */
int
main (int argc, char** argv)
{
  print_info ("Convert a PLY file to PCD format. For more information, use: %s -h\n", argv[0]);

  if (argc < 3)
  {
    printHelp (argc, argv);
    return (-1);
  }

  // Parse the command line arguments for .pcd and .ply files
  std::vector<int> pcd_file_indices = parse_file_extension_argument (argc, argv, ".pcd");
  std::vector<int> ply_file_indices = parse_file_extension_argument (argc, argv, ".ply");
  //程序要求各有且只有一个 .ply（输入）和一个 .pcd（输出），所以检查 size() != 1
  //这允许用户把文件名放在任意位置，例如 ./prog input.ply output.pcd 或 ./prog output.pcd input.ply（只要带扩展名就能识别）
  if (pcd_file_indices.size () != 1 || ply_file_indices.size () != 1)
  {
    print_error ("Need one input PLY file and one output PCD file.\n");
    return (-1);
  }

  // Command line parsing
  bool format = 1;
  parse_argument (argc, argv, "-format", format);
  //argc, argv：命令行参数列表。
  // argument_name：要匹配的参数名（这里是 "-format"）。它会取下一个参数 " "，把它转换成与 value 相同类型
  // value：引用传入，找到参数后会被赋值
  print_info ("PCD output format: "); //功能类似 printf，但会用 信息提示颜色（通常是绿色），让输出在终端更醒目
  print_value ("%s\n", (format ? "binary" : "ascii"));//作用是以 高亮值 样式输出具体的值

  // Load the first file
  pcl::PCLPointCloud2 cloud;
  if (!loadCloud (argv[ply_file_indices[0]], cloud))//ply_file_indices 是前面通过 parse_file_extension_argument 找到的 .ply 文件参数位置数组
  //这里已经加载数据了cloud
    return (-1);

  // Convert to PLY and save
  saveCloud (argv[pcd_file_indices[0]], cloud, format);

  return (0);
}