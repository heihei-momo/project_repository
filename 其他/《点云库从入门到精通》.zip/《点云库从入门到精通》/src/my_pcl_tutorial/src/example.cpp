#include <ros/ros.h>
// PCL specific includes
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>

ros::Publisher pub;

void cloud_cb (const sensor_msgs::PointCloud2ConstPtr& cloud_msg)
{
  // Container for original & filtered data
  pcl::PCLPointCloud2* cloud = new pcl::PCLPointCloud2; //创建一个PCL点云对象（原始数据）
  pcl::PCLPointCloud2ConstPtr cloudPtr(cloud);//转换成 PCL 智能指针，方便后续处理
  //这行代码将 cloud（原始指针）包装成一个共享所有权的智能指针，并赋值给 cloudPtr
  pcl::PCLPointCloud2 cloud_filtered;//存储滤波后的点云

  // Convert to PCL data type
  pcl_conversions::toPCL(*cloud_msg, *cloud);//将 ROS 的 sensor_msgs::PointCloud2 转换为 PCL 的 pcl::PCLPointCloud2 格式，以便使用 PCL 库处理

  // Perform the actual filtering
  pcl::VoxelGrid<pcl::PCLPointCloud2> sor;//体素滤波器，用于降采样（减少点云数据量）
  sor.setInputCloud (cloudPtr);//设置输入点云
  sor.setLeafSize (0.1, 0.1, 0.1);//设置体素大小（单位：米），值越大，降采样越激进
  sor.filter (cloud_filtered);//执行滤波，结果存入 cloud_filtered

  // Convert to ROS data type
  sensor_msgs::PointCloud2 output;
  pcl_conversions::moveFromPCL(cloud_filtered, output);//将滤波后的 pcl::PCLPointCloud2 转换回 ROS 的

  // Publish the data
  pub.publish (output);
}

int main (int argc, char** argv)
{
  // Initialize ROS
  ros::init (argc, argv, "my_pcl_tutorial");
  ros::NodeHandle nh;

  // Create a ROS subscriber for the input point cloud
  ros::Subscriber sub = nh.subscribe<sensor_msgs::PointCloud2> ("input", 1, cloud_cb);

  // Create a ROS publisher for the output point cloud
  pub = nh.advertise<sensor_msgs::PointCloud2> ("output", 1);

  // Spin
  ros::spin ();
}