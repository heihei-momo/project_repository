#include <pcl/range_image/range_image.h>
#include <pcl/range_image/range_image_planar.h>
#include <pcl/io/io.h>
#include <pcl/io/pcd_io.h>
#include <pcl/features/integral_image_normal.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/point_types.h>
#include <pcl/features/normal_3d.h>
#include <pcl/console/print.h>
#include <pcl/surface/organized_fast_mesh.h>
#include <pcl/console/time.h>
#include <Eigen/StdVector>
#include <Eigen/Geometry>
#include <iostream>
#include <pcl/surface/impl/organized_fast_mesh.hpp> 
#include <boost/thread/thread.hpp>

#include <pcl/common/common_headers.h>

#include <pcl/visualization/range_image_visualizer.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/console/parse.h>
using namespace pcl::console;
int main (int argc, char** argv) {


	// Generate the data
	if (argc<2)
	{

		print_error ("Syntax is: %s input.pcd -w 640 -h 480 -cx 320 -cy 240 -fx 525 -fy 525 -type 0 -size 2\n", argv[0]);
		print_info ("  where options are:\n");
		print_info ("                     -w X = width of detph iamge ");

		return -1;
	}
	std::string filename = argv[1];

	int width=640,height=480,size=2,type=0;
	float fx=525,fy=525,cx=320,cy=240;

	parse_argument (argc, argv, "-w", width);
	parse_argument (argc, argv, "-h", height);
	parse_argument (argc, argv, "-cx", cx);
	parse_argument (argc, argv, "-cy", cy);
	parse_argument (argc, argv, "-fx", fx);
	parse_argument (argc, argv, "-fy", fy);
	parse_argument (argc, argv, "-type", type);
	parse_argument (argc, argv, "-size", size);
	//convert unorignized point cloud to orginized point cloud begin
	pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZRGB>);
	pcl::io::loadPCDFile (filename, *cloud);
	print_info ("Read pcd file successfully\n");
	Eigen::Affine3f sensorPose;
	sensorPose.setIdentity(); 
	//表示 3D 的仿射变换（包含旋转和平移）。
	//setIdentity() 把它设为单位变换，意思是点云已经在“传感器坐标系”里，或者说传感器位姿就是世界原点、无旋转。
	pcl::RangeImage::CoordinateFrame coordinate_frame = pcl::RangeImage::CAMERA_FRAME;//pcl::RangeImage::CoordinateFrame coordinate_frame = pcl::RangeImage::CAMERA_FRAME
	float noiseLevel=0.00;
	float minRange = 0.0f;

	pcl::RangeImagePlanar::Ptr rangeImage(new pcl::RangeImagePlanar);
	//RangeImagePlanar 使用针孔相机模型把 3D 点投影到 2D 图像（宽 width × 高 height），本质上就是用相机内参 (fx, fy, cx, cy) 进行投影。该类提供 getCenterX/Y（主点）和 getFocalLengthX/Y（焦距）等接口，语义与相机内参一致
	rangeImage->createFromPointCloudWithFixedSize(*cloud,width,height,cx,cy,fx,fy,sensorPose,coordinate_frame);
	std::cout << rangeImage << "\n";
	//convert unorignized point cloud to orginized point cloud end


	//viusalization of range image
	pcl::visualization::RangeImageVisualizer range_image_widget ("image_look");
	range_image_widget.showRangeImage (*rangeImage);//showRangeImage(*rangeImage) 会把 RangeImagePlanar 对象绘制出来
	range_image_widget.setWindowTitle("image_look");//改变窗口标题,这个窗口只能显示灰度深度图，不是 3D 模型
	//triangulation based on range image
	pcl::OrganizedFastMesh<pcl::PointWithRange>::Ptr tri(new pcl::OrganizedFastMesh<pcl::PointWithRange>);
	//OrganizedFastMesh 用于对**有序点云（organized cloud）**做快速三角剖分。RangeImagePlanar 正好是有序点云（宽×高排列）。
	pcl::search::KdTree<pcl::PointWithRange>::Ptr tree (new pcl::search::KdTree<pcl::PointWithRange>);
	tree->setInputCloud(rangeImage);//多余的，可去
	pcl::PolygonMesh triangles;//PolygonMesh triangles 用来存放三角网格
	tri->setTrianglePixelSize(size);//setTrianglePixelSize(size) 设置相邻像素的采样间隔，通常设为 1 表示逐像素建三角形
	tri->setInputCloud(rangeImage);//setInputCloud(rangeImage) 指定输入点云
	tri->setSearchMethod(tree);//多余的，可去
	//要用到 search::KdTree 或 search::Octree 来做最近邻搜索，所以需要调用：
	//但是 pcl::OrganizedFastMesh 不一样：
	// 它是专门针对 有序点云（organized cloud） 的快速网格化算法；
	// 直接利用了点云的二维像素排列关系（像图像一样的 row × col 索引）；
	// 完全不依赖 KD-Tree。

	tri->setTriangulationType((pcl::OrganizedFastMesh<pcl::PointWithRange>::TriangulationType)type);
	// setTriangulationType(...) 指定三角剖分策略，比如：
	// TRIANGLE_RIGHT_CUT、TRIANGLE_LEFT_CUT、TRIANGLE_ADAPTIVE_CUT 等。
	// 一般用 TRIANGLE_ADAPTIVE_CUT，效果较好
	tri->reconstruct(triangles);//生成网格

	boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer (new pcl::visualization::PCLVisualizer ("look_look"));
	viewer->setBackgroundColor(0.5,0.5,0.5);//灰色背景
	viewer->addPolygonMesh(triangles,"tin");//添加三角网格
	viewer->addCoordinateSystem();//添加坐标系原点
	while (!range_image_widget.wasStopped ()&&!viewer->wasStopped())
	{
		range_image_widget.spinOnce ();

		pcl_sleep (0.01);
		viewer->spinOnce ();

	}
	//双窗口循环：左边是深度图，右边是 3D 网格。
	// spinOnce() 让窗口刷新和响应交互。
	// pcl_sleep(0.01) 延时，避免占满 CPU
}