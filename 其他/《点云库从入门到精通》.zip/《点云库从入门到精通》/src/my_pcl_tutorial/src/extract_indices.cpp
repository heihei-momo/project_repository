#include <iostream>
#include <sstream>
#include <pcl/ModelCoefficients.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/extract_indices.h>

int main(int argc, char** argv)
{
    // 原始点云 & 滤波后的点云
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_p(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_f(new pcl::PointCloud<pcl::PointXYZ>);

    // 读取PCD文件
    if (pcl::io::loadPCDFile<pcl::PointXYZ>("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/table_scene_lms400.pcd", *cloud) == -1)
    {
        PCL_ERROR("Couldn't read file table_scene_lms400.pcd\n");
        return -1;
    }
    std::cerr << "PointCloud before filtering: "
              << cloud->width * cloud->height
              << " data points." << std::endl;

    // 体素滤波
    pcl::VoxelGrid<pcl::PointXYZ> sor;
    sor.setInputCloud(cloud);
    sor.setLeafSize(0.01f, 0.01f, 0.01f);//1*1*1 cm
    sor.filter(*cloud_filtered);

    std::cerr << "PointCloud after filtering: "
              << cloud_filtered->width * cloud_filtered->height
              << " data points." << std::endl;

    // 保存下采样结果
    pcl::io::savePCDFileBinary("table_scene_lms400_downsampled.pcd", *cloud_filtered);

    // 平面模型系数 & 内点索引
    pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients());//存放最终模型参数
    pcl::PointIndices::Ptr inliers(new pcl::PointIndices());//存放内点索引

    // 分割对象
    pcl::SACSegmentation<pcl::PointXYZ> seg;
    seg.setOptimizeCoefficients(true);//先用 RANSAC 找到一个“最大内点集”，再用所有内点做一次最小二乘拟合来细化平面参数（比直接用随机选的 3 点更稳）。
    seg.setModelType(pcl::SACMODEL_PLANE);//告诉分割器我们要拟合的是平面。对平面，RANSAC 每次只需抽样 3 个点 估计一个候选平面
    seg.setMethodType(pcl::SAC_RANSAC);//使用随机采样一致性（RANSAC）：反复随机取 3 点 → 拟合平面 → 统计“近这个平面”的点数 → 记下内点最多的那个模型
    seg.setMaxIterations(1000);//RANSAC 的最多尝试次数
    seg.setDistanceThreshold(0.01);//判内点的阈值（与点云坐标同单位，这里是“米” → 1 cm），点如果到候选模型（这里是平面）的几何距离 ≤ 0.01，就算内点

    pcl::ExtractIndices<pcl::PointXYZ> extract;//索引提取滤波器
    int i = 0;
    int nr_points = (int)cloud_filtered->points.size();//保存最初点云的点数，用于决定循环结束条件

    while (cloud_filtered->points.size() > 0.3 * nr_points)//循环直到剩余点数 < 原始点数的 30% 时结束。这样做是为了防止无限分割，避免在剩余点云很小的时候还去分割无意义的小平面
    {
        // 分割平面
        seg.setInputCloud(cloud_filtered);//把当前点云 cloud_filtered 送进 RANSAC 分割器 seg
        seg.segment(*inliers, *coefficients);//inliers 会保存属于最大平面的点索引列表
        //coefficients 保存该平面的参数(a,b,c,d)（平面方程ax+by+cz+d=0）
        if (inliers->indices.empty())//如果分割失败
        {
            std::cerr << "Could not estimate a planar model for the given dataset." << std::endl;
            break;
        }

        // 提取平面内点
        extract.setInputCloud(cloud_filtered);
        extract.setIndices(inliers);
        extract.setNegative(false);//只保留inliers对应的点（平面上的点）
        extract.filter(*cloud_p);//提取后的结果保存在 cloud_p，把最大平面取出来
        std::cerr << "PointCloud representing the planar component: "
                  << cloud_p->width * cloud_p->height
                  << " data points." << std::endl;

        // 保存平面点云
        std::stringstream ss;
        ss << "/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/point_split/table_scene_lms400_plane_" << i << ".pcd";
        pcl::io::savePCDFileBinary(ss.str(), *cloud_p);

        // 去掉平面点，保留剩下的点
        extract.setNegative(true);
        extract.filter(*cloud_f);
        cloud_filtered.swap(cloud_f);// 用剩余点替换当前点云
        i++;
    }

    return 0;
}
