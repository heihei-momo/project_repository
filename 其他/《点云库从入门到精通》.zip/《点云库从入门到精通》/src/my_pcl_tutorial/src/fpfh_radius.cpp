#include <iostream>
#include <fstream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/features/fpfh.h>
#include <pcl/features/normal_3d.h>
#include <pcl/filters/voxel_grid.h>

int main(int argc, char** argv)
{
    // if (argc < 4) {
    //     std::cout << "Usage: " << argv[0] << " input_cloud.pcd ground_truth.txt parameters.txt\n";
    //     return -1;
    // }

    // 1. Load input cloud
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZRGB>);
    if (pcl::io::loadPCDFile<pcl::PointXYZRGB>(argv[1], *cloud) == -1) {
        PCL_ERROR("Couldn't read file %s\n", argv[1]);
        return -1;
    }
    std::cout << "Loaded " << cloud->size() << " points.\n";

    // 2. Optional downsampling
    pcl::VoxelGrid<pcl::PointXYZRGB> voxel;
    voxel.setInputCloud(cloud);
    voxel.setLeafSize(0.01f, 0.01f, 0.01f);//三个方向的体素边长
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud_filtered(new pcl::PointCloud<pcl::PointXYZRGB>);
    voxel.filter(*cloud_filtered);
    std::cout << "Downsampled to " << cloud_filtered->size() << " points.\n";

    // 3. Compute normals
    pcl::NormalEstimation<pcl::PointXYZRGB, pcl::Normal> ne;
    ne.setInputCloud(cloud_filtered);
    pcl::search::KdTree<pcl::PointXYZRGB>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZRGB>);
    ne.setSearchMethod(tree);
    pcl::PointCloud<pcl::Normal>::Ptr normals(new pcl::PointCloud<pcl::Normal>);
    ne.setRadiusSearch(0.03);  //搜索范围
    ne.compute(*normals);//计算法线

    // 4. Compute FPFH features
    pcl::FPFHEstimation<pcl::PointXYZRGB, pcl::Normal, pcl::FPFHSignature33> fpfh;//输入点类型，法线类型，输出特征类型
    fpfh.setInputCloud(cloud_filtered);//输入点云
    fpfh.setInputNormals(normals);//输入法线
    fpfh.setSearchMethod(tree);//搜索模式
    pcl::PointCloud<pcl::FPFHSignature33>::Ptr fpfh_features(new pcl::PointCloud<pcl::FPFHSignature33>);
    fpfh.setRadiusSearch(0.05); //搜索范围
    fpfh.compute(*fpfh_features);//传入引用对象，进行计算

    std::cout << "Computed FPFH features for " << fpfh_features->size() << " points.\n";

    // 5. Save features to a file
    std::ofstream ofs("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/txt/fpfh_features.txt");
    for (size_t i = 0; i < fpfh_features->size(); ++i) {//遍历 每一个点的 FPFH 特征
        for (int j = 0; j < 33; ++j) {//遍历 每个 FPFH 特征的 33 个直方图值（FPFHSignature33 定义为 33 维）。每个点对应一个 33 维向量
            ofs << fpfh_features->at(i).histogram[j] << " ";
        }
        ofs << "\n";
    }
    ofs.close();
    std::cout << "Saved FPFH features to fpfh_features.txt\n";

    return 0;
}
