/* \author Kripasindhu Sarkar */

#include<pcl/visualization/pcl_plotter.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/filter.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/console/parse.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/filters/normal_space.h>
#include <pcl/common/eigen.h>
#include <pcl/features/normal_3d.h>
#include <pcl/features/fpfh.h>
#include <pcl/visualization/histogram_visualizer.h>


#include<iostream>
#include<vector>
#include<utility>
#include<math.h>  //for abs()

using namespace std;
using namespace pcl::visualization;
using namespace pcl::console;
void
generateData (double *ax, double *acos, double *asin, int numPoints)//生成一组 x、cos(x)、sin(x) 的数组
{
  double inc = 7.5 / (numPoints - 1);
  for (int i = 0; i < numPoints; ++i)
  {
    ax[i] = i*inc;
    acos[i] = cos (i * inc);
    asin[i] = sin (i * inc);
  }
}


double
step (double val)
{
  if (val > 0)
    return (double) (int) val;//自定义“阶梯”函数，向零方向取整（正数取 int，负数取 int-1）
  else
    return (double) ((int) val - 1);
}

double
identity_i (double val)
{
  return val;//恒等函数 y=x
}


int
main (int argc, char * argv [])
{
		if(argc<2)
	{
		std::cout<<".exe source.pcd -r 0.005 -ds 5"<<endl;
		return 0;
	}
	float voxel_re=0.005,ds_N=5;
	parse_argument (argc, argv, "-r", voxel_re);
	parse_argument (argc, argv, "-ds", ds_N);
  
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_src (new pcl::PointCloud<pcl::PointXYZ>); 
	pcl::io::loadPCDFile (argv[1], *cloud_src);	
	std::vector<int> indices1; 
	pcl::removeNaNFromPointCloud (*cloud_src, *cloud_src, indices1); 
  //除点云中 x,y,z 有 NaN（Not a Number）的点
  // 第三个参数 indices 会返回有效点的索引，但这里我们不关心它
  // 因为第二个参数也是 *cloud_src，所以是原地覆盖（in-place）操作
	pcl::PointCloud<pcl::PointXYZ>::Ptr ds_src (new pcl::PointCloud<pcl::PointXYZ>); 
	pcl::VoxelGrid<pcl::PointXYZ> grid; 
  //创建一个体素栅格滤波器（VoxelGrid Filter）对象。
  // 它会把点云空间划分成三维格子（体素），每个体素用一个代表点（通常是重心）替代所有点，从而减少点数
	grid.setLeafSize (voxel_re, voxel_re, voxel_re);//设置尺寸
	grid.setInputCloud (cloud_src); 
	grid.filter (*ds_src); //执行滤波，并把结果写入 ds_src。ds_src 的点数会显著减少，点间距接近 voxel_re

	pcl::PointCloud<pcl::Normal>::Ptr norm_src (new pcl::PointCloud<pcl::Normal>); 
	pcl::search::KdTree<pcl::PointXYZ>::Ptr tree_src(new pcl::search::KdTree<pcl::PointXYZ>()); 
	pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> ne; 
	PCL_INFO ("	Normal Estimation - Source \n");	
	ne.setInputCloud (ds_src); 
	ne.setSearchSurface (cloud_src); 
	ne.setSearchMethod (tree_src); 
	ne.setRadiusSearch (ds_N*2*voxel_re); //设置法向量估计的邻域搜索半径。
	ne.compute (*norm_src); //执行法向量计算，把结果保存到 norm_src（一个 PointCloud<Normal>）

	pcl::PointCloud<pcl::PointXYZ>::Ptr keypoints_src (new pcl::PointCloud<pcl::PointXYZ>); 
	pcl::PointCloud<pcl::PointXYZ>::Ptr keypoints_tgt (new pcl::PointCloud<pcl::PointXYZ>); 
	grid.setLeafSize (ds_N*voxel_re,ds_N*voxel_re,ds_N*voxel_re); //把体素格（VoxelGrid）的叶大小设置为 ds_N * voxel_re（三个轴相同）。
  // 为什么乘以ds_N：前面已经用过一次较小的 voxel_re 做了下采样得到 ds_src，这里再用更粗的体素尺寸（放大 ds_N 倍）做一次下采样，以得到更稀疏、分布更均匀的关键点集合。
  // 直觉：叶子越大 → 每个体素挑一个代表点 → 点数更少
	grid.setInputCloud (ds_src);
	grid.filter (*keypoints_src); //执行体素滤波，把结果写进 keypoints_src
       

	//Feature-Descriptor 
	PCL_INFO ("FPFH - Feature Descriptor\n"); 
	//FPFH	
	//FPFH Source 
	pcl::FPFHEstimation<pcl::PointXYZ, pcl::Normal, pcl::FPFHSignature33> fpfh_est_src; 
	pcl::search::KdTree<pcl::PointXYZ>::Ptr tree_fpfh_src (new pcl::search::KdTree<pcl::PointXYZ>); 

	fpfh_est_src.setSearchSurface (ds_src);//指定“搜索表面”为 ds_src（第一次体素滤波得到的较稠密下采样点云）
	fpfh_est_src.setInputCloud (keypoints_src);//设置需要计算特征的点集合（关键点）。原因：FPFH 计算量大，所以只对稀疏关键点算，而不是全点云
	fpfh_est_src.setInputNormals (norm_src); //指定每个点的法线向量（norm_src）。注意：这里要求 norm_src 的顺序和 ds_src 对应，因为搜索表面是 ds_src
	fpfh_est_src.setRadiusSearch (2*ds_N*voxel_re);//设置邻域半径 = 2 × ds_N × voxel_re
	fpfh_est_src.setSearchMethod(tree_fpfh_src);//设置邻域搜索的方法（这里用上面创建的 KdTree）
	pcl::PointCloud<pcl::FPFHSignature33>::Ptr fpfh_src (new pcl::PointCloud<pcl::FPFHSignature33>);
  //新建一个点云结构，用来存放计算出来的 FPFH 特征结果。
  //特点：这个“点云”的每个点不是 (x,y,z)，而是33维直方图（类型是 pcl::FPFHSignature33） 
	fpfh_est_src.compute (*fpfh_src);
  // 执行特征计算，把结果写入 fpfh_src。
  // 结果：
  // fpfh_src->points.size() == keypoints_src->points.size()。
  // 每个关键点对应一个 33 维向量（直方图），描述其局部几何形状。

  PCLPlotter *plotter = new PCLPlotter ("My Plotter"); 
  //创建一个绘图窗口，标题是 "My Plotter"。
  //PCLPlotter：PCL 提供的可视化类，用于绘制特征直方图，而不是 3D 点云
  plotter->setShowLegend (true);//开启图例（Legend）显示
  std::cout<<pcl::getFieldsList<pcl::FPFHSignature33>(*fpfh_src);//打印 fpfh_src 这种点类型包含的字段。
  plotter->addFeatureHistogram<pcl::FPFHSignature33>(*fpfh_src,"fpfh",5,"one_fpfh");
  // 功能：把 FPFH 特征画成直方图。    ---画图了
  // 参数解释：
  // *fpfh_src → 输入的特征点云。
  // "fpfh" → 字段前缀（FPFHSignature33 的字段名都是 fpfh_0、fpfh_1...）。
  // 5 → 选择画第几个点的特征（这里是第 5 个关键点）。
  // "one_fpfh" → 图例名字（会显示在 Legend 中）。
  plotter->setWindowSize (800, 600);//设置绘图窗口大小为 800×600 像素
  plotter->spinOnce (30000000);//显示绘图窗口并阻塞一段时间（这里是 3 千万毫秒 ≈ 8.3 小时），spinOnce() 不像 spin() 会一直运行，所以要传一个很大的时间保证窗口不会立刻关掉
  plotter->clearPlots ();//清空绘图数据

  int numPoints = 69;//要绘制的点数
  double ax[100], acos[100], asin[100];
  generateData (ax, acos, asin, numPoints);//自定义函数，负责生成这些数组的数值

  plotter->addPlotData (ax, acos, numPoints,"cos");//把 (ax, acos) 数据作为一条曲线加到绘图窗口中，"cos"曲线的标签
  plotter->addPlotData (ax, asin, numPoints,"sin");

  plotter->spinOnce (30000);//显示绘图窗口 30000 毫秒（30 秒），然后自动返回
  plotter->clearPlots ();
  
  plotter->setYRange (-10, 10);//这一行的意思是设置绘图窗口 Y 轴的显示范围：-10 → Y 轴最小值     10 → Y 轴最大值

  vector<double> func1 (1, 0);//初始为0
  func1[0] = 1; //y = 1
  //func1 是一个多项式的系数数组（从低次项到高次项）。
  // 这里分配了长度为 1 的向量（即只有常数项），初始为 0。
  // 把 func1[0] 设为 1，意思是：
  // y = 1（常数函数）
  vector<double> func2 (3, 0);
  func2[2] = 1; //y = x^2
  //func2 是长度为 3 的向量，表示一个二次多项式：a0 + a1*x + a2*x^2
  // 把 func2[2] 设为 1，表示：
  // y = 0 + 0x + 1x² → y = x²
  
  plotter->addPlotData (std::make_pair (func1, func2), -10, 10, "y = 1/x^2", 100, vtkChart::POINTS);//std::make_pair(func1, func2)：这里意思是两个多项式相除，y = func1 / func2 → y = 1 / x²
  //-10, 10：X 轴取值范围。
  // "y = 1/x^2"：曲线的名字（图例）。
  // 100：采样点数。
  // vtkChart::POINTS：用点的方式绘制，而不是连线。
  plotter->spinOnce (2000);// spinOnce(2000)：显示 2 秒。

  plotter->addPlotData (func2, -10, 10, "y = x^2");//直接绘制 y = x²（用 func2 表示的多项式）
  plotter->spinOnce (2000);

  plotter->addPlotData ( identity_i, -10, 10, "identity");//绘制 y = x
  plotter->spinOnce (2000);

  plotter->addPlotData (abs, -10, 10, "abs");//绘制 y = |x|
  plotter->spinOnce (2000);

  plotter->addPlotData (step, -10, 10, "step", 100, vtkChart::POINTS);//绘制阶跃函数 y = step(x)，用点来表示，100是采样点数量
  plotter->spinOnce (2000);

  plotter->clearPlots ();//清除

 
  vector<double> fsq (3, 0);
  fsq[2] = -100; //y = x^2
  while (plotter->wasStopped ())
  {
    if (fsq[2] == 100) fsq[2] = -100;
    fsq[2]++;
    //控制系数 fsq[2] 在 -100 到 100 之间变化。
    // 每次循环加 1，当到 100 时就回到 -100。
    // 这会让二次函数的开口越来越宽，甚至反向开口。
    char str[50];
    sprintf (str, "y = %dx^2", (int) fsq[2]);
    plotter->addPlotData (fsq, -10, 10, str);//这种重载里，系数向量按升幂排列：fsq[0] 是常数项 fsq[1] 是一次项 fsq[2] 是二次项 
	  plotter->setYRange (-1, 1);//固定 Y 轴范围为 [-1, 1]，不随函数变化自动缩放
    plotter->spinOnce (100);
    plotter->clearPlots ();
  }
  
  return 1;
}