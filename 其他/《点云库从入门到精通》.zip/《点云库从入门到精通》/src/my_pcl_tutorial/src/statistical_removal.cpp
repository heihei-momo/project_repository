#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/filters/statistical_outlier_removal.h>
int main (int argc, char** argv)
{
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered (new pcl::PointCloud<pcl::PointXYZ>);
  
  pcl::PCDReader reader;
  
  reader.read<pcl::PointXYZ> ("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/table_scene_lms400.pcd", *cloud);//用 pcl::PCDReader 把 PCD 文件读成 pcl::PointCloud<pcl::PointXYZ> 类型的点云
  std::cerr << "Cloud before filtering: " << std::endl;
  std::cerr << *cloud << std::endl;
  //创建并配置 SOR 滤波器
  pcl::StatisticalOutlierRemoval<pcl::PointXYZ> sor;
  sor.setInputCloud (cloud);//绑定输入点云 cloud
  sor.setMeanK (50);//对于每一个点，找它的 K=50 个最近邻，然后计算该点到这 50 个邻居的平均距离 d_i
  sor.setStddevMulThresh (1.0);
  //SOR 会对全体点的这些平均距离 {d_i} 统计出全局均值 μ 与标准差 σ。
  // 判定规则（单侧）：如果某点的平均距离
  // d_i > μ + 1.0 * σ
  // 则视为离群点（通常是稀疏、孤立、噪声点）；否则视为内点（inliers）。
  // 1.0 越小越“严格”，会剔除更多点；越大越“宽松”
  sor.filter (*cloud_filtered);//执行滤波，默认保留内点，把结果写到 cloud_filtered
  std::cerr << "Cloud after filtering: " << std::endl;
  std::cerr << *cloud_filtered << std::endl;
  pcl::PCDWriter writer;
  writer.write<pcl::PointXYZ> ("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/table_scene_lms400_inliers.pcd", *cloud_filtered, false);//把内点写到 table_scene_lms400_inliers.pcd  最后一个参数 false 表示ASCII 文本格式（非二进制）。体积更大但可读
  sor.setNegative (true);//让滤波的输出变成“被剔除的那些点”（即外点 outliers）
  sor.filter (*cloud_filtered);//再次 filter()，这回 cloud_filtered 里就是离群点集合
  writer.write<pcl::PointXYZ> ("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/table_scene_lms400_outliers.pcd", *cloud_filtered, false);//外点写到 table_scene_lms400_outliers.pcd，依然是 ASCII 格式
  return (0);
}
