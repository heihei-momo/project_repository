#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl_conversions/pcl_conversions.h> // ROS <-> PCL 转换

int main(int argc, char** argv)
{
    ros::init(argc, argv, "voxel_grid_filter_node");
    ros::NodeHandle nh;
    setlocale(LC_ALL,"");
    // 1. 读取 PCD 文件到 pcl::PointCloud<PointXYZ>
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
    if (pcl::io::loadPCDFile<pcl::PointXYZ>("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/table_scene_lms400.pcd", *cloud) == -1) {
        ROS_ERROR("无法读取 PCD 文件！");
        return -1;
    }
    ROS_INFO("滤波前点数: %lu", cloud->points.size());

    // 2. 创建体素滤波器
    pcl::VoxelGrid<pcl::PointXYZ> sor;
    sor.setInputCloud(cloud);
    sor.setLeafSize(0.01f, 0.01f, 0.01f);//表示每个格子的边长是 1 cm × 1 cm × 1 cm

    // 3. 滤波结果存到新点云
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered(new pcl::PointCloud<pcl::PointXYZ>);
    sor.filter(*cloud_filtered);
    ROS_INFO("滤波后点数: %lu", cloud_filtered->points.size());

    // 4. 保存结果
    pcl::io::savePCDFileBinary("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/table_scene_lms400_2.pcd", *cloud_filtered);
    ROS_INFO("已保存");

    // 5. 可选：转成 ROS 消息发布
    sensor_msgs::PointCloud2 output_msg;
    pcl::toROSMsg(*cloud_filtered, output_msg);
    output_msg.header.frame_id = "map"; // 或者你的坐标系

    ros::Publisher pub = nh.advertise<sensor_msgs::PointCloud2>("filtered_points", 1);
    pub.publish(output_msg);

    return 0;
}
