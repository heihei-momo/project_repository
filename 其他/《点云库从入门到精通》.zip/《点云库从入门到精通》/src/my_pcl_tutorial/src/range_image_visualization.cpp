#include <iostream>
#include <boost/thread/thread.hpp>
#include <pcl/common/common_headers.h>
#include <pcl/range_image/range_image.h>
#include <pcl/io/pcd_io.h>
#include <pcl/visualization/range_image_visualizer.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/console/parse.h>

typedef pcl::PointXYZ PointType;//定义点类型

float angular_resolution = 0.5f;//角分辨率
pcl::RangeImage::CoordinateFrame coordinate_frame = pcl::RangeImage::CAMERA_FRAME;//相机坐标系，机看向 +Z，右手系，+X 右、+Y 下（PCL 约定）。
bool live_update = false;

void printUsage(const char* progName) {
    std::cout << "\n\nUsage: " << progName << " [options] <scene.pcd>\n\n"
              << "Options:\n"
              << "-------------------------------------------\n"
              << "-r <float>   angular resolution in degrees (default " << angular_resolution << ")\n"
              << "-c <int>     coordinate frame (default " << (int)coordinate_frame << ")\n"
              << "-l           live update - update the range image according to the selected view in the 3D viewer.\n"
              << "-h           this help\n"
              << "\n\n";
}

void setViewerPose(pcl::visualization::PCLVisualizer& viewer, const Eigen::Affine3f& viewer_pose) {//相机在哪里（位置）相机正看向哪里（目标点）相机“头顶”朝哪个方向（上向量
    Eigen::Vector3f pos_vector = viewer_pose * Eigen::Vector3f(0, 0, 0);
    Eigen::Vector3f look_at_vector = viewer_pose.rotation() * Eigen::Vector3f(0, 0, 1) + pos_vector;//把这个方向向量旋转到世界坐标系，加上相机位置 pos_vector，得到世界坐标系下相机正在看的目标点位置
    Eigen::Vector3f up_vector = viewer_pose.rotation() * Eigen::Vector3f(0, -1, 0);

    viewer.setCameraPosition(
        pos_vector[0], pos_vector[1], pos_vector[2],    // 相机位置
        look_at_vector[0], look_at_vector[1], look_at_vector[2], // 观察目标，在 PCL 的相机坐标中，摄像机“前向”是局部 +Z（所以 look 用 (0,0,1)）
        up_vector[0], up_vector[1], up_vector[2]        // 上方向，(0,-1,0) 是相机局部坐标系的“向上”方向（注意这里是 -Y，因为 PCL 的相机坐标系和常规右手系略有不同旋转到世界坐标系，得到世界系里的“向上”向量
    );
}

int main(int argc, char** argv) {
    if (pcl::console::find_argument(argc, argv, "-h") >= 0) {//pcl::console::find_argument() 会在传入的 argv 参数数组里查找某个特定字符串（例如 "-h"）
        printUsage(argv[0]);
        return 0;
    }
    if (pcl::console::find_argument(argc, argv, "-l") >= 0) {
        live_update = true;
        std::cout << "Live update is on.\n";
    }
    if (pcl::console::parse(argc, argv, "-r", angular_resolution) >= 0)//pcl::console::parse() 会在命令行参数里查找一个特定的 参数名（例如 "-r"），并把它后面紧跟的值解析出来存到你提供的变量里
        std::cout << "Setting angular resolution to " << angular_resolution << " deg.\n";

    int tmp_coordinate_frame;
    if (pcl::console::parse(argc, argv, "-c", tmp_coordinate_frame) >= 0) {
        coordinate_frame = pcl::RangeImage::CoordinateFrame(tmp_coordinate_frame);//把一个整数转换成枚举类型 pcl::RangeImage::CoordinateFrame，并赋值给变量 coordinate_frame
        std::cout << "Using coordinate frame " << (int)coordinate_frame << ".\n";
    }
    angular_resolution = pcl::deg2rad(angular_resolution);//就是把角分辨率从“度”转换成“弧度”，因为 PCL 内部计算时要求用弧度单位

    pcl::PointCloud<PointType>::Ptr point_cloud_ptr(new pcl::PointCloud<PointType>);//用来存放原始点云
    pcl::PointCloud<PointType>& point_cloud = *point_cloud_ptr;
    Eigen::Affine3f scene_sensor_pose(Eigen::Affine3f::Identity());//初始化一个 3D 仿射变换矩阵，并且设为单位变换

    std::vector<int> pcd_filename_indices =//找到所有命令行里以 .pcd 结尾的文件名索引
        pcl::console::parse_file_extension_argument(argc, argv, "pcd");//用命令行解析 .pcd 文件名参数。
        // 如果有传 .pcd 文件，就：
        // 用 pcl::io::loadPCDFile 读取。
        // 读取 sensor_origin_ 和 sensor_orientation_ 作为 scene_sensor_pose。
        // 如果没有传文件，就生成一个例子点云

    if (!pcd_filename_indices.empty()) {
        std::string filename = argv[pcd_filename_indices[0]];
        if (pcl::io::loadPCDFile(filename, point_cloud) == -1) {
            std::cout << "Was not able to open file \"" << filename << "\".\n";
            printUsage(argv[0]);
            return 0;
        }
        scene_sensor_pose = Eigen::Affine3f(
                                Eigen::Translation3f(point_cloud.sensor_origin_[0],
                                                      point_cloud.sensor_origin_[1],
                                                      point_cloud.sensor_origin_[2])) *
                            Eigen::Affine3f(point_cloud.sensor_orientation_);
    //sensor_origin_ 和 sensor_orientation_ 是PCL  点云头部   里记录的采集时传感器的位置和朝向。
    // 用 平移 × 旋转 生成一个 scene_sensor_pose，作为传感器在世界坐标系中的位姿
    } else {
        std::cout << "\nNo *.pcd file given => Generating example point cloud.\n\n";
        for (float x = -0.5f; x <= 0.5f; x += 0.01f) {
            for (float y = -0.5f; y <= 0.5f; y += 0.01f) {
                PointType point;
                point.x = x;  
                point.y = y;  
                point.z = 2.0f - y;
                point_cloud.points.push_back(point);
            }
        }
        point_cloud.width = (int)point_cloud.points.size();
        point_cloud.height = 1;
    }
    //如果用户没传 .pcd 文件，就手动生成一个例子点云。循环 x 和 y 在 [-0.5, 0.5]，间隔 0.01f。z = 2.0f - y，所以是一个倾斜平面（y 越大，z 越小）

    float noise_level = 0.0;
    float min_range = 0.0f;
    int border_size = 1;
    boost::shared_ptr<pcl::RangeImage> range_image_ptr(new pcl::RangeImage);
    pcl::RangeImage& range_image = *range_image_ptr;

    range_image.createFromPointCloud(point_cloud, angular_resolution,pcl::deg2rad(360.0f), pcl::deg2rad(180.0f),scene_sensor_pose, coordinate_frame,noise_level, min_range, border_size);
    //生成图像，生成 RangeImage，颜色深浅表示距离
    //angular_resolution → 角分辨率（之前已经转成弧度）。
    // pcl::deg2rad(360.0f) → 水平方向视场角。
    // pcl::deg2rad(180.0f) → 垂直方向视场角。
    // scene_sensor_pose → 传感器位置姿态。
    // coordinate_frame → 坐标系（比如 LASER_FRAME）。
    // noise_level → 0 代表不做深度平滑。
    // min_range → 忽略这个距离以内的点。
    // border_size → 生成的边框像素宽度。
    pcl::visualization::PCLVisualizer viewer("3D Viewer");
    viewer.setBackgroundColor(1, 1, 1);//颜色
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointWithRange>
        range_image_color_handler(range_image_ptr, 0, 0, 0);//黑色点云

    viewer.addPointCloud(range_image_ptr, range_image_color_handler, "range image");
    //range_image_ptr 是 点云数据（这里的 range_image 本质上继承自 PointCloud<PointWithRange>）。
    // range_image_color_handler 是颜色控制器，这里是 PointCloudColorHandlerCustom，给所有点统一颜色（上面是 (0,0,0) 黑色）。
    // "range image" 是这个点云对象的 ID
    viewer.setPointCloudRenderingProperties(
        pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "range image");//PCL_VISUALIZER_POINT_SIZE 表示设置点云的渲染属性为 点的大小
        //"range image" 让它只对刚才那个点云生效
    viewer.initCameraParameters();
    //初始化相机参数（相当于默认视角 + 透视/投影矩阵设置）。
    // 必须在添加点云之后调用，否则可能会出现相机没对准数据的情况

    setViewerPose(viewer, range_image.getTransformationToWorldSystem());
    //getTransformationToWorldSystem() 返回这个 range image 对应的 世界坐标系变换（矩阵）。
    // setViewerPose（用户定义的函数）会用这个变换来调整 viewer 的相机位置、朝向和上方向，让相机视角和 range image 的世界坐标对齐。
    //作用：让显示的点云在屏幕中处于正确位置和方向。

    pcl::visualization::RangeImageVisualizer range_image_widget("Range image");
    range_image_widget.showRangeImage(range_image);
    //RangeImageVisualizer 是 PCL 专门用来显示 深度图 / 距离图 的 2D 窗口。
    // "Range image" 是窗口标题。
    // showRangeImage(range_image) 把当前的 range image 数据画到这个窗口里（颜色通常代表深度）。
    while (!viewer.wasStopped()) {
        range_image_widget.spinOnce();
        viewer.spinOnce();
        pcl_sleep(0.01);
        //ange_image_widget.spinOnce()：刷新 2D range image 窗口。
        // viewer.spinOnce()：刷新 3D 点云窗口
        if (live_update) {
            scene_sensor_pose = viewer.getViewerPose();
            range_image.createFromPointCloud(
                point_cloud, angular_resolution,
                pcl::deg2rad(360.0f), pcl::deg2rad(180.0f),
                scene_sensor_pose, pcl::RangeImage::LASER_FRAME,
                noise_level, min_range, border_size);
            range_image_widget.showRangeImage(range_image);
            // live_update：如果这个标志是 true，说明要动态生成新的 range image。
            // viewer.getViewerPose()：获取当前 3D 相机的位置和朝向（相当于把相机当作激光扫描仪）。
            // range_image.createFromPointCloud(...)：用当前相机位姿 & 点云生成新的 range image。
            // range_image_widget.showRangeImage(...)：刷新 2D 窗口里的图像
        }
    }
    return 0;
}
