#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>

int
main(int argc,char** argv)
{
if(argc!=2)//命令行参数检查
{
std::cerr<<"please specify command line arg '-f' or '-p'"<<std::endl;
exit(0);
}
pcl::PointCloud<pcl::PointXYZ> cloud_a,cloud_b,cloud_c;
pcl::PointCloud<pcl::Normal> n_cloud_b;//每点表示法线（通常有 normal_x/y/z 和 curvature），可通过数组或成员访问。
pcl::PointCloud<pcl::PointNormal> p_n_cloud_c;//组合点类型，既有 x,y,z 又有 normal[3]，用于把坐标和法线合并。
cloud_a.width=5;
cloud_a.height=cloud_b.height=n_cloud_b.height=1;
cloud_a.points.resize(cloud_a.width*cloud_a.height);
if(strcmp(argv[1],"-p")==0)//检查argv1是不是-p
{
cloud_b.width=3;
cloud_b.points.resize(cloud_b.width*cloud_b.height);
}
else{
n_cloud_b.width=5;
n_cloud_b.points.resize(n_cloud_b.width*n_cloud_b.height);
}

for(size_t i=0;i<cloud_a.points.size();++i)//生成随机点云
{
cloud_a.points[i].x=1024*rand()/(RAND_MAX+1.0f);
cloud_a.points[i].y=1024*rand()/(RAND_MAX+1.0f);
cloud_a.points[i].z=1024*rand()/(RAND_MAX+1.0f);
}

if(strcmp(argv[1],"-p")==0)
for(size_t i=0;i<cloud_b.points.size();++i)
{
cloud_b.points[i].x=1024*rand()/(RAND_MAX+1.0f);//生成随机点云
cloud_b.points[i].y=1024*rand()/(RAND_MAX+1.0f);
cloud_b.points[i].z=1024*rand()/(RAND_MAX+1.0f);
}
else
for(size_t i=0;i<n_cloud_b.points.size();++i)//随机填充法线，给 Normal 的三个分量赋值（视需要通常法线被归一化为单位向量，但这里只是随机数用于示例）
{
n_cloud_b.points[i].normal[0]=1024*rand()/(RAND_MAX+1.0f);
n_cloud_b.points[i].normal[1]=1024*rand()/(RAND_MAX+1.0f);
n_cloud_b.points[i].normal[2]=1024*rand()/(RAND_MAX+1.0f);
}
std::cerr<<"Cloud A: "<<std::endl;
for(size_t i=0;i<cloud_a.points.size();++i)
std::cerr<<"    "<<cloud_a.points[i].x<<" "<<cloud_a.points[i].y<<" "<<cloud_a.points[i].z<<std::endl;

std::cerr<<"Cloud B: "<<std::endl;

if(strcmp(argv[1],"-p")==0)
for(size_t i=0;i<cloud_b.points.size();++i)
std::cerr<<"    "<<cloud_b.points[i].x<<" "<<cloud_b.points[i].y<<" "<<cloud_b.points[i].z<<std::endl;
else
for(size_t i=0;i<n_cloud_b.points.size();++i)
std::cerr<<"    "<<n_cloud_b.points[i].normal[0]<<" "<<n_cloud_b.points[i].normal[1]<<" "<<n_cloud_b.points[i].normal[2]<<std::endl;

if(strcmp(argv[1],"-p")==0)//-p模式   坐标拼接
{
cloud_c=cloud_a;//这里点云拼接是直接追加点，不要求宽度相同，这边类型不变，点云数量变多了，因为接上尾巴了
cloud_c+=cloud_b;
std::cerr<<"Cloud C: "<<std::endl;
for(size_t i=0;i<cloud_c.points.size();++i)
std::cerr<<"    "<<cloud_c.points[i].x<<" "<<cloud_c.points[i].y<<" "<<cloud_c.points[i].z<<" "<<std::endl;
}
else//-f，或者是其他字符    坐标加法线拼接
{
pcl::concatenateFields(cloud_a,n_cloud_b,p_n_cloud_c);//这里点云的数量不变，但是类型变化了。一个pointxyz和normal拼接变成PointNormal
//concatenateFields：PCL 的工具函数，把 同长度 的两个点云的字段按位置合并到一个复合点类型中（这里是 PointXYZ + Normal → PointNormal）。
//关键限制：cloud_a.points.size() 必须等于 n_cloud_b.points.size()，否则合并会失败或产生未定义行为。
std::cerr<<"Cloud C: "<<std::endl;

for(size_t i=0;i<p_n_cloud_c.points.size();++i)
std::cerr<<"    "<<
p_n_cloud_c.points[i].x<<" "<<p_n_cloud_c.points[i].y<<" "<<p_n_cloud_c.points[i].z<<" "<<
p_n_cloud_c.points[i].normal[0]<<" "<<p_n_cloud_c.points[i].normal[1]<<" "<<p_n_cloud_c.points[i].normal[2]<<std::endl;
}
return(0);
}
