#include <pcl/features/rops_estimation.h>
#include <pcl/io/pcd_io.h>
#include <pcl/visualization/histogram_visualizer.h>
#include<pcl/visualization/pcl_plotter.h>
int main (int argc, char** argv)
{
	if (argc != 4)
		return (-1);

	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ> ());
	if (pcl::io::loadPCDFile (argv[1], *cloud) == -1)
		return (-1);

	pcl::PointIndicesPtr indices = boost::shared_ptr <pcl::PointIndices> (new pcl::PointIndices ());//点索引容器的智能指针
	std::ifstream indices_file;
	indices_file.open (argv[2], std::ifstream::in);//打开由命令行参数 argv[2] 指定的文件
	for (std::string line; std::getline (indices_file, line);)//遍历每一行,逐行读取
	{
		std::istringstream in (line);//把 line（一行的字符串）转成 std::istringstream
		unsigned int index = 0;
		in >> index;//将这一行的数字读入 index
		indices->indices.push_back (index - 1);//把读到的索引存入 indices 里
		//pcl::PointIndices 内部有一个成员
	}
	indices_file.close ();//关闭文件

	std::vector <pcl::Vertices> triangles;
	std::ifstream triangles_file;
	triangles_file.open (argv[3], std::ifstream::in);//打开第三个文件
	for (std::string line; std::getline (triangles_file, line);)
	{
		pcl::Vertices triangle;//pcl::Vertices 就是一个小容器，里面只有一个成员 std::vector<uint32_t>
		std::istringstream in (line);//line里面的内容存入in
		unsigned int vertex = 0;
		in >> vertex;
		triangle.vertices.push_back (vertex - 1);
		in >> vertex;
		triangle.vertices.push_back (vertex - 1);
		in >> vertex;
		triangle.vertices.push_back (vertex - 1);//把三个数（角点），存入
		triangles.push_back (triangle);//把角点存入
	}

	float support_radius = 0.0285f;
	unsigned int number_of_partition_bins = 5;
	unsigned int number_of_rotations = 3;

	pcl::search::KdTree<pcl::PointXYZ>::Ptr search_method (new pcl::search::KdTree<pcl::PointXYZ>);//kdtree
	search_method->setInputCloud (cloud);//存入点云

	pcl::ROPSEstimation <pcl::PointXYZ, pcl::Histogram <135> > feature_estimator;
	//定义一个 ROPSEstimation 对象，输入点类型是 pcl::PointXYZ。
	// 输出的特征类型是 pcl::Histogram<135>（维度为 135 的直方图）

	feature_estimator.setSearchMethod (search_method);//搜索方法
	feature_estimator.setSearchSurface (cloud);//设置搜索表面，即在整个点云 cloud 中找邻域。有时可以设置为子集，比如降采样后的点云。
	feature_estimator.setInputCloud (cloud);//设置输入点云，即需要计算特征的点，通常是关键点，这里是一整个点云
	feature_estimator.setIndices (indices);//设置点的索引集合。只对这些点计算特征，而不是对整个点云
	feature_estimator.setTriangles (triangles);//设置点云的三角形连接信息
	feature_estimator.setRadiusSearch (support_radius);//设置邻域半径（support region）。决定了在计算特征时，每个点周围取多大的范围
	feature_estimator.setNumberOfPartitionBins (number_of_partition_bins);//设置直方图的分区数量。ROPS 在投影时会做统计直方图，这里控制直方图的精细程度
	feature_estimator.setNumberOfRotations (number_of_rotations);//设置投影时的旋转次数。ROPS 会把局部表面投影到不同的方向，旋转次数越多，特征越稳定，但计算量也更大
	feature_estimator.setSupportRadius (support_radius);//设置支持区域半径（其实和 setRadiusSearch 功能类似）。在 ROPS 中，这是必须指定的参数，用来定义邻域大小

	pcl::PointCloud<pcl::Histogram <135> >::Ptr histograms (new pcl::PointCloud <pcl::Histogram <135> > ());
	feature_estimator.compute (*histograms);//执行 ROPS 特征计算

	std::cout<<histograms->header<<endl;
	std::string title="pcl";
	pcl::visualization::PCLPlotter *plotter = new pcl::visualization::PCLPlotter (title.c_str());//创建一个 PCL 提供的绘图工具 PCLPlotter
	plotter->setWindowName(title);
	plotter->setShowLegend (true);//开启图例显示
	plotter->addFeatureHistogram<pcl::Histogram <135>>(*histograms,135,"rops");//添加直方图
	plotter->spin();//进入事件循环，显示窗口，直到用户关闭
	return (0);
}