#include <pcl/io/io.h>
#include <pcl/io/pcd_io.h>
#include <pcl/features/integral_image_normal.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/point_types.h>
#include <pcl/features/normal_3d.h>

int main ()
{

pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
pcl::io::loadPCDFile ("/home/yyh/study_files/pcl_study/src/my_pcl_tutorial/meshes/pcd/table_scene_lms400.pcd", *cloud);

pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> ne;//估计表面法线
ne.setInputCloud (cloud);
pcl::search::KdTree<pcl::PointXYZ>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZ> ());
ne.setSearchMethod (tree);//使用 KD-tree 做邻域搜索。
pcl::PointCloud<pcl::Normal>::Ptr cloud_normals (new pcl::PointCloud<pcl::Normal>);
ne.setRadiusSearch (0.03);//以 3cm 为半径的球体内的点被视为邻域

ne.compute (*cloud_normals);//存储法线的指针

pcl::visualization::PCLVisualizer viewer("PCL Viewer");
viewer.setBackgroundColor (0.0, 0.0, 0.0);
viewer.addPointCloudNormals<pcl::PointXYZ,pcl::Normal>(cloud, cloud_normals);//绘制法线

while (!viewer.wasStopped ())
{
     viewer.spinOnce ();
}

return 0;
}
