#include <pcl/io/pcd_io.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/keypoints/harris_3d.h>
#include <pcl/console/time.h>
#include <pcl/filters/filter.h>
#include <iostream>
#include <vector>
using namespace std;

int main(int argc,char *argv[]) 
{
	pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud (new pcl::PointCloud<pcl::PointXYZ>);
	pcl::io::loadPCDFile (argv[1], *input_cloud);
	pcl::PCDWriter writer;//创建pcd写入器
	float r_normal;
	float r_keypoint;

	r_normal=0.1;
	r_keypoint=0.1;//参数设置

	typedef pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZI> ColorHandlerT3;//定义自定义颜色处理器类型，用于可视化

	pcl::PointCloud<pcl::PointXYZI>::Ptr Harris_keypoints (new pcl::PointCloud<pcl::PointXYZI> ());//Harris关键点检测器
	pcl::HarrisKeypoint3D<pcl::PointXYZ,pcl::PointXYZI,pcl::Normal>* harris_detector = new pcl::HarrisKeypoint3D<pcl::PointXYZ,pcl::PointXYZI,pcl::Normal> ;
	//<pcl::PointXYZ>: 输入点类型（只有坐标）
	// <pcl::PointXYZI>: 输出点类型（坐标+强度）
	// <pcl::Normal>: 法线类型（用于计算）

	//harris_detector->setNonMaxSupression(true);// 注释掉的非极大值抑制
	harris_detector->setRadius(r_normal);// 设置半径参数
	harris_detector->setRadiusSearch(r_keypoint);// 设置搜索半径
	harris_detector->setInputCloud (input_cloud);//设置输入点云
	//harris_detector->setNormals(normal_source);// 注释掉的法线设置
	//harris_detector->setMethod(pcl::HarrisKeypoint3D<pcl::PointXYZRGB,pcl::PointXYZI>::LOWE); // 注释掉的方法设置
	harris_detector->compute (*Harris_keypoints);//计算
	cout<<"Harris_keypoints"<<Harris_keypoints->size()<<endl;//保存结果
	writer.write<pcl::PointXYZI> ("src/my_pcl_tutorial/meshes/pcd/Harris_keypoints.pcd",*Harris_keypoints,false);//（输出文件的名称，要保存的点云对象，false: 以ASCII文本格式保存）

	pcl::visualization::PCLVisualizer visu3("clouds");//可视化设置
	visu3.setBackgroundColor(255,255,255);//背景颜色
	visu3.addPointCloud (Harris_keypoints, ColorHandlerT3 (Harris_keypoints, 0.0, 0.0, 255.0), "Harris_keypoints");
	//ColorHandlerT3(Harris_keypoints, 0.0, 0.0, 255.0) (第二个参数)这是一个临时创建的颜色处理器对象，第三个参数是云在可视化器中的唯一标识符
	visu3.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE,8,"Harris_keypoints");//设置可视化中点云的渲染属性， specifically 设置关键点的大小
	visu3.addPointCloud(input_cloud,"input_cloud");//点云  标识符
	visu3.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR,0,0,0,"input_cloud");//设置原始点云为黑色
	visu3.spin ();
}