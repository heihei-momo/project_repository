#include <iostream>
#include <pcl/console/parse.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>

#include <pcl/visualization/pcl_visualizer.h>
#include <boost/thread/thread.hpp>
#include <pcl/features/boundary.h>
#include <math.h>
#include <boost/make_shared.hpp>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/io/pcd_io.h>

#include <pcl/visualization/range_image_visualizer.h>
#include <pcl/features/normal_3d.h>

#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/filters/covariance_sampling.h>
#include <pcl/filters/normal_space.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/features/boundary.h>
#include <pcl/io/ply_io.h>


int estimateBorders(pcl::PointCloud<pcl::PointXYZ>::Ptr &cloud,float re,float reforn) 
{ 

	pcl::PointCloud<pcl::Boundary> boundaries; //pcl::Boundary是：boundaries 是输出点云的边界信息，包含xyz，边界点标识，曲率）  pcl::PointCloud<T>里面有容器成员
	pcl::BoundaryEstimation<pcl::PointXYZ, pcl::Normal, pcl::Boundary> boundEst;//创建 边界估计器对象
	pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> normEst; //法向量估计器
	pcl::PointCloud<pcl::Normal>::Ptr normals(new pcl::PointCloud<pcl::Normal>); //用来存储法向量
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_boundary (new pcl::PointCloud<pcl::PointXYZ>); //用于存储边界点的点云
	normEst.setInputCloud(pcl::PointCloud<pcl::PointXYZ>::Ptr(cloud)); 
	normEst.setRadiusSearch(reforn); //查找半径
	normEst.compute(*normals); //输出法向量

	boundEst.setInputCloud(cloud); 
	boundEst.setInputNormals(normals); //输入法向量
	boundEst.setRadiusSearch(re); //指定邻域搜索范围
	boundEst.setAngleThreshold(M_PI/4); //如果邻域点法向量与中心点法向量之间的角度大于阈值，则可能是边界点，阈值为45度
	boundEst.setSearchMethod(pcl::search::KdTree<pcl::PointXYZ>::Ptr (new pcl::search::KdTree<pcl::PointXYZ>)); //设置搜索方法kdtree
	boundEst.compute(boundaries); //计算边界

	for(int i = 0; i < cloud->points.size(); i++) 
	{
		if(boundaries[i].boundary_point > 0) //	判读这个点的标记  是否为边界点
		{ 
			cloud_boundary->push_back(cloud->points[i]); //如果是边界点就存储
		} 
	} 

	boost::shared_ptr<pcl::visualization::PCLVisualizer> MView (new pcl::visualization::PCLVisualizer ("gagagag"));//创建可视化对象
	
	int v1(0); 
	MView->createViewPort (0.0, 0.0, 0.5, 1.0, v1);//创建第一个视口 
	MView->setBackgroundColor (0.3, 0.3, 0.3, v1); //背景颜色
	MView->addText ("Raw point clouds", 10, 10, "v1_text", v1); //显示文字
	int v2(0); 
	MView->createViewPort (0.5, 0.0, 1, 1.0, v2); //创建第二个视口 
	MView->setBackgroundColor (0.5, 0.5, 0.5, v2); //背景颜色
	MView->addText ("Boudary point clouds", 10, 10, "v2_text", v2); //显示文字

	MView->addPointCloud<pcl::PointXYZ> (cloud, "sample cloud",v1);
	MView->addPointCloud<pcl::PointXYZ> (cloud_boundary, "cloud_boundary",v2);
	MView->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_COLOR, 1,0,0, "sample cloud",v1);
	MView->setPointCloudRenderingProperties (pcl::visualization::PCL_VISUALIZER_COLOR, 0,1,0, "cloud_boundary",v2);//设置点云颜色
	MView->addCoordinateSystem (1.0);//创建坐标系
	MView->initCameraParameters ();//初始化相机

	MView->spin();

	return 0; 
} 
int main(int argc, char** argv)
{
	srand(time(NULL));//随机数种子，这里没有用到

	float re,reforn;
	re=std::atof(argv[2]);
	reforn=std::atof(argv[3]);
	pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_src (new pcl::PointCloud<pcl::PointXYZ>); 



	//Laden der PCD-Files 
	pcl::io::loadPCDFile (argv[1], *cloud_src);	

	estimateBorders(cloud_src,re,reforn);

	return 0;
}
