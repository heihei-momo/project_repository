#include <pcl/point_cloud.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <iostream>
#include <vector>
#include <ctime>

int main (int argc, char**argv)
{
srand (time (NULL));//用 srand(time(NULL)) 基于当前时间设 seed，使每次运行生成不同随机数
pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);

cloud->width =1000;
cloud->height =1;
cloud->points.resize (cloud->width * cloud->height);
for (size_t i=0; i< cloud->points.size (); ++i)
  {
cloud->points[i].x =1024.0f* rand () / (RAND_MAX +1.0f);
cloud->points[i].y =1024.0f* rand () / (RAND_MAX +1.0f);
cloud->points[i].z =1024.0f* rand () / (RAND_MAX +1.0f);
  }
//创建并填充点云
pcl::KdTreeFLANN<pcl::PointXYZ>kdtree;
kdtree.setInputCloud (cloud);//建立kd树
pcl::PointXYZ searchPoint;
searchPoint.x=1024.0f* rand () / (RAND_MAX +1.0f);
searchPoint.y=1024.0f* rand () / (RAND_MAX +1.0f);
searchPoint.z=1024.0f* rand () / (RAND_MAX +1.0f);
//随机生成一个查询点，和点云处在同样坐标范围

int K =10;//要求返回的近邻个数
std::vector<int>pointIdxNKNSearch(K);//索引列表
std::vector<float>pointNKNSquaredDistance(K);//对应的平方欧氏距离
//预先把vector大小设为K是可以的，但PCL的nearestKSearch实际返回的邻居数可能小于 K
std::cout<<"K nearest neighbor search at ("<<searchPoint.x
<<" "<<searchPoint.y
<<" "<<searchPoint.z
<<") with K="<< K <<std::endl;
if (kdtree.nearestKSearch (searchPoint,K, pointIdxNKNSearch, pointNKNSquaredDistance) >0 )//函数数签名返回 int found —— 实际找到的邻居数（0 表示没找到）
  {//函数把结果写入pointIdxNKNSearch, pointNKNSquaredDistance
for (size_t i=0; i<pointIdxNKNSearch.size (); ++i)
std::cout<<"    "<<   cloud->points[ pointIdxNKNSearch[i] ].x  
<<" "<< cloud->points[pointIdxNKNSearch[i] ].y 
<<" "<< cloud->points[pointIdxNKNSearch[i] ].z 
<<" (squared distance: "<<pointNKNSquaredDistance[i] <<")"<<std::endl;
  }

std::vector<int> pointIdxRadiusSearch;//每个元素是  找到点在原点云 cloud->points 中的索引，存放邻居点的索引
std::vector<float> pointRadiusSquaredDistance;//每个元素  是该点到查询点的平方欧氏距离，存放邻居点的平方欧氏距离
float radius =256.0f* rand () / (RAND_MAX +1.0f);//生成[0,256)
std::cout<<"Neighbors within radius search at ("<<searchPoint.x
<<" "<<searchPoint.y
<<" "<<searchPoint.z
<<") with radius="<< radius <<std::endl;

if ( kdtree.radiusSearch (searchPoint, radius, pointIdxRadiusSearch, pointRadiusSquaredDistance) >0 )
  {//kdtree.radiusSearch返回的是实际找到的邻居数
for (size_t i=0; i<pointIdxRadiusSearch.size (); ++i)
std::cout<<"    "<<   cloud->points[ pointIdxRadiusSearch[i] ].x 
<<" "<< cloud->points[pointIdxRadiusSearch[i] ].y 
<<" "<< cloud->points[pointIdxRadiusSearch[i] ].z 
<<" (squared distance: "<<pointRadiusSquaredDistance[i] <<")"<<std::endl;
  }
return 0;
}
