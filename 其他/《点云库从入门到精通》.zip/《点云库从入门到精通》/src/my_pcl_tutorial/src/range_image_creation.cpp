#include <pcl/range_image/range_image.h>
int main (int argc, char** argv) {
  pcl::PointCloud<pcl::PointXYZ> pointCloud;

  for (float y=-0.5f; y<=0.5f; y+=0.01f) {
    for (float z=-0.5f; z<=0.5f; z+=0.01f) {
      pcl::PointXYZ point;
      point.x = 2.0f - y;
      point.y = y;
      point.z = z;
      pointCloud.points.push_back(point);//生成人工点云，是一个矩形区域
    }
  }
  pointCloud.width = (uint32_t) pointCloud.points.size();
  pointCloud.height = 1;
  //设置 RangeImage 参数，角度转化为弧度
  float angularResolution = (float) (  1.0f * (M_PI/180.0f));//扫描角分辨率，1° 说明每隔 1° 采一个点，越小越精细  

  float maxAngleWidth     = (float) (360.0f * (M_PI/180.0f));//扫描的水平范围，这里是 360° 全景 

  float maxAngleHeight    = (float) (180.0f * (M_PI/180.0f));//扫描的垂直范围，这里是 180°（上下各 90°） 

  Eigen::Affine3f sensorPose = (Eigen::Affine3f)Eigen::Translation3f(0.0f, 0.0f, 0.0f);//传感器位置和方向，这里放在 (0,0,0)，朝默认方向
  pcl::RangeImage::CoordinateFrame coordinate_frame = pcl::RangeImage::CAMERA_FRAME;//使用相机坐标系（X 向右，Y 向下，Z 向前
  float noiseLevel=0.00;// 噪声水平（米），非0会做平滑
  float minRange = 0.0f;// 忽略比这个值近的点
  int borderSize = 1;//// 边界补充像素数
  pcl::RangeImage rangeImage;
  rangeImage.createFromPointCloud(pointCloud, angularResolution, maxAngleWidth, maxAngleHeight, sensorPose, coordinate_frame, noiseLevel, minRange, borderSize);
std::cout << rangeImage << "\n";
}
