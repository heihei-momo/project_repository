#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/io/io.h>
#include <pcl/compression/octree_pointcloud_compression.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/visualization/cloud_viewer.h>

pcl::visualization::CloudViewer* viewer_ptr = nullptr;
pcl::io::OctreePointCloudCompression<pcl::PointXYZRGBA>* encoder_ptr = nullptr;
pcl::io::OctreePointCloudCompression<pcl::PointXYZRGBA>* decoder_ptr = nullptr;

void cloudCallback(const sensor_msgs::PointCloud2ConstPtr& cloud_msg)
{
    // 转换 ROS -> PCL
    pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZRGBA>());
    pcl::fromROSMsg(*cloud_msg, *cloud);

    // 压缩
    std::stringstream compressedData;
    encoder_ptr->encodePointCloud(cloud, compressedData);//的作用是用 PCL 提供的 Octree 压缩算法，把输入的点云数据压缩成二进制流，并存放到 compressedData

    // 解压
    pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloudOut(new pcl::PointCloud<pcl::PointXYZRGBA>());
    decoder_ptr->decodePointCloud(compressedData, cloudOut);//解压到cloudout

    // 显示
    viewer_ptr->showCloud(cloudOut);//pcl::visualization::CloudViewer 是 PCL 自带的一个简单可视化工具类。
    //它能快速弹出一个窗口，把点云绘制成 3D 图像，支持鼠标旋转、缩放和移动视角
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "point_cloud_compression_node");
    ros::NodeHandle nh;

    bool showStatistics = true;
    pcl::io::compression_Profiles_e compressionProfile =pcl::io::MED_RES_ONLINE_COMPRESSION_WITH_COLOR;
    //compression_Profiles_e 是 PCL 提供的一组预设压缩模板（位于 pcl::io 命名空间）
    // 创建压缩器与解压器
    encoder_ptr = new pcl::io::OctreePointCloudCompression<pcl::PointXYZRGBA>(compressionProfile, showStatistics);
    //模板参数 pcl::PointXYZRGBA 指明要压缩的点云类型（必须和你给它的点云类型一致）。
    // 构造器里传入 compressionProfile（预设）与 showStatistics（是否打印统计）
    decoder_ptr = new pcl::io::OctreePointCloudCompression<pcl::PointXYZRGBA>();
    //创建 解压器（Decoder）。解码器通常不需要预设参数，因为压缩流里包含了足够的 metadata，解码时会自动按流里的设置恢复点云。
    viewer_ptr = new pcl::visualization::CloudViewer("Decoded Point Cloud");//创建一个简单的可视化窗口，用于显示点云

    ros::Subscriber sub = nh.subscribe("/camera/depth/color/points", 1, cloudCallback);

    ros::spin();

    delete encoder_ptr;
    delete decoder_ptr;
    delete viewer_ptr;
    return 0;
}
