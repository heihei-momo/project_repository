#### 开启realsense D435 i

cd deep_camera_ws /

roslaunch realsense2_camera demo_pointcloud.launch 

